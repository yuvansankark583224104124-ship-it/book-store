package com.bookstore.model;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Model class encapsulating aggregated dashboard metrics for Admin.
 * Company: YUVAN & THIYAGU & CO.
 */
public class DashboardStats implements Serializable {
    private static final long serialVersionUID = 1L;

    private int totalBooks;
    private int totalCustomers;
    private int totalOrders;
    private double totalSales;
    private int availableStock;
    private int pendingOrders;
    private int lowStockCount;

    private List<Order> recentOrders;
    private List<Book> lowStockBooks;
    private List<Map<String, Object>> bestSellers;

    public DashboardStats() {
    }

    public int getTotalBooks() {
        return totalBooks;
    }

    public void setTotalBooks(int totalBooks) {
        this.totalBooks = totalBooks;
    }

    public int getTotalCustomers() {
        return totalCustomers;
    }

    public void setTotalCustomers(int totalCustomers) {
        this.totalCustomers = totalCustomers;
    }

    public int getTotalOrders() {
        return totalOrders;
    }

    public void setTotalOrders(int totalOrders) {
        this.totalOrders = totalOrders;
    }

    public double getTotalSales() {
        return totalSales;
    }

    public void setTotalSales(double totalSales) {
        this.totalSales = totalSales;
    }

    public int getAvailableStock() {
        return availableStock;
    }

    public void setAvailableStock(int availableStock) {
        this.availableStock = availableStock;
    }

    public int getPendingOrders() {
        return pendingOrders;
    }

    public void setPendingOrders(int pendingOrders) {
        this.pendingOrders = pendingOrders;
    }

    public int getLowStockCount() {
        return lowStockCount;
    }

    public void setLowStockCount(int lowStockCount) {
        this.lowStockCount = lowStockCount;
    }

    public List<Order> getRecentOrders() {
        return recentOrders;
    }

    public void setRecentOrders(List<Order> recentOrders) {
        this.recentOrders = recentOrders;
    }

    public List<Book> getLowStockBooks() {
        return lowStockBooks;
    }

    public void setLowStockBooks(List<Book> lowStockBooks) {
        this.lowStockBooks = lowStockBooks;
    }

    public List<Map<String, Object>> getBestSellers() {
        return bestSellers;
    }

    public void setBestSellers(List<Map<String, Object>> bestSellers) {
        this.bestSellers = bestSellers;
    }

    public String getFormattedTotalSales() {
        return String.format("₹%.2f", totalSales);
    }
}
