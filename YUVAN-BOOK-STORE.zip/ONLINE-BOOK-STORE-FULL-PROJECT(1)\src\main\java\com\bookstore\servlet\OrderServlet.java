package com.bookstore.servlet;

import com.bookstore.dao.OrderDAO;
import com.bookstore.model.Order;
import com.bookstore.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * Controller servlet for customer order history, tracking, and cancellation.
 * Company: YUVAN & THIYAGU & CO.
 */
@WebServlet(name = "OrderServlet", urlPatterns = {"/orders", "/order-details", "/track-order", "/cancel-order"})
public class OrderServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final OrderDAO orderDAO = new OrderDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("loggedUser");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String path = request.getServletPath();

        if ("/order-details".equals(path)) {
            handleOrderDetails(request, response, user);
        } else if ("/track-order".equals(path)) {
            handleTrackOrder(request, response, user);
        } else if ("/cancel-order".equals(path)) {
            handleCancelOrder(request, response, user);
        } else {
            handleOrderHistory(request, response, user);
        }
    }

    private void handleOrderHistory(HttpServletRequest request, HttpServletResponse response, User user)
            throws ServletException, IOException {
        List<Order> orders = orderDAO.getOrdersByUser(user.getUserId());
        request.setAttribute("orders", orders);
        request.getRequestDispatcher("/orders.jsp").forward(request, response);
    }

    private void handleOrderDetails(HttpServletRequest request, HttpServletResponse response, User user)
            throws ServletException, IOException {
        String idParam = request.getParameter("id");
        if (idParam == null) {
            response.sendRedirect(request.getContextPath() + "/orders");
            return;
        }

        try {
            int orderId = Integer.parseInt(idParam);
            Order order = orderDAO.getOrderById(orderId);

            if (order == null || order.getUserId() != user.getUserId()) {
                request.getSession().setAttribute("errorMsg", "Order not found or access denied.");
                response.sendRedirect(request.getContextPath() + "/orders");
                return;
            }

            request.setAttribute("order", order);
            request.getRequestDispatcher("/order-details.jsp").forward(request, response);

        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/orders");
        }
    }

    private void handleTrackOrder(HttpServletRequest request, HttpServletResponse response, User user)
            throws ServletException, IOException {
        String idParam = request.getParameter("id");
        if (idParam == null) {
            response.sendRedirect(request.getContextPath() + "/orders");
            return;
        }

        try {
            int orderId = Integer.parseInt(idParam);
            Order order = orderDAO.getOrderById(orderId);

            if (order == null || order.getUserId() != user.getUserId()) {
                request.getSession().setAttribute("errorMsg", "Order not found or access denied.");
                response.sendRedirect(request.getContextPath() + "/orders");
                return;
            }

            request.setAttribute("order", order);
            request.getRequestDispatcher("/track-order.jsp").forward(request, response);

        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/orders");
        }
    }

    private void handleCancelOrder(HttpServletRequest request, HttpServletResponse response, User user)
            throws IOException {
        String idParam = request.getParameter("id");
        if (idParam != null) {
            try {
                int orderId = Integer.parseInt(idParam);
                boolean cancelled = orderDAO.cancelOrder(orderId, user.getUserId());
                if (cancelled) {
                    request.getSession().setAttribute("successMsg", "Order #" + orderId + " has been cancelled successfully. Stock has been restored.");
                } else {
                    request.getSession().setAttribute("errorMsg", "Order cannot be cancelled as it may have already been shipped or processed.");
                }
            } catch (NumberFormatException ignored) {}
        }
        response.sendRedirect(request.getContextPath() + "/orders");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
