package com.bookstore.servlet;

import com.bookstore.dao.BookDAO;
import com.bookstore.model.Book;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * Controller servlet for Admin Live Inventory and Stock Management.
 * Company: YUVAN & THIYAGU & CO.
 */
@WebServlet(name = "AdminInventoryServlet", urlPatterns = {"/admin/inventory", "/admin/update-stock"})
public class AdminInventoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final BookDAO bookDAO = new BookDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String filter = request.getParameter("filter");
        List<Book> books;

        if ("low".equalsIgnoreCase(filter)) {
            books = bookDAO.getLowStockBooks();
            request.setAttribute("activeFilter", "low");
        } else {
            books = bookDAO.getAllBooks();
            request.setAttribute("activeFilter", "all");
        }

        int lowStockCount = bookDAO.getLowStockBooks().size();
        request.setAttribute("books", books);
        request.setAttribute("lowStockCount", lowStockCount);

        request.getRequestDispatcher("/admin/inventory.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String bookIdParam = request.getParameter("bookId");
        String stockParam = request.getParameter("stock");
        String priceParam = request.getParameter("price");
        HttpSession session = request.getSession();

        if (bookIdParam == null || stockParam == null) {
            session.setAttribute("errorMsg", "Invalid stock update parameters.");
            response.sendRedirect(request.getContextPath() + "/admin/inventory");
            return;
        }

        try {
            int bookId = Integer.parseInt(bookIdParam);
            int stock = Integer.parseInt(stockParam);

            if (stock < 0) {
                session.setAttribute("errorMsg", "Stock cannot be negative.");
                response.sendRedirect(request.getContextPath() + "/admin/inventory");
                return;
            }

            boolean updated;
            if (priceParam != null && !priceParam.trim().isEmpty()) {
                double price = Double.parseDouble(priceParam);
                updated = bookDAO.updatePriceAndStock(bookId, price, stock);
            } else {
                updated = bookDAO.updateStock(bookId, stock);
            }

            if (updated) {
                session.setAttribute("successMsg", "Inventory stock for Book #" + bookId + " updated to " + stock + " units.");
            } else {
                session.setAttribute("errorMsg", "Failed to update inventory stock.");
            }

        } catch (NumberFormatException e) {
            session.setAttribute("errorMsg", "Invalid numeric values entered.");
        }

        response.sendRedirect(request.getContextPath() + "/admin/inventory");
    }
}
