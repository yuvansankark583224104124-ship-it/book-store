package com.bookstore.servlet;

import com.bookstore.dao.BookDAO;
import com.bookstore.dao.CartDAO;
import com.bookstore.model.Book;
import com.bookstore.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Controller servlet for modifying quantities of items in the shopping cart.
 * Company: YUVAN & THIYAGU & CO.
 */
@WebServlet(name = "UpdateCartServlet", urlPatterns = {"/cart/update"})
public class UpdateCartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final CartDAO cartDAO = new CartDAO();
    private final BookDAO bookDAO = new BookDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("loggedUser") : null;

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String cartIdParam = request.getParameter("cartId");
        String bookIdParam = request.getParameter("bookId");
        String quantityParam = request.getParameter("quantity");
        String action = request.getParameter("action"); // "inc", "dec", or direct "set"

        try {
            int cartId = Integer.parseInt(cartIdParam);
            int bookId = Integer.parseInt(bookIdParam);
            int quantity = Integer.parseInt(quantityParam);

            Book book = bookDAO.getBookById(bookId);
            if (book == null) {
                session.setAttribute("errorMsg", "Book not found.");
                response.sendRedirect(request.getContextPath() + "/cart");
                return;
            }

            if ("inc".equals(action)) {
                quantity += 1;
            } else if ("dec".equals(action)) {
                quantity -= 1;
            }

            if (quantity <= 0) {
                cartDAO.removeFromCart(cartId);
                session.setAttribute("successMsg", "Item removed from cart.");
            } else if (quantity > book.getStock()) {
                session.setAttribute("errorMsg", "Cannot update quantity. Only " + book.getStock() + " copies available.");
            } else {
                cartDAO.updateQuantity(cartId, quantity);
                session.setAttribute("successMsg", "Cart updated successfully.");
            }

            int count = cartDAO.getCartCount(user.getUserId());
            session.setAttribute("cartCount", count);

        } catch (Exception e) {
            session.setAttribute("errorMsg", "Invalid cart update request.");
        }

        response.sendRedirect(request.getContextPath() + "/cart");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }
}
