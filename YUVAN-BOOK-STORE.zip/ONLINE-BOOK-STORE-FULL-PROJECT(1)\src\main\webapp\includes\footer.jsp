<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<footer class="bg-dark text-white pt-5 pb-4 mt-auto" style="background-color: #0b1120 !important;">
    <div class="container">
        <div class="row g-4">
            <!-- Col 1: Brand & Bio -->
            <div class="col-lg-4 col-md-6">
                <div class="d-flex align-items-center mb-3">
                    <i class="fa-solid fa-book-open-reader text-warning me-2 fs-3"></i>
                    <h5 class="fw-bold mb-0 text-white">YUVAN &amp; THIYAGU &amp; CO.</h5>
                </div>
                <p class="text-secondary small">
                    Your premier destination for academic textbooks, literature, technology guides, and inspiring reads. Empowering minds since 2026.
                </p>
                <div class="d-flex gap-3 text-secondary mt-3">
                    <a href="#" class="text-secondary fs-5 hover-warning"><i class="fa-brands fa-facebook"></i></a>
                    <a href="#" class="text-secondary fs-5 hover-warning"><i class="fa-brands fa-x-twitter"></i></a>
                    <a href="#" class="text-secondary fs-5 hover-warning"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" class="text-secondary fs-5 hover-warning"><i class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>

            <!-- Col 2: Quick Links -->
            <div class="col-lg-2 col-md-6">
                <h6 class="text-white fw-bold mb-3 text-uppercase">Explore</h6>
                <ul class="list-unstyled text-secondary small mb-0">
                    <li class="mb-2"><a href="${pageContext.request.contextPath}/home" class="text-decoration-none text-secondary">Home</a></li>
                    <li class="mb-2"><a href="${pageContext.request.contextPath}/books" class="text-decoration-none text-secondary">All Books</a></li>
                    <li class="mb-2"><a href="${pageContext.request.contextPath}/about.jsp" class="text-decoration-none text-secondary">About Us</a></li>
                    <li class="mb-2"><a href="${pageContext.request.contextPath}/contact.jsp" class="text-decoration-none text-secondary">Contact Us</a></li>
                    <li class="mb-2"><a href="${pageContext.request.contextPath}/admin/login.jsp" class="text-decoration-none text-warning"><i class="fa-solid fa-lock me-1"></i> Admin Portal</a></li>
                </ul>
            </div>

            <!-- Col 3: Customer Care -->
            <div class="col-lg-3 col-md-6">
                <h6 class="text-white fw-bold mb-3 text-uppercase">Customer Care</h6>
                <ul class="list-unstyled text-secondary small mb-0">
                    <li class="mb-2"><a href="${pageContext.request.contextPath}/cart" class="text-decoration-none text-secondary">Shopping Cart</a></li>
                    <li class="mb-2"><a href="${pageContext.request.contextPath}/orders" class="text-decoration-none text-secondary">Order History</a></li>
                    <li class="mb-2"><a href="${pageContext.request.contextPath}/profile" class="text-decoration-none text-secondary">Account Profile</a></li>
                    <li class="mb-2"><a href="#" class="text-decoration-none text-secondary">Privacy Policy</a></li>
                    <li class="mb-2"><a href="#" class="text-decoration-none text-secondary">Terms of Service</a></li>
                </ul>
            </div>

            <!-- Col 4: Contact Info -->
            <div class="col-lg-3 col-md-6">
                <h6 class="text-white fw-bold mb-3 text-uppercase">Get In Touch</h6>
                <p class="text-secondary small mb-2">
                    <i class="fa-solid fa-location-dot text-warning me-2"></i> 124, Anna Salai, Mount Road, Chennai, Tamil Nadu - 600002
                </p>
                <p class="text-secondary small mb-2">
                    <i class="fa-solid fa-phone text-warning me-2"></i> +91 98765 43210
                </p>
                <p class="text-secondary small mb-0">
                    <i class="fa-solid fa-envelope text-warning me-2"></i> contact@yuvanthiyagu.com
                </p>
            </div>
        </div>

        <hr class="border-secondary my-4">

        <div class="row align-items-center small text-secondary">
            <div class="col-md-6 text-center text-md-start mb-2 mb-md-0">
                &copy; 2026 <strong>YUVAN &amp; THIYAGU &amp; CO.</strong> All rights reserved.
            </div>
            <div class="col-md-6 text-center text-md-end">
                <span class="badge bg-secondary-subtle text-secondary me-2">College Project Edition</span>
                <span>Designed with <i class="fa-solid fa-heart text-danger"></i> &amp; Java MVC</span>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap 5 Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- Main App Script -->
<script src="${pageContext.request.contextPath}/js/main.js"></script>
</body>
</html>
