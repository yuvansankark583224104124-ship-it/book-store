﻿/**
 * YUVAN BOOK STORE - ONLINE BOOK STORE MANAGEMENT SYSTEM
 * Admin Panel Interactive JavaScript & Charts
 */

document.addEventListener('DOMContentLoaded', function () {
    // 1. Admin Sidebar Toggle for responsive views
    const sidebarToggle = document.getElementById('sidebarToggle');
    const adminSidebar = document.querySelector('.admin-sidebar');

    if (sidebarToggle && adminSidebar) {
        sidebarToggle.addEventListener('click', function () {
            adminSidebar.classList.toggle('show');
        });
    }

    // 2. Table search filter helper
    const adminSearchInput = document.getElementById('adminTableSearch');
    if (adminSearchInput) {
        adminSearchInput.addEventListener('keyup', function () {
            const filter = this.value.toLowerCase();
            const rows = document.querySelectorAll('.filterable-table tbody tr');

            rows.forEach(function (row) {
                const text = row.textContent.toLowerCase();
                if (text.indexOf(filter) > -1) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }
});

// Helper confirmation function for destructive actions
function confirmDelete(message) {
    return confirm(message || 'Are you sure you want to proceed with this deletion? This action cannot be undone.');
}
