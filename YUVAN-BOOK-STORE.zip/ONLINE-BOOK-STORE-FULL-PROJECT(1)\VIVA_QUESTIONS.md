﻿# VIVA VOCE QUESTIONS & ANSWERS
## Project: ONLINE BOOK STORE MANAGEMENT SYSTEM
**Company**: YUVAN BOOK STORE

---

### Q1: What is the main objective of the Online Book Store Management System?
**Ans**: The main objective is to digitize traditional bookstore operations for **YUVAN BOOK STORE**, providing an intuitive web platform where customers can browse, search, purchase, and track books online, while administrators can manage catalog inventory, categories, customer orders, and sales turnover reports.

---

### Q2: What architecture is used in this project?
**Ans**: The system uses the **Model-View-Controller (MVC)** architectural pattern:
* **Model**: Represents business data (Books, Categories, Cart, Orders, Users, Payments).
* **View**: User interfaces styled with HTML5, modern CSS3 variables, and responsive design.
* **Controller**: JavaScript event handlers and routing logic that manage user input, inventory stock constraints, and cart state transitions.

---

### Q3: How is data stored and managed on the client-side for the frontend demonstration?
**Ans**: We utilize the HTML5 Web Storage API (`localStorage`). The shopping cart items, recent orders, and temporary user preferences are serialized as JSON objects and stored persistently across browser page transitions.

---

### Q4: How does the real-time book search and category filtering work?
**Ans**: The JavaScript engine dynamically filters the books array against user input using string matching across multiple fields (`title`, `author`, `category`, and `isbn`). The DOM grid is updated instantly without requiring a page reload.

---

### Q5: How is responsive web design achieved in this project?
**Ans**: Responsive design is implemented using CSS3 Flexbox, CSS Grid layouts, and `@media` screen queries with breakpoints tailored for Mobile (below 768px), Tablet (768px - 992px), and Desktop (above 992px).

---

### Q6: What are the key stages in the order fulfillment lifecycle?
**Ans**: The order progress tracker uses a 5-step state transition:
1. `ORDER PLACED`
2. `CONFIRMED`
3. `SHIPPED`
4. `OUT FOR DELIVERY`
5. `DELIVERED`

---

### Q7: What security features are incorporated in the design?
**Ans**: 
1. Client-side form input validation for emails, phone numbers, and required fields.
2. Separation of Admin and Customer portal routes.
3. Quantity bounds checking preventing orders that exceed available inventory stock.

---

### Q8: What database schema is designed for backend deployment?
**Ans**: The MySQL schema (`book_store.sql`) contains 8 normalized relational tables: `admin`, `users`, `categories`, `books`, `cart`, `orders`, `order_details`, and `payments` with primary keys, foreign key constraints, and cascading integrity rules.

---

### Q9: What are the future enhancements possible for this system?
**Ans**:
1. Integration with live payment gateways (Razorpay, Stripe, PayPal).
2. AI-based recommendation engine recommending books based on customer browsing history.
3. Native mobile applications for Android and iOS using Flutter or React Native.
4. Automated SMS/Email dispatch alerts.
