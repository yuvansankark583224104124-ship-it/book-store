package com.bookstore.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Model class representing a Book in the bookstore.
 * Company: YUVAN & PRASUN & CO.
 */
public class Book implements Serializable {
    private static final long serialVersionUID = 1L;

    private int bookId;
    private String title;
    private String author;
    private int categoryId;
    private String categoryName; // Joined auxiliary field
    private String publisher;
    private String isbn;
    private double price;
    private int stock;
    private String description;
    private String imageUrl;
    private boolean featured;
    private Timestamp createdAt;

    public Book() {
    }

    public Book(int bookId, String title, String author, int categoryId, String publisher, String isbn, double price, int stock, String description, String imageUrl, boolean featured, Timestamp createdAt) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.categoryId = categoryId;
        this.publisher = publisher;
        this.isbn = isbn;
        this.price = price;
        this.stock = stock;
        this.description = description;
        this.imageUrl = imageUrl;
        this.featured = featured;
        this.createdAt = createdAt;
    }

    public Book(String title, String author, int categoryId, String publisher, String isbn, double price, int stock, String description, String imageUrl, boolean featured) {
        this.title = title;
        this.author = author;
        this.categoryId = categoryId;
        this.publisher = publisher;
        this.isbn = isbn;
        this.price = price;
        this.stock = stock;
        this.description = description;
        this.imageUrl = imageUrl;
        this.featured = featured;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImageUrl() {
        if (imageUrl == null || imageUrl.trim().isEmpty()) {
            return "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400&q=80";
        }
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public boolean isFeatured() {
        return featured;
    }

    public void setFeatured(boolean featured) {
        this.featured = featured;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public String getStockStatus() {
        if (stock <= 0) {
            return "Out of Stock";
        } else if (stock <= 5) {
            return "Low Stock (" + stock + " left)";
        } else {
            return "In Stock (" + stock + " available)";
        }
    }

    public String getStockBadgeClass() {
        if (stock <= 0) {
            return "bg-danger";
        } else if (stock <= 5) {
            return "bg-warning text-dark";
        } else {
            return "bg-success";
        }
    }

    public String getFormattedPrice() {
        return String.format("₹%.2f", price);
    }

    @Override
    public String toString() {
        return "Book{" +
                "bookId=" + bookId +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", price=" + price +
                ", stock=" + stock +
                '}';
    }
}
