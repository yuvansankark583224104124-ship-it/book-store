<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<c:set var="pageTitle" value="${book.title} | YUVAN & THIYAGU & CO." scope="request"/>
<jsp:include page="/includes/header.jsp" />
<jsp:include page="/includes/navbar.jsp" />

<main class="py-5 bg-light">
    <div class="container">
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="${pageContext.request.contextPath}/home" class="text-decoration-none">Home</a></li>
                <li class="breadcrumb-item"><a href="${pageContext.request.contextPath}/books" class="text-decoration-none">Books</a></li>
                <li class="breadcrumb-item"><a href="${pageContext.request.contextPath}/books?category=${book.categoryId}" class="text-decoration-none">${book.categoryName}</a></li>
                <li class="breadcrumb-item active" aria-current="page">${book.title}</li>
            </ol>
        </nav>

        <jsp:include page="/includes/alerts.jsp" />

        <!-- Main Book Details Card -->
        <div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-5">
            <div class="card-body p-4 p-md-5">
                <div class="row g-5">
                    <!-- Left: Book Cover Image Preview -->
                    <div class="col-lg-4 text-center">
                        <div class="p-4 bg-light rounded-4 shadow-sm d-flex align-items-center justify-content-center" style="min-height: 380px;">
                            <img src="${book.imageUrl}" alt="${book.title}" class="img-fluid rounded shadow-lg" style="max-height: 340px; object-fit: cover;">
                        </div>
                    </div>

                    <!-- Right: Metadata & Purchase Form -->
                    <div class="col-lg-8">
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <span class="badge bg-primary-subtle text-primary px-3 py-1 rounded-pill fw-semibold">
                                ${book.categoryName}
                            </span>
                            <c:if test="${book.featured}">
                                <span class="badge bg-warning text-dark px-2 py-1 rounded-pill fw-bold">
                                    <i class="fa-solid fa-star me-1"></i> Featured
                                </span>
                            </c:if>
                        </div>

                        <h1 class="h2 fw-bold text-dark mb-2">${book.title}</h1>
                        <p class="fs-5 text-muted mb-3">By <span class="text-dark fw-semibold">${book.author}</span></p>

                        <!-- Price & Stock Indicator -->
                        <div class="d-flex align-items-center gap-3 p-3 bg-light rounded-3 mb-4">
                            <div class="fs-2 fw-bold text-primary">${book.formattedPrice}</div>
                            <div class="vr"></div>
                            <div>
                                <span class="badge ${book.stockBadgeClass} rounded-pill px-3 py-2 fs-6">
                                    <i class="fa-solid fa-box me-1"></i> ${book.stockStatus}
                                </span>
                            </div>
                        </div>

                        <!-- Description -->
                        <div class="mb-4">
                            <h6 class="fw-bold text-dark text-uppercase small">Overview &amp; Synopsis</h6>
                            <p class="text-secondary" style="line-height: 1.7;">
                                ${book.description}
                            </p>
                        </div>

                        <!-- Technical Specs Table -->
                        <div class="row g-3 mb-4 small text-muted">
                            <div class="col-sm-6">
                                <div class="p-2 border rounded bg-white">
                                    <strong><i class="fa-solid fa-building me-2 text-primary"></i>Publisher:</strong> ${book.publisher}
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="p-2 border rounded bg-white">
                                    <strong><i class="fa-solid fa-barcode me-2 text-primary"></i>ISBN:</strong> <code>${book.isbn}</code>
                                </div>
                            </div>
                        </div>

                        <!-- Add to Cart Form with Stock Boundary Controls -->
                        <c:choose>
                            <c:when test="${book.stock > 0}">
                                <form action="${pageContext.request.contextPath}/cart/add" method="post" class="d-flex flex-wrap align-items-center gap-3">
                                    <input type="hidden" name="bookId" value="${book.bookId}">
                                    <input type="hidden" id="availableStockValue" value="${book.stock}">

                                    <div class="input-group" style="width: 140px;">
                                        <button class="btn btn-outline-secondary" type="button" id="btnQtyMinus"><i class="fa-solid fa-minus"></i></button>
                                        <input type="number" name="quantity" id="bookDetailQty" class="form-control text-center fw-bold" value="1" min="1" max="${book.stock}">
                                        <button class="btn btn-outline-secondary" type="button" id="btnQtyPlus"><i class="fa-solid fa-plus"></i></button>
                                    </div>

                                    <button type="submit" class="btn btn-warning btn-lg px-4 fw-bold text-dark shadow-sm">
                                        <i class="fa-solid fa-cart-shopping me-2"></i> Add to Cart
                                    </button>
                                </form>
                            </c:when>
                            <c:otherwise>
                                <div class="alert alert-danger d-inline-block py-2 px-4 rounded-pill">
                                    <i class="fa-solid fa-circle-xmark me-2"></i> This book is currently Out of Stock. Check back soon.
                                </div>
                            </c:otherwise>
                        </c:choose>
                    </div>
                </div>
            </div>
        </div>

        <!-- Related Books Section -->
        <c:if test="${not empty relatedBooks}">
            <section class="mt-5">
                <h4 class="fw-bold text-dark mb-4">
                    <i class="fa-solid fa-layer-group text-primary me-2"></i> You Might Also Like
                </h4>
                <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 g-4">
                    <c:forEach var="relBook" items="${relatedBooks}" begin="0" end="3">
                        <div class="col">
                            <div class="book-card">
                                <div class="img-container">
                                    <span class="book-badge-category">${relBook.categoryName}</span>
                                    <img src="${relBook.imageUrl}" alt="${relBook.title}" class="book-img" loading="lazy">
                                </div>
                                <div class="card-body">
                                    <h3 class="book-title" title="${relBook.title}">${relBook.title}</h3>
                                    <p class="book-author">By <span class="text-dark fw-medium">${relBook.author}</span></p>
                                    <div class="d-flex align-items-center justify-content-between mt-auto pt-2 border-top">
                                        <div class="book-price">${relBook.formattedPrice}</div>
                                        <a href="${pageContext.request.contextPath}/book-details?id=${relBook.bookId}" class="btn btn-outline-primary btn-sm">
                                            View
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </c:forEach>
                </div>
            </section>
        </c:if>
    </div>
</main>

<jsp:include page="/includes/footer.jsp" />
