package com.bookstore.dao;

import com.bookstore.model.CartItem;
import com.bookstore.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Customer Shopping Cart operations.
 * Company: YUVAN & THIYAGU & CO.
 */
public class CartDAO {

    /**
     * Adds a book to the user's cart or increments quantity if already present.
     * Validates against available book stock.
     * @return true on success, false if stock is insufficient or operation fails
     */
    public boolean addToCart(int userId, int bookId, int quantity) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();

            // 1. Check book stock
            String stockSql = "SELECT stock FROM `books` WHERE `book_id` = ?";
            ps = conn.prepareStatement(stockSql);
            ps.setInt(1, bookId);
            rs = ps.executeQuery();
            if (!rs.next()) {
                return false; // Book does not exist
            }
            int availableStock = rs.getInt("stock");
            DBConnection.closeResultSet(rs);
            DBConnection.closeStatement(ps);

            // 2. Check if item already in cart
            String checkSql = "SELECT cart_id, quantity FROM `cart` WHERE `user_id` = ? AND `book_id` = ?";
            ps = conn.prepareStatement(checkSql);
            ps.setInt(1, userId);
            ps.setInt(2, bookId);
            rs = ps.executeQuery();

            if (rs.next()) {
                int cartId = rs.getInt("cart_id");
                int currentQty = rs.getInt("quantity");
                int newQty = currentQty + quantity;

                if (newQty > availableStock) {
                    newQty = availableStock; // Cap at max available stock
                }
                if (newQty <= 0) {
                    return removeFromCart(cartId);
                }

                DBConnection.closeResultSet(rs);
                DBConnection.closeStatement(ps);

                String updateSql = "UPDATE `cart` SET `quantity` = ? WHERE `cart_id` = ?";
                ps = conn.prepareStatement(updateSql);
                ps.setInt(1, newQty);
                ps.setInt(2, cartId);
                return ps.executeUpdate() > 0;
            } else {
                DBConnection.closeResultSet(rs);
                DBConnection.closeStatement(ps);

                if (quantity > availableStock) {
                    quantity = availableStock;
                }
                if (quantity <= 0) {
                    return false;
                }

                String insertSql = "INSERT INTO `cart` (`user_id`, `book_id`, `quantity`) VALUES (?, ?, ?)";
                ps = conn.prepareStatement(insertSql);
                ps.setInt(1, userId);
                ps.setInt(2, bookId);
                ps.setInt(3, quantity);
                return ps.executeUpdate() > 0;
            }

        } catch (SQLException e) {
            System.err.println("[CartDAO.addToCart Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return false;
    }

    /**
     * Retrieves all cart items for a customer, joined with book and category information.
     */
    public List<CartItem> getCartItemsByUser(int userId) {
        List<CartItem> items = new ArrayList<>();
        String sql = "SELECT c.cart_id, c.user_id, c.book_id, c.quantity, " +
                     "b.title, b.author, b.isbn, b.image_url, b.price, b.stock, " +
                     "cat.category_name " +
                     "FROM `cart` c " +
                     "JOIN `books` b ON c.book_id = b.book_id " +
                     "JOIN `categories` cat ON b.category_id = cat.category_id " +
                     "WHERE c.user_id = ? ORDER BY c.added_at DESC";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            rs = ps.executeQuery();

            while (rs.next()) {
                CartItem item = new CartItem();
                item.setCartId(rs.getInt("cart_id"));
                item.setUserId(rs.getInt("user_id"));
                item.setBookId(rs.getInt("book_id"));
                item.setBookTitle(rs.getString("title"));
                item.setBookAuthor(rs.getString("author"));
                item.setIsbn(rs.getString("isbn"));
                item.setImageUrl(rs.getString("image_url"));
                item.setPrice(rs.getDouble("price"));
                item.setStock(rs.getInt("stock"));
                item.setQuantity(rs.getInt("quantity"));
                item.setCategoryName(rs.getString("category_name"));
                items.add(item);
            }
        } catch (SQLException e) {
            System.err.println("[CartDAO.getCartItemsByUser Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return items;
    }

    /**
     * Updates quantity of a specific cart item.
     */
    public boolean updateQuantity(int cartId, int quantity) {
        if (quantity <= 0) {
            return removeFromCart(cartId);
        }
        String sql = "UPDATE `cart` SET `quantity` = ? WHERE `cart_id` = ?";
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, quantity);
            ps.setInt(2, cartId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[CartDAO.updateQuantity Error] " + e.getMessage());
        } finally {
            DBConnection.closeStatement(ps);
            DBConnection.closeConnection(conn);
        }
        return false;
    }

    /**
     * Removes an item from the cart.
     */
    public boolean removeFromCart(int cartId) {
        String sql = "DELETE FROM `cart` WHERE `cart_id` = ?";
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, cartId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[CartDAO.removeFromCart Error] " + e.getMessage());
        } finally {
            DBConnection.closeStatement(ps);
            DBConnection.closeConnection(conn);
        }
        return false;
    }

    /**
     * Empties the cart for a user (e.g. after order checkout).
     */
    public boolean clearCart(int userId) {
        String sql = "DELETE FROM `cart` WHERE `user_id` = ?";
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            return ps.executeUpdate() >= 0;
        } catch (SQLException e) {
            System.err.println("[CartDAO.clearCart Error] " + e.getMessage());
        } finally {
            DBConnection.closeStatement(ps);
            DBConnection.closeConnection(conn);
        }
        return false;
    }

    /**
     * Computes the total grand total amount in user's cart.
     */
    public double getCartTotal(int userId) {
        String sql = "SELECT COALESCE(SUM(c.quantity * b.price), 0) AS grand_total " +
                     "FROM `cart` c JOIN `books` b ON c.book_id = b.book_id WHERE c.user_id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getDouble("grand_total");
            }
        } catch (SQLException e) {
            System.err.println("[CartDAO.getCartTotal Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return 0.0;
    }

    /**
     * Computes total distinct item count in user's cart for navigation badge.
     */
    public int getCartCount(int userId) {
        String sql = "SELECT COALESCE(SUM(quantity), 0) AS total_count FROM `cart` WHERE `user_id` = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("total_count");
            }
        } catch (SQLException e) {
            System.err.println("[CartDAO.getCartCount Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return 0;
    }
}
