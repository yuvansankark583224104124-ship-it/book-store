package com.bookstore.filter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Security Filter that protects customer-specific endpoints (cart, checkout, orders, profile, invoice).
 * Company: YUVAN & THIYAGU & CO.
 */
@WebFilter(filterName = "UserAuthFilter", urlPatterns = {
        "/cart/*", "/checkout", "/place-order", "/orders", "/order-details", 
        "/track-order", "/invoice", "/profile", "/cart.jsp", "/checkout.jsp", 
        "/orders.jsp", "/profile.jsp", "/invoice.jsp"
})
public class UserAuthFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        HttpSession session = httpRequest.getSession(false);
        boolean loggedIn = (session != null && session.getAttribute("loggedUser") != null);

        if (loggedIn) {
            chain.doFilter(request, response);
        } else {
            String targetUri = httpRequest.getRequestURI();
            if (httpRequest.getQueryString() != null) {
                targetUri += "?" + httpRequest.getQueryString();
            }
            httpRequest.getSession(true).setAttribute("redirectAfterLogin", targetUri);
            httpRequest.getSession(true).setAttribute("errorMsg", "Please log in to your account to proceed.");
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/login.jsp");
        }
    }

    @Override
    public void destroy() {
    }
}
