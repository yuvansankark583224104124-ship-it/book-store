<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<c:set var="pageTitle" value="Search Results for '${keyword}' | YUVAN & THIYAGU & CO." scope="request"/>
<jsp:include page="/includes/header.jsp" />
<jsp:include page="/includes/navbar.jsp" />

<main class="py-5 bg-light">
    <div class="container">
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="${pageContext.request.contextPath}/home" class="text-decoration-none">Home</a></li>
                <li class="breadcrumb-item"><a href="${pageContext.request.contextPath}/books" class="text-decoration-none">Books</a></li>
                <li class="breadcrumb-item active" aria-current="page">Search Results</li>
            </ol>
        </nav>

        <jsp:include page="/includes/alerts.jsp" />

        <!-- Search Header Bar -->
        <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
            <div class="row align-items-center g-3">
                <div class="col-md-6">
                    <h4 class="fw-bold text-dark mb-1">
                        <i class="fa-solid fa-magnifying-glass text-warning me-2"></i> Search Results
                    </h4>
                    <p class="text-muted small mb-0">
                        Found <strong>${resultCount}</strong> match(es) for keyword: <span class="badge bg-secondary-subtle text-dark fs-6 px-2">"${keyword}"</span>
                    </p>
                </div>
                <div class="col-md-6">
                    <form action="${pageContext.request.contextPath}/search" method="get" class="d-flex">
                        <input type="text" name="q" class="form-control me-2" placeholder="Refine search query..." value="${keyword}" required>
                        <button type="submit" class="btn btn-warning fw-bold px-3">Search</button>
                    </form>
                </div>
            </div>
        </div>

        <c:choose>
            <c:when test="${not empty books}">
                <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
                    <c:forEach var="book" items="${books}">
                        <div class="col">
                            <div class="book-card">
                                <div class="img-container">
                                    <span class="book-badge-category">${book.categoryName}</span>
                                    <img src="${book.imageUrl}" alt="${book.title}" class="book-img" loading="lazy">
                                </div>
                                <div class="card-body">
                                    <h3 class="book-title" title="${book.title}">${book.title}</h3>
                                    <p class="book-author">By <span class="text-dark fw-medium">${book.author}</span></p>
                                    
                                    <div class="d-flex align-items-center justify-content-between mt-auto pt-2 border-top">
                                        <div>
                                            <div class="book-price">${book.formattedPrice}</div>
                                            <span class="badge ${book.stockBadgeClass} rounded-pill font-monospace" style="font-size: 0.72rem;">
                                                ${book.stockStatus}
                                            </span>
                                        </div>
                                        <div class="d-flex gap-1">
                                            <a href="${pageContext.request.contextPath}/book-details?id=${book.bookId}" class="btn btn-outline-secondary btn-sm" title="View Details">
                                                <i class="fa-solid fa-eye"></i>
                                            </a>
                                            <c:choose>
                                                <c:when test="${book.stock > 0}">
                                                    <form action="${pageContext.request.contextPath}/cart/add" method="post" class="d-inline">
                                                        <input type="hidden" name="bookId" value="${book.bookId}">
                                                        <input type="hidden" name="quantity" value="1">
                                                        <button type="submit" class="btn btn-primary btn-sm" title="Add to Cart">
                                                            <i class="fa-solid fa-cart-plus me-1"></i> Add
                                                        </button>
                                                    </form>
                                                </c:when>
                                                <c:otherwise>
                                                    <button class="btn btn-secondary btn-sm" disabled>Sold Out</button>
                                                </c:otherwise>
                                            </c:choose>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </c:forEach>
                </div>
            </c:when>
            <c:otherwise>
                <div class="card border-0 shadow-sm rounded-4 p-5 text-center my-4">
                    <i class="fa-solid fa-face-frown fs-1 text-muted mb-3"></i>
                    <h4 class="fw-bold text-dark">No Books Matched Your Search</h4>
                    <p class="text-muted">We couldn't find any books matching "<strong>${keyword}</strong>". Try searching for general terms like <em>Java</em>, <em>Science</em>, <em>Habits</em>, or author names.</p>
                    <div class="mt-2">
                        <a href="${pageContext.request.contextPath}/books" class="btn btn-primary px-4">Browse All Books</a>
                    </div>
                </div>
            </c:otherwise>
        </c:choose>
    </div>
</main>

<jsp:include page="/includes/footer.jsp" />
