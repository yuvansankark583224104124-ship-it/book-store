package com.bookstore.servlet;

import com.bookstore.dao.CartDAO;
import com.bookstore.model.CartItem;
import com.bookstore.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * Controller servlet for displaying Customer Shopping Cart.
 * Calculates subtotals, grand total, and checks available stock.
 * Company: YUVAN & THIYAGU & CO.
 */
@WebServlet(name = "CartServlet", urlPatterns = {"/cart"})
public class CartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final CartDAO cartDAO = new CartDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("loggedUser");

        if (user == null) {
            session.setAttribute("errorMsg", "Please log in to view your shopping cart.");
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        List<CartItem> cartItems = cartDAO.getCartItemsByUser(user.getUserId());
        double grandTotal = 0.0;
        boolean hasStockIssue = false;

        for (CartItem item : cartItems) {
            grandTotal += item.getSubtotal();
            if (item.getQuantity() > item.getStock()) {
                hasStockIssue = true;
            }
        }

        // Update session count
        int count = cartDAO.getCartCount(user.getUserId());
        session.setAttribute("cartCount", count);

        request.setAttribute("cartItems", cartItems);
        request.setAttribute("grandTotal", grandTotal);
        request.setAttribute("hasStockIssue", hasStockIssue);

        request.getRequestDispatcher("/cart.jsp").forward(request, response);
    }
}
