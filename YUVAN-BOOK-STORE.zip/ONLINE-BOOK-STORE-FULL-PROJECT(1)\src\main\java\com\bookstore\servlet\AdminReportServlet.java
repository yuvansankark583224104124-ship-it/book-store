package com.bookstore.servlet;

import com.bookstore.dao.AdminDAO;
import com.bookstore.model.SalesReport;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Controller servlet for Admin Sales and Revenue Analytics Reports.
 * Company: YUVAN & THIYAGU & CO.
 */
@WebServlet(name = "AdminReportServlet", urlPatterns = {"/admin/reports"})
public class AdminReportServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final AdminDAO adminDAO = new AdminDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        SalesReport report = adminDAO.getSalesReport();
        request.setAttribute("report", report);
        request.getRequestDispatcher("/admin/reports.jsp").forward(request, response);
    }
}
