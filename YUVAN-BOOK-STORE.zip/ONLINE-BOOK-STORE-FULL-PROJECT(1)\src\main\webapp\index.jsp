<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<%-- If accessed directly without HomeServlet forwarding, redirect to /home to load data --%>
<c:if test="${empty featuredBooks && empty categories}">
    <c:redirect url="/home" />
</c:if>

<c:set var="pageTitle" value="YUVAN & THIYAGU & CO. | Online Book Store" scope="request"/>
<jsp:include page="/includes/header.jsp" />
<jsp:include page="/includes/navbar.jsp" />

<main>
    <!-- Hero Section -->
    <section class="hero-section text-center">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-9">
                    <span class="badge bg-warning text-dark px-3 py-2 rounded-pill fw-bold text-uppercase mb-3 shadow-sm">
                        <i class="fa-solid fa-sparkles me-1"></i> Welcome to YUVAN &amp; THIYAGU &amp; CO.
                    </span>
                    <h1 class="hero-title mb-3">FIND YOUR NEXT GREAT BOOK</h1>
                    <p class="hero-subtitle">
                        Discover thousands of curated books spanning Computer Science, Literature, Business, History, and Engineering at unbeatable academic prices.
                    </p>

                    <!-- Main Search Bar -->
                    <div class="search-wrapper mb-4">
                        <form action="${pageContext.request.contextPath}/search" method="get" class="search-input-group d-flex shadow-lg rounded-pill">
                            <input type="text" name="q" class="form-control form-control-lg" placeholder="Search by title, author, category, or ISBN..." required>
                            <button type="submit" class="btn btn-warning btn-lg px-4">
                                <i class="fa-solid fa-magnifying-glass me-2"></i> Search
                            </button>
                        </form>
                    </div>

                    <!-- Category Pills Quick Navigation -->
                    <div class="d-flex flex-wrap justify-content-center gap-2 mt-4">
                        <c:forEach var="cat" items="${categories}">
                            <a href="${pageContext.request.contextPath}/books?category=${cat.categoryId}" class="category-pill">
                                <i class="fa-solid fa-bookmark text-warning me-1"></i> ${cat.categoryName}
                            </a>
                        </c:forEach>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Main Content Container -->
    <div class="container my-5">
        <jsp:include page="/includes/alerts.jsp" />

        <!-- Featured Books Section -->
        <section class="mb-5">
            <div class="d-flex justify-content-between align-items-end mb-4 border-bottom pb-2">
                <div>
                    <h2 class="fw-bold text-dark mb-1">
                        <i class="fa-solid fa-fire text-danger me-2"></i> Popular &amp; Featured Books
                    </h2>
                    <p class="text-muted mb-0">Handpicked bestsellers chosen by our academic editorial board</p>
                </div>
                <a href="${pageContext.request.contextPath}/books" class="btn btn-outline-primary btn-sm fw-semibold">
                    View All Books <i class="fa-solid fa-arrow-right ms-1"></i>
                </a>
            </div>

            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
                <c:forEach var="book" items="${featuredBooks}">
                    <div class="col">
                        <div class="book-card">
                            <div class="img-container">
                                <span class="book-badge-category">${book.categoryName}</span>
                                <img src="${book.imageUrl}" alt="${book.title}" class="book-img" loading="lazy">
                            </div>
                            <div class="card-body">
                                <h3 class="book-title" title="${book.title}">${book.title}</h3>
                                <p class="book-author">By <span class="text-dark fw-medium">${book.author}</span></p>
                                
                                <div class="d-flex align-items-center justify-content-between mt-auto pt-2 border-top">
                                    <div>
                                        <div class="book-price">${book.formattedPrice}</div>
                                        <span class="badge ${book.stockBadgeClass} rounded-pill font-monospace" style="font-size: 0.72rem;">
                                            ${book.stockStatus}
                                        </span>
                                    </div>
                                    <div class="d-flex gap-1">
                                        <a href="${pageContext.request.contextPath}/book-details?id=${book.bookId}" class="btn btn-outline-secondary btn-sm" title="View Details">
                                            <i class="fa-solid fa-eye"></i>
                                        </a>
                                        <c:choose>
                                            <c:when test="${book.stock > 0}">
                                                <form action="${pageContext.request.contextPath}/cart/add" method="post" class="d-inline">
                                                    <input type="hidden" name="bookId" value="${book.bookId}">
                                                    <input type="hidden" name="quantity" value="1">
                                                    <button type="submit" class="btn btn-primary btn-sm" title="Add to Cart">
                                                        <i class="fa-solid fa-cart-plus me-1"></i> Add
                                                    </button>
                                                </form>
                                            </c:when>
                                            <c:otherwise>
                                                <button class="btn btn-secondary btn-sm" disabled>Sold Out</button>
                                            </c:otherwise>
                                        </c:choose>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </c:forEach>
            </div>
        </section>

        <!-- Value Proposition Features Banner -->
        <section class="my-5 py-4">
            <div class="row g-4">
                <div class="col-md-3">
                    <div class="feature-box h-100 shadow-sm">
                        <div class="feature-icon"><i class="fa-solid fa-truck-fast"></i></div>
                        <h5 class="fw-bold">Express Delivery</h5>
                        <p class="text-muted small mb-0">Fast dispatch to your doorstep across Tamil Nadu &amp; India.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="feature-box h-100 shadow-sm">
                        <div class="feature-icon"><i class="fa-solid fa-certificate"></i></div>
                        <h5 class="fw-bold">100% Genuine Books</h5>
                        <p class="text-muted small mb-0">Direct procurement from top academic and trade publishers.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="feature-box h-100 shadow-sm">
                        <div class="feature-icon"><i class="fa-solid fa-shield-check"></i></div>
                        <h5 class="fw-bold">Secure Checkout</h5>
                        <p class="text-muted small mb-0">Cash on Delivery and instant simulated digital payment options.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="feature-box h-100 shadow-sm">
                        <div class="feature-icon"><i class="fa-solid fa-headset"></i></div>
                        <h5 class="fw-bold">Dedicated Support</h5>
                        <p class="text-muted small mb-0">Direct student and institutional book order assistance.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- New Arrivals Section -->
        <section class="mb-5">
            <div class="d-flex justify-content-between align-items-end mb-4 border-bottom pb-2">
                <div>
                    <h2 class="fw-bold text-dark mb-1">
                        <i class="fa-solid fa-clock-rotate-left text-primary me-2"></i> Recent Additions
                    </h2>
                    <p class="text-muted mb-0">Freshly cataloged volumes added this week</p>
                </div>
                <a href="${pageContext.request.contextPath}/books" class="btn btn-outline-primary btn-sm fw-semibold">
                    Browse All <i class="fa-solid fa-arrow-right ms-1"></i>
                </a>
            </div>

            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
                <c:forEach var="book" items="${recentBooks}">
                    <div class="col">
                        <div class="book-card">
                            <div class="img-container">
                                <span class="book-badge-category">${book.categoryName}</span>
                                <img src="${book.imageUrl}" alt="${book.title}" class="book-img" loading="lazy">
                            </div>
                            <div class="card-body">
                                <h3 class="book-title" title="${book.title}">${book.title}</h3>
                                <p class="book-author">By <span class="text-dark fw-medium">${book.author}</span></p>
                                
                                <div class="d-flex align-items-center justify-content-between mt-auto pt-2 border-top">
                                    <div>
                                        <div class="book-price">${book.formattedPrice}</div>
                                        <span class="badge ${book.stockBadgeClass} rounded-pill font-monospace" style="font-size: 0.72rem;">
                                            ${book.stockStatus}
                                        </span>
                                    </div>
                                    <div class="d-flex gap-1">
                                        <a href="${pageContext.request.contextPath}/book-details?id=${book.bookId}" class="btn btn-outline-secondary btn-sm" title="View Details">
                                            <i class="fa-solid fa-eye"></i>
                                        </a>
                                        <c:choose>
                                            <c:when test="${book.stock > 0}">
                                                <form action="${pageContext.request.contextPath}/cart/add" method="post" class="d-inline">
                                                    <input type="hidden" name="bookId" value="${book.bookId}">
                                                    <input type="hidden" name="quantity" value="1">
                                                    <button type="submit" class="btn btn-primary btn-sm" title="Add to Cart">
                                                        <i class="fa-solid fa-cart-plus me-1"></i> Add
                                                    </button>
                                                </form>
                                            </c:when>
                                            <c:otherwise>
                                                <button class="btn btn-secondary btn-sm" disabled>Sold Out</button>
                                            </c:otherwise>
                                        </c:choose>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </c:forEach>
            </div>
        </section>
    </div>
</main>

<jsp:include page="/includes/footer.jsp" />
