package com.bookstore.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Database Connection Utility for MySQL.
 * Manages JDBC Driver loading and Connection lifecycles.
 * Company: YUVAN & THIYAGU & CO.
 */
public class DBConnection {

    private static final String DRIVER_CLASS = "com.mysql.cj.jdbc.Driver";
    private static final String DB_NAME = "book_store";
    private static final String HOST = System.getProperty("db.host", "localhost");
    private static final String PORT = System.getProperty("db.port", "3306");
    
    // Default connection parameters
    private static final String URL = "jdbc:mysql://" + HOST + ":" + PORT + "/" + DB_NAME + 
            "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&useUnicode=true&characterEncoding=UTF-8";
    
    // Default credentials (can be overridden via environment variables or JVM system properties)
    private static final String USER = System.getProperty("db.user", System.getenv("DB_USER") != null ? System.getenv("DB_USER") : "root");
    private static final String PASSWORD = System.getProperty("db.password", System.getenv("DB_PASSWORD") != null ? System.getenv("DB_PASSWORD") : "root");

    static {
        try {
            Class.forName(DRIVER_CLASS);
        } catch (ClassNotFoundException e) {
            System.err.println("[DBConnection] MySQL JDBC Driver not found in classpath: " + e.getMessage());
            // Fallback for older drivers if present
            try {
                Class.forName("com.mysql.jdbc.Driver");
            } catch (ClassNotFoundException ex) {
                System.err.println("[DBConnection] Fatal: Unable to load any MySQL Driver: " + ex.getMessage());
            }
        }
    }

    private DBConnection() {
        // Private constructor to prevent instantiation
    }

    /**
     * Obtains a new database connection using standard configuration.
     * @return Connection object
     * @throws SQLException if connection fails
     */
    public static Connection getConnection() throws SQLException {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            // Attempt fallback to empty password if default root/root fails (common in XAMPP/WAMP/Mac/Linux)
            if ("root".equals(PASSWORD) && e.getErrorCode() == 1045) {
                try {
                    return DriverManager.getConnection(URL, USER, "");
                } catch (SQLException ignored) {
                    // rethrow original
                }
            }
            System.err.println("[DBConnection Error] Failed to connect to MySQL: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Safely closes a database connection.
     * @param conn Connection to close
     */
    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                System.err.println("[DBConnection] Error closing Connection: " + e.getMessage());
            }
        }
    }

    /**
     * Safely closes a database statement.
     * @param stmt Statement to close
     */
    public static void closeStatement(Statement stmt) {
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                System.err.println("[DBConnection] Error closing Statement: " + e.getMessage());
            }
        }
    }

    /**
     * Safely closes a database result set.
     * @param rs ResultSet to close
     */
    public static void closeResultSet(ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                System.err.println("[DBConnection] Error closing ResultSet: " + e.getMessage());
            }
        }
    }

    /**
     * Closes all database resources safely in one call.
     */
    public static void closeAll(ResultSet rs, Statement stmt, Connection conn) {
        closeResultSet(rs);
        closeStatement(stmt);
        closeConnection(conn);
    }
}
