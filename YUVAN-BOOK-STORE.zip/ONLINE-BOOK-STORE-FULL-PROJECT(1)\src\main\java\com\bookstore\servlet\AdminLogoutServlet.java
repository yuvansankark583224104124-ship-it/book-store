package com.bookstore.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Controller servlet for Administrator logout.
 * Company: YUVAN & THIYAGU & CO.
 */
@WebServlet(name = "AdminLogoutServlet", urlPatterns = {"/admin-logout", "/admin/logout"})
public class AdminLogoutServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.removeAttribute("adminUser");
            session.invalidate();
        }
        HttpSession newSession = request.getSession(true);
        newSession.setAttribute("successMsg", "Admin logged out successfully.");
        response.sendRedirect(request.getContextPath() + "/admin/login.jsp");
    }
}
