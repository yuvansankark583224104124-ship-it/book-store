package com.bookstore.dao;

import com.bookstore.model.Book;
import com.bookstore.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Book catalog, search, filtering, stock management, and CRUD.
 * Company: YUVAN & THIYAGU & CO.
 */
public class BookDAO {

    /**
     * Retrieves all books with joined category name.
     */
    public List<Book> getAllBooks() {
        List<Book> books = new ArrayList<>();
        String sql = "SELECT b.*, c.category_name FROM `books` b " +
                     "JOIN `categories` c ON b.category_id = c.category_id " +
                     "ORDER BY b.book_id DESC";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                books.add(mapBook(rs));
            }
        } catch (SQLException e) {
            System.err.println("[BookDAO.getAllBooks Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return books;
    }

    /**
     * Retrieves featured books for the home page showcase.
     */
    public List<Book> getFeaturedBooks() {
        List<Book> books = new ArrayList<>();
        String sql = "SELECT b.*, c.category_name FROM `books` b " +
                     "JOIN `categories` c ON b.category_id = c.category_id " +
                     "WHERE b.featured = 1 ORDER BY b.book_id DESC LIMIT 8";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                books.add(mapBook(rs));
            }
        } catch (SQLException e) {
            System.err.println("[BookDAO.getFeaturedBooks Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return books;
    }

    /**
     * Retrieves recent books.
     */
    public List<Book> getRecentBooks(int limit) {
        List<Book> books = new ArrayList<>();
        String sql = "SELECT b.*, c.category_name FROM `books` b " +
                     "JOIN `categories` c ON b.category_id = c.category_id " +
                     "ORDER BY b.created_at DESC LIMIT ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, limit);
            rs = ps.executeQuery();
            while (rs.next()) {
                books.add(mapBook(rs));
            }
        } catch (SQLException e) {
            System.err.println("[BookDAO.getRecentBooks Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return books;
    }

    /**
     * Retrieves a book by ID.
     */
    public Book getBookById(int bookId) {
        String sql = "SELECT b.*, c.category_name FROM `books` b " +
                     "JOIN `categories` c ON b.category_id = c.category_id " +
                     "WHERE b.book_id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, bookId);
            rs = ps.executeQuery();
            if (rs.next()) {
                return mapBook(rs);
            }
        } catch (SQLException e) {
            System.err.println("[BookDAO.getBookById Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return null;
    }

    /**
     * Retrieves books by Category ID.
     */
    public List<Book> getBooksByCategory(int categoryId) {
        List<Book> books = new ArrayList<>();
        String sql = "SELECT b.*, c.category_name FROM `books` b " +
                     "JOIN `categories` c ON b.category_id = c.category_id " +
                     "WHERE b.category_id = ? ORDER BY b.book_id DESC";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, categoryId);
            rs = ps.executeQuery();
            while (rs.next()) {
                books.add(mapBook(rs));
            }
        } catch (SQLException e) {
            System.err.println("[BookDAO.getBooksByCategory Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return books;
    }

    /**
     * Search books by keyword matching Title, Author, or ISBN.
     */
    public List<Book> searchBooks(String keyword) {
        List<Book> books = new ArrayList<>();
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllBooks();
        }
        String pattern = "%" + keyword.trim() + "%";
        String sql = "SELECT b.*, c.category_name FROM `books` b " +
                     "JOIN `categories` c ON b.category_id = c.category_id " +
                     "WHERE b.title LIKE ? OR b.author LIKE ? OR b.isbn LIKE ? OR c.category_name LIKE ? " +
                     "ORDER BY b.book_id DESC";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, pattern);
            ps.setString(2, pattern);
            ps.setString(3, pattern);
            ps.setString(4, pattern);
            rs = ps.executeQuery();
            while (rs.next()) {
                books.add(mapBook(rs));
            }
        } catch (SQLException e) {
            System.err.println("[BookDAO.searchBooks Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return books;
    }

    /**
     * Adds a new book to the bookstore.
     */
    public boolean addBook(Book book) {
        String sql = "INSERT INTO `books` (`title`, `author`, `category_id`, `publisher`, `isbn`, `price`, `stock`, `description`, `image_url`, `featured`) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, book.getTitle().trim());
            ps.setString(2, book.getAuthor().trim());
            ps.setInt(3, book.getCategoryId());
            ps.setString(4, book.getPublisher() != null ? book.getPublisher().trim() : "General Publisher");
            ps.setString(5, book.getIsbn().trim());
            ps.setDouble(6, book.getPrice());
            ps.setInt(7, book.getStock());
            ps.setString(8, book.getDescription());
            ps.setString(9, book.getImageUrl());
            ps.setBoolean(10, book.isFeatured());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[BookDAO.addBook Error] " + e.getMessage());
        } finally {
            DBConnection.closeStatement(ps);
            DBConnection.closeConnection(conn);
        }
        return false;
    }

    /**
     * Updates an existing book.
     */
    public boolean updateBook(Book book) {
        String sql = "UPDATE `books` SET `title` = ?, `author` = ?, `category_id` = ?, `publisher` = ?, " +
                     "`isbn` = ?, `price` = ?, `stock` = ?, `description` = ?, `image_url` = ?, `featured` = ? " +
                     "WHERE `book_id` = ?";
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, book.getTitle().trim());
            ps.setString(2, book.getAuthor().trim());
            ps.setInt(3, book.getCategoryId());
            ps.setString(4, book.getPublisher());
            ps.setString(5, book.getIsbn().trim());
            ps.setDouble(6, book.getPrice());
            ps.setInt(7, book.getStock());
            ps.setString(8, book.getDescription());
            ps.setString(9, book.getImageUrl());
            ps.setBoolean(10, book.isFeatured());
            ps.setInt(11, book.getBookId());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[BookDAO.updateBook Error] " + e.getMessage());
        } finally {
            DBConnection.closeStatement(ps);
            DBConnection.closeConnection(conn);
        }
        return false;
    }

    /**
     * Updates only stock and price for quick inventory management.
     */
    public boolean updatePriceAndStock(int bookId, double price, int stock) {
        String sql = "UPDATE `books` SET `price` = ?, `stock` = ? WHERE `book_id` = ?";
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setDouble(1, price);
            ps.setInt(2, stock);
            ps.setInt(3, bookId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[BookDAO.updatePriceAndStock Error] " + e.getMessage());
        } finally {
            DBConnection.closeStatement(ps);
            DBConnection.closeConnection(conn);
        }
        return false;
    }

    /**
     * Updates available stock.
     */
    public boolean updateStock(int bookId, int stock) {
        String sql = "UPDATE `books` SET `stock` = ? WHERE `book_id` = ?";
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, stock);
            ps.setInt(2, bookId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[BookDAO.updateStock Error] " + e.getMessage());
        } finally {
            DBConnection.closeStatement(ps);
            DBConnection.closeConnection(conn);
        }
        return false;
    }

    /**
     * Deletes a book by ID.
     */
    public boolean deleteBook(int bookId) {
        String sql = "DELETE FROM `books` WHERE `book_id` = ?";
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, bookId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[BookDAO.deleteBook Error] " + e.getMessage());
        } finally {
            DBConnection.closeStatement(ps);
            DBConnection.closeConnection(conn);
        }
        return false;
    }

    /**
     * Checks if ISBN already exists (useful for add/edit book validation).
     */
    public boolean isIsbnExists(String isbn, int excludeBookId) {
        String sql = "SELECT 1 FROM `books` WHERE `isbn` = ? AND `book_id` != ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, isbn.trim());
            ps.setInt(2, excludeBookId);
            rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.err.println("[BookDAO.isIsbnExists Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return false;
    }

    /**
     * Retrieves all low-stock books (stock <= 5).
     */
    public List<Book> getLowStockBooks() {
        List<Book> books = new ArrayList<>();
        String sql = "SELECT b.*, c.category_name FROM `books` b " +
                     "JOIN `categories` c ON b.category_id = c.category_id " +
                     "WHERE b.stock <= 5 ORDER BY b.stock ASC";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                books.add(mapBook(rs));
            }
        } catch (SQLException e) {
            System.err.println("[BookDAO.getLowStockBooks Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return books;
    }

    private Book mapBook(ResultSet rs) throws SQLException {
        Book b = new Book();
        b.setBookId(rs.getInt("book_id"));
        b.setTitle(rs.getString("title"));
        b.setAuthor(rs.getString("author"));
        b.setCategoryId(rs.getInt("category_id"));
        try {
            b.setCategoryName(rs.getString("category_name"));
        } catch (SQLException ignored) {}
        b.setPublisher(rs.getString("publisher"));
        b.setIsbn(rs.getString("isbn"));
        b.setPrice(rs.getDouble("price"));
        b.setStock(rs.getInt("stock"));
        b.setDescription(rs.getString("description"));
        b.setImageUrl(rs.getString("image_url"));
        b.setFeatured(rs.getBoolean("featured"));
        b.setCreatedAt(rs.getTimestamp("created_at"));
        return b;
    }
}
