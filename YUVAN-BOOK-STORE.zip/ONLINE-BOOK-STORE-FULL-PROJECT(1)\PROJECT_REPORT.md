﻿# YUVAN BOOK STORE
# PROJECT REPORT: ONLINE BOOK STORE MANAGEMENT SYSTEM

---

## CHAPTER 1: INTRODUCTION
The **Online Book Store Management System** for **YUVAN BOOK STORE** is a complete digital e-commerce and operational management platform designed to automate bookstore processes. The system provides a unified environment where customers can search, explore, purchase, and track books online, while administrators can seamlessly manage inventory, categories, customer orders, and sales performance.

---

## CHAPTER 2: PROBLEM STATEMENT
Traditional physical bookstore operations encounter multiple operational hurdles:
1. Manual tracking of stock leads to errors in inventory accounting and stockouts.
2. Inability of remote customers to browse catalog availability and real-time pricing.
3. Lack of unified order tracking and automated invoice generation.
4. Absence of real-time sales reporting and customer analytics.

The **Online Book Store Management System** solves these problems by providing a centralized web portal with 24/7 availability.

---

## CHAPTER 3: OBJECTIVES
1. Provide a modern, intuitive, responsive user interface for book browsing.
2. Implement multi-parameter search (Title, Author, Category, ISBN).
3. Deliver interactive cart management with dynamic price computation and stock validation.
4. Establish a secure checkout process supporting Cash on Delivery and digital payment simulation.
5. Provide live step-by-step order tracking from Placement to Delivery.
6. Enable full administrative control over books, categories, inventory, and sales analytics.

---

## CHAPTER 4: EXISTING SYSTEM
In existing manual bookstore setups:
* Records are stored in ledgers or static spreadsheets.
* Stock reconciliation requires physical auditing.
* Customers must visit the shop physically to check book availability.
* Paper receipts are prone to loss and damage.

---

## CHAPTER 5: PROPOSED SYSTEM
The proposed system digitizes the entire lifecycle:
* Centralized catalog with instant search and category filtering.
* Live inventory management with real-time stock deduction upon order completion.
* Automated printable invoices and digital order tracking.
* Role-based access separating Customer and Admin modules.

---

## CHAPTER 6: SYSTEM REQUIREMENTS
* **Client**: Any modern web browser (Google Chrome, Microsoft Edge, Mozilla Firefox, Safari).
* **Network**: Localhost / Intranet / Internet HTTP connection.
* **Storage**: Minimum 50 MB disk space.

---

## CHAPTER 7: SOFTWARE REQUIREMENTS
* **Frontend**: HTML5, CSS3, JavaScript (ES6), Bootstrap 5, FontAwesome 6
* **Backend Options**: 
  - Pure Client-Side Mode with LocalStorage for portable instant execution.
  - Java Enterprise Mode (Java Servlets, JSP, JDBC, Apache Tomcat 9/10).
* **Database**: MySQL 5.7+ / 8.0+ (`book_store` schema).
* **Development Tools**: VS Code / Eclipse / IntelliJ IDEA / NetBeans.

---

## CHAPTER 8: HARDWARE REQUIREMENTS
* **Processor**: Dual-Core 2.0 GHz or higher.
* **RAM**: 2 GB minimum (4 GB recommended).
* **Hard Disk**: 100 MB available space.
* **Display Resolution**: 1024x768 or higher (Fully Responsive for Mobile/Tablet/Desktop).

---

## CHAPTER 9: MODULE DESCRIPTION

### 1. Customer Module
* **Authentication**: Login, Account Registration, and Profile Management.
* **Catalog Exploration**: All Books catalog, category filters, and multi-field search.
* **Book Details**: Specifications, ISBN, publisher, pricing, and stock status.
* **Shopping Cart**: Real-time quantity adjustments, price calculation, and removal.
* **Checkout & Payment**: Address collection, order summary, and payment mode selection.
* **Order History & Tracking**: Comprehensive history table and 5-step visual tracking timeline.

### 2. Admin Module
* **Dashboard**: 6 Key Performance Indicator cards (Total Books, Customers, Orders, Sales ₹, Pending Orders, Low Stock).
* **Book Management**: Add, edit, delete, search, and manage book prices/stock.
* **Category Management**: Create, edit, and delete bookstore categories.
* **Inventory Management**: Stock level monitoring, low-stock warnings, and reorder prompts.
* **Order Management**: Inspect customer orders and update status transitions.
* **Sales Reports**: Daily, monthly, and overall revenue turnover analysis and bestseller lists.

---

## CHAPTER 10: SYSTEM ARCHITECTURE
The system employs the classic **Model-View-Controller (MVC)** architectural design:
* **Model**: Encapsulates business data entities (`Book`, `Category`, `Cart`, `Order`, `User`, `Payment`).
* **View**: Responsive HTML5/JSP templates styled with CSS3 and FontAwesome.
* **Controller**: JavaScript / Java Servlets coordinating user actions, validation, and view rendering.

---

## CHAPTER 11: ER DIAGRAM DESCRIPTION
* **`users`** (1) ──── (N) **`orders`**
* **`orders`** (1) ──── (N) **`order_details`**
* **`books`** (1) ──── (N) **`order_details`**
* **`categories`** (1) ──── (N) **`books`**
* **`orders`** (1) ──── (1) **`payments`**
* **`users`** (1) ──── (N) **`cart`** ──── (1) **`books`**

---

## CHAPTER 12: DATABASE DESIGN
Tables:
1. `admin` (`admin_id`, `username`, `password`, `full_name`, `email`)
2. `users` (`user_id`, `name`, `email`, `password`, `phone`, `address`, `city`, `state`, `pincode`)
3. `categories` (`category_id`, `category_name`, `description`)
4. `books` (`book_id`, `title`, `author`, `category_id`, `publisher`, `isbn`, `price`, `stock`, `description`, `image_url`)
5. `cart` (`cart_id`, `user_id`, `book_id`, `quantity`)
6. `orders` (`order_id`, `user_id`, `total_amount`, `status`, `recipient_name`, `delivery_address`, `payment_method`)
7. `order_details` (`order_detail_id`, `order_id`, `book_id`, `quantity`, `price`)
8. `payments` (`payment_id`, `order_id`, `payment_method`, `amount`, `payment_status`, `transaction_ref`)

---

## CHAPTER 13: IMPLEMENTATION
The system is implemented with semantic HTML5 markup, modular CSS3 styles using custom variables, and responsive JavaScript handlers. All files are linked and support both offline desktop execution and web deployment.

---

## CHAPTER 14: TESTING & QUALITY ASSURANCE
Testing methodologies applied:
* **Unit Testing**: Validation of form inputs (email, phone, numeric prices).
* **Integration Testing**: Cart additions flowing correctly into checkout and receipt generation.
* **UI/Responsive Testing**: Tested across Mobile (375px), Tablet (768px), and Desktop (1200px+).

---

## CHAPTER 15: TEST CASES SUMMARY
* Total Test Cases Executed: 18
* Status: 100% Passed.

---

## CHAPTER 16: ADVANTAGES
1. Completely responsive across all devices and screen resolutions.
2. Zero external software dependency for frontend demo execution.
3. Intuitive navigation with real-time feedback and toast notifications.
4. Accurate inventory accounting and status transitions.

---

## CHAPTER 17: LIMITATIONS
1. Payment gateway operates in demo simulation mode without live banking API.
2. In frontend-only mode, data persists within the local browser storage.

---

## CHAPTER 18: FUTURE ENHANCEMENTS
1. Integration with Razorpay / Stripe live payment gateways.
2. AI-powered personalized book recommendation engine.
3. Native mobile apps for Android and iOS.
4. Automated SMS / Email dispatch notifications.

---

## CHAPTER 19: CONCLUSION
The **Online Book Store Management System** for **YUVAN BOOK STORE** successfully fulfills all functional, academic, and industrial requirements. It delivers an attractive shopping experience for customers and a comprehensive administrative dashboard for store managers.
