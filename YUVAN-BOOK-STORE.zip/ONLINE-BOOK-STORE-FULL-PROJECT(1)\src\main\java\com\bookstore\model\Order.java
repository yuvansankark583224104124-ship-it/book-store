package com.bookstore.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Model class representing a Customer Order.
 * Company: YUVAN & THIYAGU & CO.
 */
public class Order implements Serializable {
    private static final long serialVersionUID = 1L;

    private int orderId;
    private int userId;
    private String customerName; // Joined auxiliary field
    private String customerEmail; // Joined auxiliary field
    private Timestamp orderDate;
    private double totalAmount;
    private String status;
    private String recipientName;
    private String recipientPhone;
    private String deliveryAddress;
    private String paymentMethod;
    private String paymentStatus; // Joined auxiliary field
    private String transactionRef; // Joined auxiliary field

    private List<OrderDetail> orderDetails = new ArrayList<>();

    public Order() {
    }

    public Order(int orderId, int userId, Timestamp orderDate, double totalAmount, String status, String recipientName, String recipientPhone, String deliveryAddress, String paymentMethod) {
        this.orderId = orderId;
        this.userId = userId;
        this.orderDate = orderDate;
        this.totalAmount = totalAmount;
        this.status = status;
        this.recipientName = recipientName;
        this.recipientPhone = recipientPhone;
        this.deliveryAddress = deliveryAddress;
        this.paymentMethod = paymentMethod;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public Timestamp getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Timestamp orderDate) {
        this.orderDate = orderDate;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRecipientName() {
        return recipientName;
    }

    public void setRecipientName(String recipientName) {
        this.recipientName = recipientName;
    }

    public String getRecipientPhone() {
        return recipientPhone;
    }

    public void setRecipientPhone(String recipientPhone) {
        this.recipientPhone = recipientPhone;
    }

    public String getDeliveryAddress() {
        return deliveryAddress;
    }

    public void setDeliveryAddress(String deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getTransactionRef() {
        return transactionRef;
    }

    public void setTransactionRef(String transactionRef) {
        this.transactionRef = transactionRef;
    }

    public List<OrderDetail> getOrderDetails() {
        return orderDetails;
    }

    public void setOrderDetails(List<OrderDetail> orderDetails) {
        this.orderDetails = orderDetails;
    }

    public String getFormattedTotalAmount() {
        return String.format("₹%.2f", totalAmount);
    }

    public String getFormattedDate() {
        if (orderDate == null) return "";
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy, hh:mm a");
        return sdf.format(orderDate);
    }

    public String getStatusBadgeClass() {
        if (status == null) return "bg-secondary";
        switch (status.toUpperCase()) {
            case "PLACED":
                return "bg-primary";
            case "CONFIRMED":
                return "bg-info text-dark";
            case "SHIPPED":
                return "bg-warning text-dark";
            case "OUT FOR DELIVERY":
                return "bg-primary text-light";
            case "DELIVERED":
                return "bg-success";
            case "CANCELLED":
                return "bg-danger";
            default:
                return "bg-secondary";
        }
    }

    public int getStatusStep() {
        if (status == null) return 1;
        switch (status.toUpperCase()) {
            case "PLACED":
                return 1;
            case "CONFIRMED":
                return 2;
            case "SHIPPED":
                return 3;
            case "OUT FOR DELIVERY":
                return 4;
            case "DELIVERED":
                return 5;
            case "CANCELLED":
                return -1;
            default:
                return 1;
        }
    }
}
