package com.bookstore.model;

import java.io.Serializable;

/**
 * Model representing an enriched item in the customer shopping cart.
 * Combines Cart entity with Book details for presentation.
 * Company: YUVAN & PRASUN & CO.
 */
public class CartItem implements Serializable {
    private static final long serialVersionUID = 1L;

    private int cartId;
    private int userId;
    private int bookId;
    private String bookTitle;
    private String bookAuthor;
    private String categoryName;
    private String isbn;
    private String imageUrl;
    private double price;
    private int stock;
    private int quantity;
    private double subtotal;

    public CartItem() {
    }

    public CartItem(int cartId, int userId, int bookId, String bookTitle, String bookAuthor, String categoryName, String isbn, String imageUrl, double price, int stock, int quantity) {
        this.cartId = cartId;
        this.userId = userId;
        this.bookId = bookId;
        this.bookTitle = bookTitle;
        this.bookAuthor = bookAuthor;
        this.categoryName = categoryName;
        this.isbn = isbn;
        this.imageUrl = imageUrl;
        this.price = price;
        this.stock = stock;
        this.quantity = quantity;
        this.subtotal = price * quantity;
    }

    public int getCartId() {
        return cartId;
    }

    public void setCartId(int cartId) {
        this.cartId = cartId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public String getBookAuthor() {
        return bookAuthor;
    }

    public void setBookAuthor(String bookAuthor) {
        this.bookAuthor = bookAuthor;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getImageUrl() {
        if (imageUrl == null || imageUrl.trim().isEmpty()) {
            return "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400&q=80";
        }
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
        this.subtotal = this.price * this.quantity;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
        this.subtotal = this.price * this.quantity;
    }

    public double getSubtotal() {
        return price * quantity;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public String getFormattedPrice() {
        return String.format("₹%.2f", price);
    }

    public String getFormattedSubtotal() {
        return String.format("₹%.2f", getSubtotal());
    }

    public boolean isExceedsStock() {
        return quantity > stock;
    }
}
