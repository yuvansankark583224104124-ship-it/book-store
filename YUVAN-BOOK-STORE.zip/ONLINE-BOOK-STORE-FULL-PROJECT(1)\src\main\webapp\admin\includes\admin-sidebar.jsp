<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<aside class="admin-sidebar shadow">
    <a href="${pageContext.request.contextPath}/admin/dashboard" class="admin-sidebar-brand">
        <i class="fa-solid fa-shield-halved text-warning fs-4"></i>
        <span>YUVAN &amp; PRASUN</span>
    </a>

    <ul class="admin-sidebar-menu">
        <li class="admin-sidebar-item">
            <a href="${pageContext.request.contextPath}/admin/dashboard" class="admin-sidebar-link ${param.activeNav == 'dashboard' ? 'active' : ''}">
                <i class="fa-solid fa-gauge-high"></i>
                <span>Dashboard</span>
            </a>
        </li>
        <li class="admin-sidebar-item">
            <a href="${pageContext.request.contextPath}/admin/books" class="admin-sidebar-link ${param.activeNav == 'books' ? 'active' : ''}">
                <i class="fa-solid fa-book"></i>
                <span>Manage Books</span>
            </a>
        </li>
        <li class="admin-sidebar-item">
            <a href="${pageContext.request.contextPath}/admin/add-book" class="admin-sidebar-link ${param.activeNav == 'add-book' ? 'active' : ''}">
                <i class="fa-solid fa-circle-plus"></i>
                <span>Add New Book</span>
            </a>
        </li>
        <li class="admin-sidebar-item">
            <a href="${pageContext.request.contextPath}/admin/categories" class="admin-sidebar-link ${param.activeNav == 'categories' ? 'active' : ''}">
                <i class="fa-solid fa-layer-group"></i>
                <span>Categories</span>
            </a>
        </li>
        <li class="admin-sidebar-item">
            <a href="${pageContext.request.contextPath}/admin/inventory" class="admin-sidebar-link ${param.activeNav == 'inventory' ? 'active' : ''}">
                <i class="fa-solid fa-boxes-stacked"></i>
                <span>Inventory &amp; Stock</span>
            </a>
        </li>
        <li class="admin-sidebar-item">
            <a href="${pageContext.request.contextPath}/admin/orders" class="admin-sidebar-link ${param.activeNav == 'orders' ? 'active' : ''}">
                <i class="fa-solid fa-cart-flatbed"></i>
                <span>Customer Orders</span>
            </a>
        </li>
        <li class="admin-sidebar-item">
            <a href="${pageContext.request.contextPath}/admin/reports" class="admin-sidebar-link ${param.activeNav == 'reports' ? 'active' : ''}">
                <i class="fa-solid fa-chart-line"></i>
                <span>Sales Reports</span>
            </a>
        </li>

        <li class="admin-sidebar-item mt-4 pt-3 border-top border-secondary">
            <a href="${pageContext.request.contextPath}/home" class="admin-sidebar-link text-info" target="_blank">
                <i class="fa-solid fa-arrow-up-right-from-square"></i>
                <span>Visit Storefront</span>
            </a>
        </li>
        <li class="admin-sidebar-item">
            <a href="${pageContext.request.contextPath}/admin-logout" class="admin-sidebar-link text-danger">
                <i class="fa-solid fa-right-from-bracket"></i>
                <span>Admin Logout</span>
            </a>
        </li>
    </ul>
</aside>
