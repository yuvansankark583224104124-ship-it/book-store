package com.bookstore.servlet;

import com.bookstore.dao.OrderDAO;
import com.bookstore.dao.UserDAO;
import com.bookstore.model.Order;
import com.bookstore.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * Controller servlet for Customer Profile view, update, and order summary.
 * Company: YUVAN & THIYAGU & CO.
 */
@WebServlet(name = "UserProfileServlet", urlPatterns = {"/profile"})
public class UserProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final UserDAO userDAO = new UserDAO();
    private final OrderDAO orderDAO = new OrderDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User loggedUser = (User) session.getAttribute("loggedUser");

        if (loggedUser == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        // Fetch fresh details
        User freshUser = userDAO.getUserById(loggedUser.getUserId());
        if (freshUser != null) {
            session.setAttribute("loggedUser", freshUser);
            loggedUser = freshUser;
        }

        List<Order> recentOrders = orderDAO.getOrdersByUser(loggedUser.getUserId());
        request.setAttribute("recentOrders", recentOrders);
        request.setAttribute("user", loggedUser);

        request.getRequestDispatcher("/profile.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User loggedUser = (User) session.getAttribute("loggedUser");

        if (loggedUser == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String action = request.getParameter("action");

        if ("updatePassword".equals(action)) {
            String currentPassword = request.getParameter("currentPassword");
            String newPassword = request.getParameter("newPassword");
            String confirmPassword = request.getParameter("confirmPassword");

            User verify = userDAO.login(loggedUser.getEmail(), currentPassword);
            if (verify == null) {
                session.setAttribute("errorMsg", "Current password is incorrect.");
            } else if (newPassword == null || newPassword.length() < 6) {
                session.setAttribute("errorMsg", "New password must be at least 6 characters.");
            } else if (!newPassword.equals(confirmPassword)) {
                session.setAttribute("errorMsg", "New passwords do not match.");
            } else {
                boolean changed = userDAO.changePassword(loggedUser.getUserId(), newPassword);
                if (changed) {
                    session.setAttribute("successMsg", "Password updated successfully!");
                } else {
                    session.setAttribute("errorMsg", "Failed to update password.");
                }
            }
        } else {
            // Update Profile details
            String name = request.getParameter("name");
            String phone = request.getParameter("phone");
            String address = request.getParameter("address");
            String city = request.getParameter("city");
            String state = request.getParameter("state");
            String pincode = request.getParameter("pincode");

            if (name == null || name.trim().isEmpty() || phone == null || phone.trim().isEmpty()) {
                session.setAttribute("errorMsg", "Name and Phone cannot be empty.");
            } else {
                User updated = new User(name.trim(), loggedUser.getEmail(), null, phone.trim(),
                                        address != null ? address.trim() : "",
                                        city != null ? city.trim() : "",
                                        state != null ? state.trim() : "",
                                        pincode != null ? pincode.trim() : "");
                updated.setUserId(loggedUser.getUserId());

                boolean success = userDAO.updateProfile(updated);
                if (success) {
                    User fresh = userDAO.getUserById(loggedUser.getUserId());
                    session.setAttribute("loggedUser", fresh);
                    session.setAttribute("successMsg", "Profile details updated successfully!");
                } else {
                    session.setAttribute("errorMsg", "Failed to update profile.");
                }
            }
        }

        response.sendRedirect(request.getContextPath() + "/profile");
    }
}
