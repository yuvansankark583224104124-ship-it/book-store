﻿/**
 * YUVAN BOOK STORE - ONLINE BOOK STORE MANAGEMENT SYSTEM
 * Customer Frontend Interactive JavaScript
 */

document.addEventListener('DOMContentLoaded', function () {
    // 1. Auto-dismiss alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(function (alert) {
        setTimeout(function () {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // 2. Quantity Selector in Book Details
    const qtyInput = document.getElementById('bookDetailQty');
    const btnMinus = document.getElementById('btnQtyMinus');
    const btnPlus = document.getElementById('btnQtyPlus');
    const maxStockEl = document.getElementById('availableStockValue');

    if (qtyInput && btnMinus && btnPlus && maxStockEl) {
        const maxStock = parseInt(maxStockEl.value, 10) || 1;

        btnMinus.addEventListener('click', function () {
            let current = parseInt(qtyInput.value, 10) || 1;
            if (current > 1) {
                qtyInput.value = current - 1;
            }
        });

        btnPlus.addEventListener('click', function () {
            let current = parseInt(qtyInput.value, 10) || 1;
            if (current < maxStock) {
                qtyInput.value = current + 1;
            } else {
                alert('Maximum available stock is ' + maxStock + ' units.');
            }
        });

        qtyInput.addEventListener('change', function () {
            let val = parseInt(qtyInput.value, 10);
            if (isNaN(val) || val < 1) {
                qtyInput.value = 1;
            } else if (val > maxStock) {
                alert('Requested quantity exceeds available stock (' + maxStock + '). Set to maximum.');
                qtyInput.value = maxStock;
            }
        });
    }

    // 3. Checkout Form validation and Payment Method Selection
    const checkoutForm = document.getElementById('checkoutForm');
    const onlinePaymentDemo = document.getElementById('payOnlineDemo');
    const codPayment = document.getElementById('payCOD');
    const demoCardFields = document.getElementById('demoCardFields');

    if (onlinePaymentDemo && codPayment && demoCardFields) {
        function togglePaymentFields() {
            if (onlinePaymentDemo.checked) {
                demoCardFields.style.display = 'block';
            } else {
                demoCardFields.style.display = 'none';
            }
        }
        onlinePaymentDemo.addEventListener('change', togglePaymentFields);
        codPayment.addEventListener('change', togglePaymentFields);
        togglePaymentFields();
    }

    if (checkoutForm) {
        checkoutForm.addEventListener('submit', function (e) {
            const phone = document.getElementById('recipientPhone');
            if (phone && phone.value.trim().length < 10) {
                alert('Please enter a valid 10-digit mobile number.');
                e.preventDefault();
                phone.focus();
            }
        });
    }
});
