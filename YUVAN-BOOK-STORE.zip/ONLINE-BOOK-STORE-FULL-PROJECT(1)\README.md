﻿# YUVAN BOOK STORE
## ONLINE BOOK STORE MANAGEMENT SYSTEM (FRONTEND PROJECT)

A complete, responsive, and modern **Online Book Store Management System** frontend web application developed for **YUVAN BOOK STORE** using **HTML5, CSS3, and JavaScript**.

---

## 🌟 Project Overview

This project provides a centralized, digitized online platform for bookstore operations. It allows customers to browse, search, purchase, and track books with real-time cart calculations and order workflows. It also provides bookstore administrators with an interactive dashboard to manage books, categories, inventory, customer orders, and sales reports.

---

## 📂 Project Directory Structure

```text
c:\Users\NPRCSELAB-1\Desktop\book project\
│
├── index.html                  (Home Page with Hero & Featured Books)
├── login.html                  (Customer Login Page)
├── register.html               (Customer Account Registration)
├── books.html                  (Catalog with Search & Category Filters)
├── book-details.html           (Detailed Single Book View & Specs)
├── categories.html             (All 8 Book Categories Showcase)
├── cart.html                   (Interactive Shopping Cart with Totals)
├── checkout.html               (Order Placement & Payment Selection)
├── order-confirmation.html     (Order Confirmation Receipt)
├── orders.html                 (Customer Order History)
├── track-order.html            (Visual Step-by-Step Order Tracker)
├── about.html                  (About Yuvan Book Store)
├── contact.html                (Contact Desk & Feedback Form)
│
├── admin-login.html            (Administrator Authentication)
├── admin-dashboard.html        (6 KPI Metrics & Quick Actions)
├── admin-books.html            (Manage, Search, and Delete Books)
├── add-book.html               (Add New Book to Catalog)
├── edit-book.html              (Modify Existing Book Details)
├── admin-categories.html       (Category Management System)
├── admin-inventory.html        (Live Stock Levels & Low-Stock Alerts)
├── admin-orders.html           (Customer Orders & Status Transitions)
├── admin-reports.html          (Sales Turnover & Bestseller Analytics)
│
├── css/
│   └── style.css               (Universal Modern CSS3 Stylesheet)
│
├── js/
│   └── script.js               (Cart, LocalStorage, Search & Dynamic UI)
│
└── README.md                   (Running Instructions & Documentation)
```

---

## 🚀 How to Run the Project

1. **No server or database installation is required** — this is a pure, portable frontend application.
2. Locate the project folder on your computer:
   ```text
   c:\Users\NPRCSELAB-1\Desktop\book project\
   ```
3. **Double-click `index.html`** or right-click `index.html` and choose **"Open with Google Chrome" / "Open with Microsoft Edge" / "Open with Firefox"**.
4. The website will immediately load and is 100% interactive!

---

## 🔑 Demo Login Credentials

### Customer Login
* **URL**: `login.html`
* **Email**: `karthik@example.com`
* **Password**: `user123`

### Administrator Login
* **URL**: `admin-login.html`
* **Username**: `admin`
* **Password**: `admin123`

---

## ✨ Features Included

### 1. Customer Experience
* **Home Page**: Modern brand header, hero banner, quick search bar, value features, popular categories, and bestselling book cards.
* **Catalog & Search (`books.html`)**: Real-time keyword search across Title, Author, Category, and ISBN, plus instant genre filtering.
* **Book Details (`book-details.html`)**: Book specifications, publisher, ISBN, rating, stock status, quantity chooser (+/-), and Add to Cart / Buy Now.
* **Interactive Cart (`cart.html`)**: Add items, increase/decrease quantities, remove items, free shipping threshold (over ₹1,000), and dynamic total calculation saved via `localStorage`.
* **Checkout (`checkout.html`)**: Customer address details, live order summary, and payment radio buttons (Cash on Delivery, UPI Instant, Debit/Credit Card).
* **Order Confirmation (`order-confirmation.html`)**: Generates Order ID (`YTC1001`), displays customer address, payment mode, total amount, and printable receipt.
* **Order History & Tracking (`orders.html` & `track-order.html`)**: Visual CSS timeline tracker: `PLACED` → `CONFIRMED` → `SHIPPED` → `OUT FOR DELIVERY` → `DELIVERED`.

### 2. Admin Management Portal
* **Dashboard (`admin-dashboard.html`)**: 6 KPI cards (Total Books: 120, Customers: 450, Total Orders: 320, Total Sales: ₹2,50,000, Pending: 25, Low Stock: 10).
* **Book Management (`admin-books.html`, `add-book.html`, `edit-book.html`)**: Book data table, instant filter, deletion confirmation, and add/edit forms.
* **Category Management (`admin-categories.html`)**: Manage 8 distinct bookstore categories with book counts and modal actions.
* **Inventory Management (`admin-inventory.html`)**: Live stock status indicators (`IN STOCK`, `LOW STOCK`, `OUT OF STOCK`) and quick stock updater.
* **Orders Management (`admin-orders.html`)**: View customer order lines and change fulfillment statuses.
* **Sales Reports (`admin-reports.html`)**: Daily sales (₹4,850), Monthly sales (₹85,000), Total revenue (₹2,50,000), bestsellers table, and category distribution.

---

## 💻 Technologies Used
* **HTML5**: Semantic tags (`<header>`, `<nav>`, `<main>`, `<section>`, `<aside>`, `<footer>`, `<form>`, `<table>`).
* **CSS3**: Custom properties / variables, Flexbox, CSS Grid, Hover effects, Responsive media queries, Badges, and Stepper Timeline.
* **JavaScript**: Vanilla JS for `localStorage` shopping cart, dynamic search filtering, quantity increments, toast alerts, and navigation toggles.
* **FontAwesome 6**: Modern iconography.

---

&copy; 2026 **YUVAN BOOK STORE** All Rights Reserved.
