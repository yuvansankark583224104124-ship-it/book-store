package com.bookstore.util;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Utility for date/time conversions, invoice numbering, and report formatting.
 * Company: YUVAN & THIYAGU & CO.
 */
public class DateUtil {

    private DateUtil() {
    }

    public static String formatTimestamp(Timestamp ts) {
        if (ts == null) return "N/A";
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy, hh:mm a");
        return sdf.format(ts);
    }

    public static String formatDateOnly(Date date) {
        if (date == null) return "N/A";
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy");
        return sdf.format(date);
    }

    public static String generateInvoiceNumber(int orderId) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        String datePart = sdf.format(new Date());
        return "INV-YTC-" + datePart + "-" + String.format("%05d", orderId);
    }

    public static String generateTransactionReference() {
        long time = System.currentTimeMillis();
        int random = (int) (Math.random() * 9000) + 1000;
        return "TXN-YTC-" + time + "-" + random;
    }
}
