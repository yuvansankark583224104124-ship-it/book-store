package com.bookstore.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Utility class for password handling and hashing.
 * Company: YUVAN & THIYAGU & CO.
 */
public class PasswordUtil {

    private PasswordUtil() {
    }

    /**
     * Hashes a plain-text password using SHA-256 algorithm.
     * @param plainTextPassword the plain text password
     * @return hex encoded SHA-256 hash string
     */
    public static String hashPassword(String plainTextPassword) {
        if (plainTextPassword == null) {
            return null;
        }
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(plainTextPassword.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            System.err.println("[PasswordUtil] SHA-256 algorithm unavailable: " + e.getMessage());
            return plainTextPassword; // Fallback
        }
    }

    /**
     * Verifies if input password matches stored password.
     * Supports both direct match (for initial seed demo passwords like admin123) and SHA-256 hash matching.
     * @param inputPassword plain text password input
     * @param storedPassword stored password (plain or hashed)
     * @return true if valid, false otherwise
     */
    public static boolean checkPassword(String inputPassword, String storedPassword) {
        if (inputPassword == null || storedPassword == null) {
            return false;
        }
        // Direct match
        if (inputPassword.equals(storedPassword)) {
            return true;
        }
        // Hash match
        String hashedInput = hashPassword(inputPassword);
        return hashedInput != null && hashedInput.equalsIgnoreCase(storedPassword);
    }
}
