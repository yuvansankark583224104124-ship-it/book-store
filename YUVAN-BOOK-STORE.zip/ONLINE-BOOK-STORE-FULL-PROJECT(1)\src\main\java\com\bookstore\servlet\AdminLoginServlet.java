package com.bookstore.servlet;

import com.bookstore.dao.AdminDAO;
import com.bookstore.model.Admin;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Controller servlet for Administrator authentication and session creation.
 * Company: YUVAN & THIYAGU & CO.
 */
@WebServlet(name = "AdminLoginServlet", urlPatterns = {"/admin-login", "/admin/login"})
public class AdminLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final AdminDAO adminDAO = new AdminDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("adminUser") != null) {
            response.sendRedirect(request.getContextPath() + "/admin/dashboard");
            return;
        }
        request.getRequestDispatcher("/admin/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if (username == null || username.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            request.setAttribute("errorMsg", "Please enter both administrator username and password.");
            request.getRequestDispatcher("/admin/login.jsp").forward(request, response);
            return;
        }

        Admin admin = adminDAO.login(username.trim(), password);

        if (admin != null) {
            HttpSession session = request.getSession(true);
            session.setAttribute("adminUser", admin);
            session.setAttribute("successMsg", "Welcome back, " + admin.getFullName() + "!");
            response.sendRedirect(request.getContextPath() + "/admin/dashboard");
        } else {
            request.setAttribute("errorMsg", "Invalid Admin credentials. Access denied.");
            request.setAttribute("username", username);
            request.getRequestDispatcher("/admin/login.jsp").forward(request, response);
        }
    }
}
