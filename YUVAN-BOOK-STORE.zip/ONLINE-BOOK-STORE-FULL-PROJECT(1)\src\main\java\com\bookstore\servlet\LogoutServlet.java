package com.bookstore.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Controller servlet for Customer Logout.
 * Company: YUVAN & THIYAGU & CO.
 */
@WebServlet(name = "LogoutServlet", urlPatterns = {"/logout"})
public class LogoutServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.removeAttribute("loggedUser");
            session.removeAttribute("cartCount");
            session.invalidate();
        }
        HttpSession newSession = request.getSession(true);
        newSession.setAttribute("successMsg", "You have been logged out successfully.");
        response.sendRedirect(request.getContextPath() + "/login.jsp");
    }
}
