<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<c:set var="pageTitle" value="Explore Books | YUVAN & THIYAGU & CO." scope="request"/>
<jsp:include page="/includes/header.jsp" />
<jsp:include page="/includes/navbar.jsp" />

<main class="py-5 bg-light">
    <div class="container">
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="${pageContext.request.contextPath}/home" class="text-decoration-none">Home</a></li>
                <li class="breadcrumb-item"><a href="${pageContext.request.contextPath}/books" class="text-decoration-none">Books</a></li>
                <c:if test="${not empty activeCategory}">
                    <li class="breadcrumb-item active" aria-current="page">${activeCategory.categoryName}</li>
                </c:if>
            </ol>
        </nav>

        <jsp:include page="/includes/alerts.jsp" />

        <div class="row g-4">
            <!-- Sidebar Filters -->
            <div class="col-lg-3">
                <div class="card border-0 shadow-sm rounded-4 p-4 sticky-lg-top" style="top: 85px; z-index: 10;">
                    <h5 class="fw-bold text-dark mb-3"><i class="fa-solid fa-filter text-primary me-2"></i> Categories</h5>
                    <div class="list-group list-group-flush">
                        <a href="${pageContext.request.contextPath}/books" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center py-2 px-0 border-0 ${empty activeCategory ? 'fw-bold text-primary' : 'text-secondary'}">
                            <span><i class="fa-solid fa-border-all me-2"></i> All Categories</span>
                        </a>
                        <c:forEach var="cat" items="${categories}">
                            <a href="${pageContext.request.contextPath}/books?category=${cat.categoryId}" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center py-2 px-0 border-0 ${activeCategory.categoryId == cat.categoryId ? 'fw-bold text-primary' : 'text-secondary'}">
                                <span><i class="fa-solid fa-angle-right me-2 text-muted"></i> ${cat.categoryName}</span>
                                <span class="badge bg-light text-muted border rounded-pill">${cat.bookCount}</span>
                            </a>
                        </c:forEach>
                    </div>
                </div>
            </div>

            <!-- Book Catalog Grid -->
            <div class="col-lg-9">
                <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
                    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
                        <div>
                            <h4 class="fw-bold text-dark mb-1">
                                <c:choose>
                                    <c:when test="${not empty activeCategory}">
                                        ${activeCategory.categoryName} Books
                                    </c:when>
                                    <c:otherwise>
                                        All Books Catalog
                                    </c:otherwise>
                                </c:choose>
                            </h4>
                            <p class="text-muted small mb-0">Showing <strong>${books.size()}</strong> titles available in stock</p>
                        </div>
                    </div>
                </div>

                <c:choose>
                    <c:when test="${not empty books}">
                        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-4">
                            <c:forEach var="book" items="${books}">
                                <div class="col">
                                    <div class="book-card">
                                        <div class="img-container">
                                            <span class="book-badge-category">${book.categoryName}</span>
                                            <img src="${book.imageUrl}" alt="${book.title}" class="book-img" loading="lazy">
                                        </div>
                                        <div class="card-body">
                                            <h3 class="book-title" title="${book.title}">${book.title}</h3>
                                            <p class="book-author">By <span class="text-dark fw-medium">${book.author}</span></p>
                                            
                                            <div class="d-flex align-items-center justify-content-between mt-auto pt-2 border-top">
                                                <div>
                                                    <div class="book-price">${book.formattedPrice}</div>
                                                    <span class="badge ${book.stockBadgeClass} rounded-pill font-monospace" style="font-size: 0.72rem;">
                                                        ${book.stockStatus}
                                                    </span>
                                                </div>
                                                <div class="d-flex gap-1">
                                                    <a href="${pageContext.request.contextPath}/book-details?id=${book.bookId}" class="btn btn-outline-secondary btn-sm" title="View Details">
                                                        <i class="fa-solid fa-eye"></i>
                                                    </a>
                                                    <c:choose>
                                                        <c:when test="${book.stock > 0}">
                                                            <form action="${pageContext.request.contextPath}/cart/add" method="post" class="d-inline">
                                                                <input type="hidden" name="bookId" value="${book.bookId}">
                                                                <input type="hidden" name="quantity" value="1">
                                                                <button type="submit" class="btn btn-primary btn-sm" title="Add to Cart">
                                                                    <i class="fa-solid fa-cart-plus me-1"></i> Add
                                                                </button>
                                                            </form>
                                                        </c:when>
                                                        <c:otherwise>
                                                            <button class="btn btn-secondary btn-sm" disabled>Sold Out</button>
                                                        </c:otherwise>
                                                    </c:choose>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </c:forEach>
                        </div>
                    </c:when>
                    <c:otherwise>
                        <div class="card border-0 shadow-sm rounded-4 p-5 text-center">
                            <i class="fa-solid fa-book-bookmark fs-1 text-muted mb-3"></i>
                            <h4 class="fw-bold text-dark">No Books Found</h4>
                            <p class="text-muted">There are no books currently listed in this category.</p>
                            <div>
                                <a href="${pageContext.request.contextPath}/books" class="btn btn-primary btn-sm px-4">Browse All Books</a>
                            </div>
                        </div>
                    </c:otherwise>
                </c:choose>
            </div>
        </div>
    </div>
</main>

<jsp:include page="/includes/footer.jsp" />
