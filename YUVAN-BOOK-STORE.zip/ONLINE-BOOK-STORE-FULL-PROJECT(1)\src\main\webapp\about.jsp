<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<c:set var="pageTitle" value="About Us | YUVAN & THIYAGU & CO." scope="request"/>
<jsp:include page="/includes/header.jsp" />
<jsp:include page="/includes/navbar.jsp" />

<main class="py-5 bg-light">
    <div class="container">
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="${pageContext.request.contextPath}/home" class="text-decoration-none">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">About Us</li>
            </ol>
        </nav>

        <div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-5">
            <div class="card-body p-4 p-md-5">
                <div class="row align-items-center g-5">
                    <div class="col-lg-6">
                        <span class="badge bg-primary-subtle text-primary px-3 py-2 rounded-pill fw-bold text-uppercase mb-3">Our Legacy &amp; Vision</span>
                        <h1 class="display-6 fw-bold text-dark mb-3">YUVAN &amp; THIYAGU &amp; CO.</h1>
                        <p class="lead text-muted">
                            Empowering knowledge seekers, students, researchers, and book lovers across the nation with a rich and seamless book-buying experience.
                        </p>
                        <p class="text-secondary">
                            Established with the mission to bridge the gap between avid readers and quality literature, <strong>YUVAN &amp; THIYAGU &amp; CO.</strong> has grown into a premier digital bookstore. We combine the timeless value of physical books with modern, responsive e-commerce convenience.
                        </p>
                        <p class="text-secondary">
                            Whether you are searching for high-level computer science reference volumes, gripping literary fiction, inspiring biographies, or academic engineering textbooks, our catalog is meticulously maintained and updated daily.
                        </p>
                    </div>
                    <div class="col-lg-6 text-center">
                        <img src="https://images.unsplash.com/photo-1521587760476-6c12a4b040da?w=600&q=80" alt="Bookstore Library" class="img-fluid rounded-4 shadow">
                    </div>
                </div>
            </div>
        </div>

        <!-- Mission & Objectives Grid -->
        <div class="row g-4 mb-5">
            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 h-100 p-4 text-center">
                    <div class="feature-icon mx-auto"><i class="fa-solid fa-bullseye"></i></div>
                    <h4 class="fw-bold">Our Mission</h4>
                    <p class="text-muted small mb-0">
                        To democratize access to education and quality reading by offering an expansive digital catalog with transparent pricing, instant ordering, and dependable delivery.
                    </p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 h-100 p-4 text-center">
                    <div class="feature-icon mx-auto"><i class="fa-solid fa-eye"></i></div>
                    <h4 class="fw-bold">Our Vision</h4>
                    <p class="text-muted small mb-0">
                        To be recognized as South India’s most trusted online literary and academic bookstore, championing lifelong learning and technological innovation in retail.
                    </p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm rounded-4 h-100 p-4 text-center">
                    <div class="feature-icon mx-auto"><i class="fa-solid fa-handshake"></i></div>
                    <h4 class="fw-bold">Core Values</h4>
                    <p class="text-muted small mb-0">
                        Integrity in business, passion for literature, customer satisfaction first, continuous inventory accuracy, and technological excellence.
                    </p>
                </div>
            </div>
        </div>
    </div>
</main>

<jsp:include page="/includes/footer.jsp" />
