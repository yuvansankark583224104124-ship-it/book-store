package com.bookstore.dao;

import com.bookstore.model.Admin;
import com.bookstore.model.Book;
import com.bookstore.model.DashboardStats;
import com.bookstore.model.Order;
import com.bookstore.model.SalesReport;
import com.bookstore.util.DBConnection;
import com.bookstore.util.PasswordUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Data Access Object for Admin authentication, dashboard metrics, and executive reports.
 * Company: YUVAN & THIYAGU & CO.
 */
public class AdminDAO {

    /**
     * Authenticates an administrator by username and password.
     */
    public Admin login(String username, String password) {
        String sql = "SELECT * FROM `admin` WHERE `username` = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            rs = ps.executeQuery();

            if (rs.next()) {
                String storedPassword = rs.getString("password");
                if (PasswordUtil.checkPassword(password, storedPassword)) {
                    Admin admin = new Admin();
                    admin.setAdminId(rs.getInt("admin_id"));
                    admin.setUsername(rs.getString("username"));
                    admin.setFullName(rs.getString("full_name"));
                    admin.setEmail(rs.getString("email"));
                    admin.setCreatedAt(rs.getTimestamp("created_at"));
                    return admin;
                }
            }
        } catch (SQLException e) {
            System.err.println("[AdminDAO.login Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return null;
    }

    /**
     * Retrieves aggregated KPI statistics for the Admin Dashboard.
     */
    public DashboardStats getDashboardStats() {
        DashboardStats stats = new DashboardStats();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();

            // 1. Total Books & Total Stock
            String bookSql = "SELECT COUNT(*) AS total_books, COALESCE(SUM(stock), 0) AS total_stock, " +
                             "SUM(CASE WHEN stock <= 5 THEN 1 ELSE 0 END) AS low_stock_count FROM `books`";
            ps = conn.prepareStatement(bookSql);
            rs = ps.executeQuery();
            if (rs.next()) {
                stats.setTotalBooks(rs.getInt("total_books"));
                stats.setAvailableStock(rs.getInt("total_stock"));
                stats.setLowStockCount(rs.getInt("low_stock_count"));
            }
            DBConnection.closeResultSet(rs);
            DBConnection.closeStatement(ps);

            // 2. Total Customers
            String userSql = "SELECT COUNT(*) AS total_customers FROM `users`";
            ps = conn.prepareStatement(userSql);
            rs = ps.executeQuery();
            if (rs.next()) {
                stats.setTotalCustomers(rs.getInt("total_customers"));
            }
            DBConnection.closeResultSet(rs);
            DBConnection.closeStatement(ps);

            // 3. Total Orders, Total Sales, and Pending Orders
            String orderSql = "SELECT COUNT(*) AS total_orders, " +
                              "COALESCE(SUM(CASE WHEN status != 'CANCELLED' THEN total_amount ELSE 0 END), 0) AS total_sales, " +
                              "SUM(CASE WHEN status = 'PLACED' OR status = 'CONFIRMED' THEN 1 ELSE 0 END) AS pending_orders " +
                              "FROM `orders`";
            ps = conn.prepareStatement(orderSql);
            rs = ps.executeQuery();
            if (rs.next()) {
                stats.setTotalOrders(rs.getInt("total_orders"));
                stats.setTotalSales(rs.getDouble("total_sales"));
                stats.setPendingOrders(rs.getInt("pending_orders"));
            }
            DBConnection.closeResultSet(rs);
            DBConnection.closeStatement(ps);

            // 4. Low stock books (top 5)
            String lowStockSql = "SELECT b.*, c.category_name FROM `books` b " +
                                 "JOIN `categories` c ON b.category_id = c.category_id " +
                                 "WHERE b.stock <= 5 ORDER BY b.stock ASC LIMIT 5";
            ps = conn.prepareStatement(lowStockSql);
            rs = ps.executeQuery();
            List<Book> lowStockBooks = new ArrayList<>();
            while (rs.next()) {
                Book b = new Book();
                b.setBookId(rs.getInt("book_id"));
                b.setTitle(rs.getString("title"));
                b.setAuthor(rs.getString("author"));
                b.setCategoryName(rs.getString("category_name"));
                b.setPrice(rs.getDouble("price"));
                b.setStock(rs.getInt("stock"));
                lowStockBooks.add(b);
            }
            stats.setLowStockBooks(lowStockBooks);
            DBConnection.closeResultSet(rs);
            DBConnection.closeStatement(ps);

            // 5. Best selling books
            String bestSellerSql = "SELECT b.title, b.author, SUM(od.quantity) AS total_sold, SUM(od.quantity * od.price) AS total_revenue " +
                                   "FROM `order_details` od " +
                                   "JOIN `books` b ON od.book_id = b.book_id " +
                                   "JOIN `orders` o ON od.order_id = o.order_id " +
                                   "WHERE o.status != 'CANCELLED' " +
                                   "GROUP BY b.book_id, b.title, b.author " +
                                   "ORDER BY total_sold DESC LIMIT 5";
            ps = conn.prepareStatement(bestSellerSql);
            rs = ps.executeQuery();
            List<Map<String, Object>> bestSellers = new ArrayList<>();
            while (rs.next()) {
                Map<String, Object> map = new HashMap<>();
                map.put("title", rs.getString("title"));
                map.put("author", rs.getString("author"));
                map.put("totalSold", rs.getInt("total_sold"));
                map.put("totalRevenue", rs.getDouble("total_revenue"));
                bestSellers.add(map);
            }
            stats.setBestSellers(bestSellers);

        } catch (SQLException e) {
            System.err.println("[AdminDAO.getDashboardStats Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }

        return stats;
    }

    /**
     * Generates structured Sales Analytics Report.
     */
    public SalesReport getSalesReport() {
        SalesReport report = new SalesReport();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();

            // 1. Overall Revenue, Orders, and Books Sold
            String overallSql = "SELECT COUNT(DISTINCT o.order_id) AS total_orders, " +
                                "COALESCE(SUM(o.total_amount), 0) AS total_revenue, " +
                                "COALESCE(SUM(od.quantity), 0) AS total_books_sold " +
                                "FROM `orders` o " +
                                "LEFT JOIN `order_details` od ON o.order_id = od.order_id " +
                                "WHERE o.status != 'CANCELLED'";
            ps = conn.prepareStatement(overallSql);
            rs = ps.executeQuery();
            if (rs.next()) {
                report.setTotalOrders(rs.getInt("total_orders"));
                report.setTotalRevenue(rs.getDouble("total_revenue"));
                report.setTotalBooksSold(rs.getInt("total_books_sold"));
            }
            DBConnection.closeResultSet(rs);
            DBConnection.closeStatement(ps);

            // 2. Today's Sales
            String dailySql = "SELECT COUNT(*) AS daily_orders, COALESCE(SUM(total_amount), 0) AS daily_revenue " +
                              "FROM `orders` WHERE DATE(order_date) = CURDATE() AND status != 'CANCELLED'";
            ps = conn.prepareStatement(dailySql);
            rs = ps.executeQuery();
            if (rs.next()) {
                report.setDailyOrders(rs.getInt("daily_orders"));
                report.setDailyRevenue(rs.getDouble("daily_revenue"));
            }
            DBConnection.closeResultSet(rs);
            DBConnection.closeStatement(ps);

            // 3. Current Month's Sales
            String monthlySql = "SELECT COUNT(*) AS monthly_orders, COALESCE(SUM(total_amount), 0) AS monthly_revenue " +
                                "FROM `orders` WHERE MONTH(order_date) = MONTH(CURDATE()) AND YEAR(order_date) = YEAR(CURDATE()) AND status != 'CANCELLED'";
            ps = conn.prepareStatement(monthlySql);
            rs = ps.executeQuery();
            if (rs.next()) {
                report.setMonthlyOrders(rs.getInt("monthly_orders"));
                report.setMonthlyRevenue(rs.getDouble("monthly_revenue"));
            }
            DBConnection.closeResultSet(rs);
            DBConnection.closeStatement(ps);

            // 4. Daily Sales Trend (Past 7 days)
            String trendSql = "SELECT DATE_FORMAT(order_date, '%d %b') AS sale_date, " +
                              "COALESCE(SUM(total_amount), 0) AS revenue, COUNT(*) AS orders_count " +
                              "FROM `orders` WHERE status != 'CANCELLED' " +
                              "GROUP BY DATE(order_date), DATE_FORMAT(order_date, '%d %b') " +
                              "ORDER BY DATE(order_date) ASC LIMIT 7";
            ps = conn.prepareStatement(trendSql);
            rs = ps.executeQuery();
            List<Map<String, Object>> dailyTrend = new ArrayList<>();
            while (rs.next()) {
                Map<String, Object> map = new HashMap<>();
                map.put("date", rs.getString("sale_date"));
                map.put("revenue", rs.getDouble("revenue"));
                map.put("orders", rs.getInt("orders_count"));
                dailyTrend.add(map);
            }
            report.setDailySalesTrend(dailyTrend);
            DBConnection.closeResultSet(rs);
            DBConnection.closeStatement(ps);

            // 5. Category-wise sales distribution
            String catSalesSql = "SELECT c.category_name, SUM(od.quantity) AS books_sold, SUM(od.quantity * od.price) AS total_sales " +
                                 "FROM `order_details` od " +
                                 "JOIN `books` b ON od.book_id = b.book_id " +
                                 "JOIN `categories` c ON b.category_id = c.category_id " +
                                 "JOIN `orders` o ON od.order_id = o.order_id " +
                                 "WHERE o.status != 'CANCELLED' " +
                                 "GROUP BY c.category_id, c.category_name " +
                                 "ORDER BY total_sales DESC";
            ps = conn.prepareStatement(catSalesSql);
            rs = ps.executeQuery();
            List<Map<String, Object>> catSales = new ArrayList<>();
            while (rs.next()) {
                Map<String, Object> map = new HashMap<>();
                map.put("category", rs.getString("category_name"));
                map.put("booksSold", rs.getInt("books_sold"));
                map.put("totalSales", rs.getDouble("total_sales"));
                catSales.add(map);
            }
            report.setCategoryWiseSales(catSales);
            DBConnection.closeResultSet(rs);
            DBConnection.closeStatement(ps);

            // 6. Best selling books list
            String bestSellingSql = "SELECT b.book_id, b.title, b.author, c.category_name, b.price, " +
                                    "SUM(od.quantity) AS units_sold, SUM(od.quantity * od.price) AS revenue " +
                                    "FROM `order_details` od " +
                                    "JOIN `books` b ON od.book_id = b.book_id " +
                                    "JOIN `categories` c ON b.category_id = c.category_id " +
                                    "JOIN `orders` o ON od.order_id = o.order_id " +
                                    "WHERE o.status != 'CANCELLED' " +
                                    "GROUP BY b.book_id, b.title, b.author, c.category_name, b.price " +
                                    "ORDER BY units_sold DESC LIMIT 10";
            ps = conn.prepareStatement(bestSellingSql);
            rs = ps.executeQuery();
            List<Map<String, Object>> bestSellers = new ArrayList<>();
            while (rs.next()) {
                Map<String, Object> map = new HashMap<>();
                map.put("bookId", rs.getInt("book_id"));
                map.put("title", rs.getString("title"));
                map.put("author", rs.getString("author"));
                map.put("category", rs.getString("category_name"));
                map.put("price", rs.getDouble("price"));
                map.put("unitsSold", rs.getInt("units_sold"));
                map.put("revenue", rs.getDouble("revenue"));
                bestSellers.add(map);
            }
            report.setBestSellingBooks(bestSellers);

        } catch (SQLException e) {
            System.err.println("[AdminDAO.getSalesReport Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }

        return report;
    }
}
