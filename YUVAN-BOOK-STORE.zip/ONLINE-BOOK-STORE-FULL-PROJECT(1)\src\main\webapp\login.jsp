<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<c:set var="pageTitle" value="Customer Login | YUVAN & THIYAGU & CO." scope="request"/>
<jsp:include page="/includes/header.jsp" />
<jsp:include page="/includes/navbar.jsp" />

<main class="py-5 bg-light d-flex align-items-center">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-5">
                <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
                    <div class="card-header bg-primary text-white text-center py-4" style="background: linear-gradient(135deg, #1e3a8a 0%, #0f172a 100%) !important;">
                        <i class="fa-solid fa-book-open-reader text-warning fs-1 mb-2"></i>
                        <h4 class="fw-bold mb-1">Customer Login</h4>
                        <p class="text-light opacity-75 small mb-0">Sign in to your YUVAN &amp; THIYAGU &amp; CO. account</p>
                    </div>

                    <div class="card-body p-4 p-md-5">
                        <jsp:include page="/includes/alerts.jsp" />

                        <form action="${pageContext.request.contextPath}/login" method="post">
                            <div class="mb-3">
                                <label for="email" class="form-label fw-semibold text-secondary small">Email Address <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0"><i class="fa-solid fa-envelope text-muted"></i></span>
                                    <input type="email" class="form-control border-start-0" id="email" name="email" value="${email}" placeholder="name@example.com" required autofocus>
                                </div>
                            </div>

                            <div class="mb-4">
                                <div class="d-flex justify-content-between align-items-center mb-1">
                                    <label for="password" class="form-label fw-semibold text-secondary small mb-0">Password <span class="text-danger">*</span></label>
                                </div>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0"><i class="fa-solid fa-lock text-muted"></i></span>
                                    <input type="password" class="form-control border-start-0" id="password" name="password" placeholder="Enter your account password" required>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary w-100 py-2 fw-bold shadow-sm">
                                <i class="fa-solid fa-right-to-bracket me-2"></i> Sign In
                            </button>
                        </form>

                        <div class="text-center mt-4 pt-3 border-top">
                            <p class="text-muted small mb-2">
                                New to YUVAN &amp; THIYAGU &amp; CO.? 
                                <a href="${pageContext.request.contextPath}/register.jsp" class="text-primary fw-bold text-decoration-none">Create an Account</a>
                            </p>
                            <p class="text-muted small mb-0">
                                Bookstore Staff / Administrator? 
                                <a href="${pageContext.request.contextPath}/admin/login.jsp" class="text-warning fw-bold text-decoration-none">
                                    <i class="fa-solid fa-user-shield me-1"></i> Admin Portal
                                </a>
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Demo Credentials Box -->
                <div class="card mt-3 border-0 bg-white shadow-sm rounded-3">
                    <div class="card-body p-3 text-center small text-muted">
                        <span class="badge bg-secondary-subtle text-secondary me-1">Demo Account</span>
                        Email: <code>karthik@example.com</code> | Password: <code>user123</code>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<jsp:include page="/includes/footer.jsp" />
