package com.bookstore.dao;

import com.bookstore.model.Category;
import com.bookstore.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Book Category management.
 * Company: YUVAN & THIYAGU & CO.
 */
public class CategoryDAO {

    /**
     * Retrieves all categories ordered by name.
     */
    public List<Category> getAllCategories() {
        List<Category> categories = new ArrayList<>();
        String sql = "SELECT * FROM `categories` ORDER BY `category_name` ASC";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                categories.add(mapCategory(rs));
            }
        } catch (SQLException e) {
            System.err.println("[CategoryDAO.getAllCategories Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return categories;
    }

    /**
     * Retrieves all categories along with the count of books in each category.
     */
    public List<Category> getCategoriesWithBookCount() {
        List<Category> categories = new ArrayList<>();
        String sql = "SELECT c.*, COUNT(b.book_id) AS book_count " +
                     "FROM `categories` c " +
                     "LEFT JOIN `books` b ON c.category_id = b.category_id " +
                     "GROUP BY c.category_id, c.category_name, c.description, c.created_at " +
                     "ORDER BY c.category_name ASC";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Category cat = mapCategory(rs);
                cat.setBookCount(rs.getInt("book_count"));
                categories.add(cat);
            }
        } catch (SQLException e) {
            System.err.println("[CategoryDAO.getCategoriesWithBookCount Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return categories;
    }

    /**
     * Retrieves a single category by its primary key ID.
     */
    public Category getCategoryById(int categoryId) {
        String sql = "SELECT * FROM `categories` WHERE `category_id` = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, categoryId);
            rs = ps.executeQuery();
            if (rs.next()) {
                return mapCategory(rs);
            }
        } catch (SQLException e) {
            System.err.println("[CategoryDAO.getCategoryById Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return null;
    }

    /**
     * Adds a new category to the database.
     */
    public boolean addCategory(Category category) {
        String sql = "INSERT INTO `categories` (`category_name`, `description`) VALUES (?, ?)";
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, category.getCategoryName().trim());
            ps.setString(2, category.getDescription());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[CategoryDAO.addCategory Error] " + e.getMessage());
        } finally {
            DBConnection.closeStatement(ps);
            DBConnection.closeConnection(conn);
        }
        return false;
    }

    /**
     * Updates an existing category.
     */
    public boolean updateCategory(Category category) {
        String sql = "UPDATE `categories` SET `category_name` = ?, `description` = ? WHERE `category_id` = ?";
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, category.getCategoryName().trim());
            ps.setString(2, category.getDescription());
            ps.setInt(3, category.getCategoryId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[CategoryDAO.updateCategory Error] " + e.getMessage());
        } finally {
            DBConnection.closeStatement(ps);
            DBConnection.closeConnection(conn);
        }
        return false;
    }

    /**
     * Deletes a category by ID.
     */
    public boolean deleteCategory(int categoryId) {
        String sql = "DELETE FROM `categories` WHERE `category_id` = ?";
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, categoryId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[CategoryDAO.deleteCategory Error] " + e.getMessage());
        } finally {
            DBConnection.closeStatement(ps);
            DBConnection.closeConnection(conn);
        }
        return false;
    }

    private Category mapCategory(ResultSet rs) throws SQLException {
        Category c = new Category();
        c.setCategoryId(rs.getInt("category_id"));
        c.setCategoryName(rs.getString("category_name"));
        c.setDescription(rs.getString("description"));
        c.setCreatedAt(rs.getTimestamp("created_at"));
        return c;
    }
}
