<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
        </div> <!-- End .admin-container -->
    </main> <!-- End .admin-main-content -->
</div> <!-- End .admin-wrapper -->

<!-- Bootstrap 5 Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- Admin Custom Script -->
<script src="${pageContext.request.contextPath}/js/admin.js"></script>
</body>
</html>
