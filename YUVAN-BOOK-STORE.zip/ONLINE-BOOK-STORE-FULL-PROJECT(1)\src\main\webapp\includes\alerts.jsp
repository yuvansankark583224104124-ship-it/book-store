<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<%-- Success Alert --%>
<c:if test="${not empty sessionScope.successMsg}">
    <div class="alert alert-success alert-dismissible fade show shadow-sm border-0 d-flex align-items-center mb-4" role="alert">
        <i class="fa-solid fa-circle-check me-2 fs-5"></i>
        <div>${sessionScope.successMsg}</div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <c:remove var="successMsg" scope="session" />
</c:if>

<%-- Error / Warning Alert from session --%>
<c:if test="${not empty sessionScope.errorMsg}">
    <div class="alert alert-danger alert-dismissible fade show shadow-sm border-0 d-flex align-items-center mb-4" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2 fs-5"></i>
        <div>${sessionScope.errorMsg}</div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <c:remove var="errorMsg" scope="session" />
</c:if>

<%-- Request Scope Error Alert --%>
<c:if test="${not empty requestScope.errorMsg}">
    <div class="alert alert-danger alert-dismissible fade show shadow-sm border-0 d-flex align-items-center mb-4" role="alert">
        <i class="fa-solid fa-circle-xmark me-2 fs-5"></i>
        <div>${requestScope.errorMsg}</div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
</c:if>
