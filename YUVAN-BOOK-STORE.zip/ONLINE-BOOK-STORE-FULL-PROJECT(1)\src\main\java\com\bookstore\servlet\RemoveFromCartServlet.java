package com.bookstore.servlet;

import com.bookstore.dao.CartDAO;
import com.bookstore.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Controller servlet for removing an item from the customer's cart.
 * Company: YUVAN & THIYAGU & CO.
 */
@WebServlet(name = "RemoveFromCartServlet", urlPatterns = {"/cart/remove"})
public class RemoveFromCartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final CartDAO cartDAO = new CartDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("loggedUser") : null;

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String cartIdParam = request.getParameter("id");
        if (cartIdParam != null) {
            try {
                int cartId = Integer.parseInt(cartIdParam);
                boolean removed = cartDAO.removeFromCart(cartId);
                if (removed) {
                    session.setAttribute("successMsg", "Item removed from your cart.");
                } else {
                    session.setAttribute("errorMsg", "Failed to remove item.");
                }
            } catch (NumberFormatException ignored) {
            }
        }

        int count = cartDAO.getCartCount(user.getUserId());
        session.setAttribute("cartCount", count);

        response.sendRedirect(request.getContextPath() + "/cart");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
