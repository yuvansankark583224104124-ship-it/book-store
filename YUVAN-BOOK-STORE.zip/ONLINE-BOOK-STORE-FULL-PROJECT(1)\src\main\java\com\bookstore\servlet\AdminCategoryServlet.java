package com.bookstore.servlet;

import com.bookstore.dao.CategoryDAO;
import com.bookstore.model.Category;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * Controller servlet for Admin Category Management.
 * Company: YUVAN & THIYAGU & CO.
 */
@WebServlet(name = "AdminCategoryServlet", urlPatterns = {
        "/admin/categories", "/admin/add-category", "/admin/edit-category", "/admin/delete-category"
})
public class AdminCategoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final CategoryDAO categoryDAO = new CategoryDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();

        if ("/admin/delete-category".equals(path)) {
            handleDeleteCategory(request, response);
        } else {
            List<Category> categories = categoryDAO.getCategoriesWithBookCount();
            request.setAttribute("categories", categories);
            request.getRequestDispatcher("/admin/categories.jsp").forward(request, response);
        }
    }

    private void handleDeleteCategory(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String idParam = request.getParameter("id");
        HttpSession session = request.getSession();

        if (idParam != null) {
            try {
                int catId = Integer.parseInt(idParam);
                boolean deleted = categoryDAO.deleteCategory(catId);
                if (deleted) {
                    session.setAttribute("successMsg", "Category deleted successfully.");
                } else {
                    session.setAttribute("errorMsg", "Failed to delete category.");
                }
            } catch (NumberFormatException ignored) {}
        }
        response.sendRedirect(request.getContextPath() + "/admin/categories");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        String categoryName = request.getParameter("categoryName");
        String description = request.getParameter("description");
        HttpSession session = request.getSession();

        if (categoryName == null || categoryName.trim().isEmpty()) {
            session.setAttribute("errorMsg", "Category name cannot be empty.");
            response.sendRedirect(request.getContextPath() + "/admin/categories");
            return;
        }

        if ("edit".equalsIgnoreCase(action)) {
            String idParam = request.getParameter("categoryId");
            try {
                int catId = Integer.parseInt(idParam);
                Category cat = new Category(catId, categoryName.trim(), description != null ? description.trim() : "", null);
                boolean updated = categoryDAO.updateCategory(cat);
                if (updated) {
                    session.setAttribute("successMsg", "Category updated successfully.");
                } else {
                    session.setAttribute("errorMsg", "Failed to update category.");
                }
            } catch (NumberFormatException e) {
                session.setAttribute("errorMsg", "Invalid Category ID.");
            }
        } else {
            // Add Category
            Category cat = new Category(categoryName.trim(), description != null ? description.trim() : "");
            boolean added = categoryDAO.addCategory(cat);
            if (added) {
                session.setAttribute("successMsg", "New category '" + categoryName.trim() + "' created.");
            } else {
                session.setAttribute("errorMsg", "Failed to add category. Name might already exist.");
            }
        }

        response.sendRedirect(request.getContextPath() + "/admin/categories");
    }
}
