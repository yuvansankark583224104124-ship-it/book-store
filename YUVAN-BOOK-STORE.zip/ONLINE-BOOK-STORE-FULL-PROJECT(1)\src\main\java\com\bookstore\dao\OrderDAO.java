package com.bookstore.dao;

import com.bookstore.model.CartItem;
import com.bookstore.model.Order;
import com.bookstore.model.OrderDetail;
import com.bookstore.util.DBConnection;
import com.bookstore.util.DateUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Order processing, transactional inventory decrement, status tracking, and order history.
 * Company: YUVAN & THIYAGU & CO.
 */
public class OrderDAO {

    /**
     * Executes complete checkout transaction:
     * 1. Validates real-time inventory stock for all cart items.
     * 2. Inserts master record into `orders`.
     * 3. Inserts each item into `order_details`.
     * 4. Deducts purchased quantity from `books` inventory (`stock = stock - qty`).
     * 5. Creates transaction record in `payments`.
     * 6. Purges user's shopping cart.
     * 7. Commits database transaction.
     *
     * @return generated order_id on success, -1 on failure
     * @throws Exception with descriptive error if stock is insufficient or order fails
     */
    public int createOrder(int userId, String recipientName, String recipientPhone, 
                           String deliveryAddress, String paymentMethod, List<CartItem> cartItems) throws Exception {
        if (cartItems == null || cartItems.isEmpty()) {
            throw new Exception("Your shopping cart is empty.");
        }

        Connection conn = null;
        PreparedStatement psOrder = null;
        PreparedStatement psDetail = null;
        PreparedStatement psStockCheck = null;
        PreparedStatement psStockUpdate = null;
        PreparedStatement psPayment = null;
        PreparedStatement psClearCart = null;
        ResultSet rs = null;

        int orderId = -1;

        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false); // Begin Transaction

            // Step 1: Validate stock for every item
            String checkStockSql = "SELECT title, stock FROM `books` WHERE `book_id` = ? FOR UPDATE";
            psStockCheck = conn.prepareStatement(checkStockSql);

            double totalAmount = 0.0;
            for (CartItem item : cartItems) {
                psStockCheck.setInt(1, item.getBookId());
                rs = psStockCheck.executeQuery();
                if (rs.next()) {
                    int currentStock = rs.getInt("stock");
                    String bookTitle = rs.getString("title");
                    if (item.getQuantity() > currentStock) {
                        throw new Exception("Insufficient stock for '" + bookTitle + "'. Available: " + currentStock + ", Requested: " + item.getQuantity());
                    }
                } else {
                    throw new Exception("Book (ID: " + item.getBookId() + ") is no longer available.");
                }
                rs.close();
                totalAmount += (item.getPrice() * item.getQuantity());
            }

            // Step 2: Insert into orders table
            String orderSql = "INSERT INTO `orders` (`user_id`, `total_amount`, `status`, `recipient_name`, `recipient_phone`, `delivery_address`, `payment_method`) " +
                              "VALUES (?, ?, 'PLACED', ?, ?, ?, ?)";
            psOrder = conn.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS);
            psOrder.setInt(1, userId);
            psOrder.setDouble(2, totalAmount);
            psOrder.setString(3, recipientName.trim());
            psOrder.setString(4, recipientPhone.trim());
            psOrder.setString(5, deliveryAddress.trim());
            psOrder.setString(6, paymentMethod.trim());

            int affected = psOrder.executeUpdate();
            if (affected == 0) {
                throw new SQLException("Failed to create master order record.");
            }

            rs = psOrder.getGeneratedKeys();
            if (rs.next()) {
                orderId = rs.getInt(1);
            } else {
                throw new SQLException("Failed to retrieve generated Order ID.");
            }
            rs.close();

            // Step 3 & 4: Insert order details & Deduct book inventory
            String detailSql = "INSERT INTO `order_details` (`order_id`, `book_id`, `quantity`, `price`) VALUES (?, ?, ?, ?)";
            psDetail = conn.prepareStatement(detailSql);

            String stockUpdateSql = "UPDATE `books` SET `stock` = `stock` - ? WHERE `book_id` = ?";
            psStockUpdate = conn.prepareStatement(stockUpdateSql);

            for (CartItem item : cartItems) {
                // Add order detail
                psDetail.setInt(1, orderId);
                psDetail.setInt(2, item.getBookId());
                psDetail.setInt(3, item.getQuantity());
                psDetail.setDouble(4, item.getPrice());
                psDetail.addBatch();

                // Deduct stock
                psStockUpdate.setInt(1, item.getQuantity());
                psStockUpdate.setInt(2, item.getBookId());
                psStockUpdate.addBatch();
            }

            psDetail.executeBatch();
            psStockUpdate.executeBatch();

            // Step 5: Insert payment record
            String paymentStatus = "Online Payment Demo".equalsIgnoreCase(paymentMethod) ? "COMPLETED" : "PENDING";
            String txnRef = "Online Payment Demo".equalsIgnoreCase(paymentMethod) ? DateUtil.generateTransactionReference() : "COD-" + orderId;

            String paymentSql = "INSERT INTO `payments` (`order_id`, `payment_method`, `amount`, `payment_status`, `transaction_ref`) " +
                                "VALUES (?, ?, ?, ?, ?)";
            psPayment = conn.prepareStatement(paymentSql);
            psPayment.setInt(1, orderId);
            psPayment.setString(2, paymentMethod);
            psPayment.setDouble(3, totalAmount);
            psPayment.setString(4, paymentStatus);
            psPayment.setString(5, txnRef);
            psPayment.executeUpdate();

            // Step 6: Empty user's cart
            String clearCartSql = "DELETE FROM `cart` WHERE `user_id` = ?";
            psClearCart = conn.prepareStatement(clearCartSql);
            psClearCart.setInt(1, userId);
            psClearCart.executeUpdate();

            // Step 7: Commit transaction
            conn.commit();
            return orderId;

        } catch (Exception e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    System.err.println("[OrderDAO.createOrder Rollback Error] " + ex.getMessage());
                }
            }
            throw e;
        } finally {
            DBConnection.closeStatement(psStockCheck);
            DBConnection.closeStatement(psOrder);
            DBConnection.closeStatement(psDetail);
            DBConnection.closeStatement(psStockUpdate);
            DBConnection.closeStatement(psPayment);
            DBConnection.closeStatement(psClearCart);
            DBConnection.closeConnection(conn);
        }
    }

    /**
     * Retrieves all orders for a specific customer.
     */
    public List<Order> getOrdersByUser(int userId) {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT o.*, p.payment_status, p.transaction_ref FROM `orders` o " +
                     "LEFT JOIN `payments` p ON o.order_id = p.order_id " +
                     "WHERE o.user_id = ? ORDER BY o.order_date DESC";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            rs = ps.executeQuery();
            while (rs.next()) {
                orders.add(mapOrder(rs));
            }
        } catch (SQLException e) {
            System.err.println("[OrderDAO.getOrdersByUser Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return orders;
    }

    /**
     * Retrieves all orders across the bookstore for Admin.
     */
    public List<Order> getAllOrders() {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT o.*, u.name AS customer_name, u.email AS customer_email, " +
                     "p.payment_status, p.transaction_ref FROM `orders` o " +
                     "JOIN `users` u ON o.user_id = u.user_id " +
                     "LEFT JOIN `payments` p ON o.order_id = p.order_id " +
                     "ORDER BY o.order_date DESC";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                orders.add(mapOrder(rs));
            }
        } catch (SQLException e) {
            System.err.println("[OrderDAO.getAllOrders Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return orders;
    }

    /**
     * Retrieves a complete single order with items for invoice / detail view.
     */
    public Order getOrderById(int orderId) {
        String sql = "SELECT o.*, u.name AS customer_name, u.email AS customer_email, " +
                     "p.payment_status, p.transaction_ref FROM `orders` o " +
                     "JOIN `users` u ON o.user_id = u.user_id " +
                     "LEFT JOIN `payments` p ON o.order_id = p.order_id " +
                     "WHERE o.order_id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, orderId);
            rs = ps.executeQuery();

            if (rs.next()) {
                Order order = mapOrder(rs);
                order.setOrderDetails(getOrderDetails(orderId, conn));
                return order;
            }
        } catch (SQLException e) {
            System.err.println("[OrderDAO.getOrderById Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return null;
    }

    /**
     * Retrieves line items for an order.
     */
    public List<OrderDetail> getOrderDetails(int orderId, Connection existingConn) {
        List<OrderDetail> details = new ArrayList<>();
        String sql = "SELECT od.*, b.title, b.author, b.isbn, b.image_url FROM `order_details` od " +
                     "JOIN `books` b ON od.book_id = b.book_id " +
                     "WHERE od.order_id = ?";
        Connection conn = existingConn;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean shouldClose = false;

        try {
            if (conn == null || conn.isClosed()) {
                conn = DBConnection.getConnection();
                shouldClose = true;
            }
            ps = conn.prepareStatement(sql);
            ps.setInt(1, orderId);
            rs = ps.executeQuery();
            while (rs.next()) {
                OrderDetail detail = new OrderDetail();
                detail.setOrderDetailId(rs.getInt("order_detail_id"));
                detail.setOrderId(rs.getInt("order_id"));
                detail.setBookId(rs.getInt("book_id"));
                detail.setBookTitle(rs.getString("title"));
                detail.setBookAuthor(rs.getString("author"));
                detail.setIsbn(rs.getString("isbn"));
                detail.setImageUrl(rs.getString("image_url"));
                detail.setQuantity(rs.getInt("quantity"));
                detail.setPrice(rs.getDouble("price"));
                detail.setSubtotal(detail.getPrice() * detail.getQuantity());
                details.add(detail);
            }
        } catch (SQLException e) {
            System.err.println("[OrderDAO.getOrderDetails Error] " + e.getMessage());
        } finally {
            if (shouldClose) {
                DBConnection.closeAll(rs, ps, conn);
            } else {
                DBConnection.closeResultSet(rs);
                DBConnection.closeStatement(ps);
            }
        }
        return details;
    }

    /**
     * Updates an order's fulfillment status (Admin action).
     */
    public boolean updateOrderStatus(int orderId, String newStatus) {
        String sql = "UPDATE `orders` SET `status` = ? WHERE `order_id` = ?";
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, newStatus);
            ps.setInt(2, orderId);

            int updated = ps.executeUpdate();
            if (updated > 0 && "DELIVERED".equalsIgnoreCase(newStatus)) {
                // If delivered, mark payment as COMPLETED if pending
                String paySql = "UPDATE `payments` SET `payment_status` = 'COMPLETED' WHERE `order_id` = ?";
                PreparedStatement psPay = conn.prepareStatement(paySql);
                psPay.setInt(1, orderId);
                psPay.executeUpdate();
                psPay.close();
            }
            return updated > 0;
        } catch (SQLException e) {
            System.err.println("[OrderDAO.updateOrderStatus Error] " + e.getMessage());
        } finally {
            DBConnection.closeStatement(ps);
            DBConnection.closeConnection(conn);
        }
        return false;
    }

    /**
     * Cancels an order and restores book inventory.
     */
    public boolean cancelOrder(int orderId, int userId) {
        Connection conn = null;
        PreparedStatement psCheck = null;
        PreparedStatement psUpdateStatus = null;
        PreparedStatement psRestoreStock = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false);

            // Check if order belongs to user and is in cancellable state
            String checkSql = "SELECT status FROM `orders` WHERE `order_id` = ?" + (userId > 0 ? " AND `user_id` = ?" : "");
            psCheck = conn.prepareStatement(checkSql);
            psCheck.setInt(1, orderId);
            if (userId > 0) {
                psCheck.setInt(2, userId);
            }
            rs = psCheck.executeQuery();

            if (!rs.next()) {
                return false;
            }

            String currentStatus = rs.getString("status");
            if (!"PLACED".equalsIgnoreCase(currentStatus) && !"CONFIRMED".equalsIgnoreCase(currentStatus)) {
                return false; // Cannot cancel shipped or delivered orders
            }

            // Update status to CANCELLED
            String updateSql = "UPDATE `orders` SET `status` = 'CANCELLED' WHERE `order_id` = ?";
            psUpdateStatus = conn.prepareStatement(updateSql);
            psUpdateStatus.setInt(1, orderId);
            psUpdateStatus.executeUpdate();

            // Restore book stock
            List<OrderDetail> details = getOrderDetails(orderId, conn);
            String restoreSql = "UPDATE `books` SET `stock` = `stock` + ? WHERE `book_id` = ?";
            psRestoreStock = conn.prepareStatement(restoreSql);

            for (OrderDetail od : details) {
                psRestoreStock.setInt(1, od.getQuantity());
                psRestoreStock.setInt(2, od.getBookId());
                psRestoreStock.addBatch();
            }
            psRestoreStock.executeBatch();

            conn.commit();
            return true;

        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ignored) {}
            }
            System.err.println("[OrderDAO.cancelOrder Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, psCheck, null);
            DBConnection.closeStatement(psUpdateStatus);
            DBConnection.closeStatement(psRestoreStock);
            DBConnection.closeConnection(conn);
        }
        return false;
    }

    private Order mapOrder(ResultSet rs) throws SQLException {
        Order o = new Order();
        o.setOrderId(rs.getInt("order_id"));
        o.setUserId(rs.getInt("user_id"));
        try {
            o.setCustomerName(rs.getString("customer_name"));
            o.setCustomerEmail(rs.getString("customer_email"));
        } catch (SQLException ignored) {}
        o.setOrderDate(rs.getTimestamp("order_date"));
        o.setTotalAmount(rs.getDouble("total_amount"));
        o.setStatus(rs.getString("status"));
        o.setRecipientName(rs.getString("recipient_name"));
        o.setRecipientPhone(rs.getString("recipient_phone"));
        o.setDeliveryAddress(rs.getString("delivery_address"));
        o.setPaymentMethod(rs.getString("payment_method"));
        try {
            o.setPaymentStatus(rs.getString("payment_status"));
            o.setTransactionRef(rs.getString("transaction_ref"));
        } catch (SQLException ignored) {}
        return o;
    }
}
