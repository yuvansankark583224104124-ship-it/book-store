﻿# TEST CASES: ONLINE BOOK STORE MANAGEMENT SYSTEM
**Company**: YUVAN BOOK STORE

| TC ID | Test Scenario | Test Steps / Input | Expected Result | Status |
| :--- | :--- | :--- | :--- | :--- |
| **TC01** | Admin Authentication | Enter valid username (`admin`) & password (`admin123`) on `admin-login.html` | Redirects to `admin-dashboard.html` with KPI metrics displayed | **PASS** |
| **TC02** | Invalid Admin Login | Enter invalid password | Displays validation alert and denies login access | **PASS** |
| **TC03** | Customer Registration | Fill valid Name, Email, Phone, Address, and Password on `register.html` | Creates account and redirects to home page with confirmation alert | **PASS** |
| **TC04** | Customer Login | Enter registered email & password on `login.html` | Authenticates customer and loads personalized session | **PASS** |
| **TC05** | Book Catalog Loading | Open `books.html` | Displays at least 12 book cards with prices, categories, and stock status | **PASS** |
| **TC06** | Category Filtering | Click on "Programming" category filter on `books.html` | Displays only books tagged under the Programming category | **PASS** |
| **TC07** | Live Book Search | Enter keyword "Java" in search box | Instantly filters and displays all Java related books | **PASS** |
| **TC08** | Book Details View | Click "View Details" on a book card | Loads `book-details.html` with full ISBN, publisher, and specs | **PASS** |
| **TC09** | Add Book to Cart | Click "Add to Cart" on book details page | Item added to cart, badge count increments, toast alert appears | **PASS** |
| **TC10** | Cart Quantity Update | Click `+` and `-` buttons in `cart.html` | Updates item quantity and recalculates line subtotal | **PASS** |
| **TC11** | Cart Total Calculation | Adjust item quantities in cart | Subtotal and delivery fee calculated dynamically (Free above ₹1,000) | **PASS** |
| **TC12** | Remove Item from Cart | Click Remove/Trash icon in `cart.html` | Removes item from cart and recalculates grand total | **PASS** |
| **TC13** | Checkout Submission | Enter recipient address and choose "Cash on Delivery" on `checkout.html` | Generates Order ID `YTC1001`, clears cart, and opens `order-confirmation.html` | **PASS** |
| **TC14** | Order Confirmation | Verify receipt on `order-confirmation.html` | Displays customer name, address, order date, and total paid | **PASS** |
| **TC15** | Order Tracking | Open `track-order.html?id=YTC1001` | Renders 5-step visual tracking timeline from Placed to Delivered | **PASS** |
| **TC16** | Admin Add Book | Fill new book form on `add-book.html` and submit | Confirms addition and redirects to updated `admin-books.html` | **PASS** |
| **TC17** | Admin Delete Book | Click delete icon on `admin-books.html` with confirmation | Removes the book row from the table | **PASS** |
| **TC18** | Admin Sales Report | Open `admin-reports.html` | Displays daily turnover, monthly sales, and bestsellers ranking table | **PASS** |
