package com.bookstore.servlet;

import com.bookstore.dao.OrderDAO;
import com.bookstore.model.Admin;
import com.bookstore.model.Order;
import com.bookstore.model.User;
import com.bookstore.util.DateUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Controller servlet for generating printable, branded invoices.
 * Company: YUVAN & THIYAGU & CO.
 */
@WebServlet(name = "InvoiceServlet", urlPatterns = {"/invoice"})
public class InvoiceServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final OrderDAO orderDAO = new OrderDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("loggedUser") : null;
        Admin admin = (session != null) ? (Admin) session.getAttribute("adminUser") : null;

        if (user == null && admin == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String idParam = request.getParameter("id");
        if (idParam == null) {
            response.sendRedirect(request.getContextPath() + "/orders");
            return;
        }

        try {
            int orderId = Integer.parseInt(idParam);
            Order order = orderDAO.getOrderById(orderId);

            if (order == null) {
                request.getSession().setAttribute("errorMsg", "Order not found.");
                response.sendRedirect(request.getContextPath() + "/orders");
                return;
            }

            // If user is accessing, ensure ownership
            if (admin == null && (user != null && order.getUserId() != user.getUserId())) {
                request.getSession().setAttribute("errorMsg", "Unauthorized invoice access.");
                response.sendRedirect(request.getContextPath() + "/orders");
                return;
            }

            String invoiceNo = DateUtil.generateInvoiceNumber(order.getOrderId());

            request.setAttribute("order", order);
            request.setAttribute("invoiceNo", invoiceNo);
            request.getRequestDispatcher("/invoice.jsp").forward(request, response);

        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/orders");
        }
    }
}
