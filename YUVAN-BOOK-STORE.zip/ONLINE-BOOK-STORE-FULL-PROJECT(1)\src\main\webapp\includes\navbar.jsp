<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm" style="background-color: var(--primary-dark) !important;">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="${pageContext.request.contextPath}/home">
            <i class="fa-solid fa-book-open-reader text-warning me-2 fs-4"></i>
            <span>YUVAN &amp; THIYAGU &amp; CO.</span>
            <span class="brand-badge">Bookstore</span>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar" aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainNavbar">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-3">
                <li class="nav-item">
                    <a class="nav-link ${pageContext.request.servletPath == '/index.jsp' || pageContext.request.servletPath == '/home' ? 'active' : ''}" href="${pageContext.request.contextPath}/home">
                        <i class="fa-solid fa-house me-1"></i> Home
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link ${pageContext.request.servletPath == '/books.jsp' || pageContext.request.servletPath == '/books' ? 'active' : ''}" href="${pageContext.request.contextPath}/books">
                        <i class="fa-solid fa-book me-1"></i> Books
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link ${pageContext.request.servletPath == '/about.jsp' ? 'active' : ''}" href="${pageContext.request.contextPath}/about.jsp">
                        <i class="fa-solid fa-circle-info me-1"></i> About Us
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link ${pageContext.request.servletPath == '/contact.jsp' ? 'active' : ''}" href="${pageContext.request.contextPath}/contact.jsp">
                        <i class="fa-solid fa-envelope me-1"></i> Contact
                    </a>
                </li>
            </ul>

            <!-- Search bar in navbar -->
            <form class="d-flex me-lg-3 my-2 my-lg-0" action="${pageContext.request.contextPath}/search" method="get">
                <div class="input-group input-group-sm">
                    <input class="form-control" type="search" name="q" placeholder="Search title, author, ISBN..." value="${keyword}" aria-label="Search" required>
                    <button class="btn btn-warning" type="submit">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </button>
                </div>
            </form>

            <ul class="navbar-nav align-items-lg-center">
                <!-- Cart Link -->
                <li class="nav-item me-2">
                    <a class="nav-link position-relative btn btn-outline-light btn-sm text-start text-lg-center border-0" href="${pageContext.request.contextPath}/cart">
                        <i class="fa-solid fa-cart-shopping me-1 fs-5"></i>
                        <span class="d-lg-none">Cart</span>
                        <c:if test="${not empty sessionScope.cartCount && sessionScope.cartCount > 0}">
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                ${sessionScope.cartCount}
                            </span>
                        </c:if>
                    </a>
                </li>

                <!-- User Session State -->
                <c:choose>
                    <c:when test="${not empty sessionScope.loggedUser}">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <div class="avatar-circle me-2 bg-primary text-white d-inline-flex justify-content-center align-items-center rounded-circle" style="width: 32px; height: 32px; font-weight: 700; font-size: 0.9rem;">
                                    ${sessionScope.loggedUser.name.substring(0, 1).toUpperCase()}
                                </div>
                                <span>${sessionScope.loggedUser.name}</span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end shadow border-0" aria-labelledby="userDropdown">
                                <li>
                                    <div class="dropdown-header">
                                        <small class="text-muted d-block">Signed in as</small>
                                        <strong>${sessionScope.loggedUser.email}</strong>
                                    </div>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item" href="${pageContext.request.contextPath}/profile">
                                        <i class="fa-solid fa-user me-2 text-primary"></i> My Profile
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="${pageContext.request.contextPath}/orders">
                                        <i class="fa-solid fa-box-archive me-2 text-success"></i> My Orders
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item text-danger" href="${pageContext.request.contextPath}/logout">
                                        <i class="fa-solid fa-right-from-bracket me-2"></i> Logout
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </c:when>
                    <c:otherwise>
                        <li class="nav-item me-1">
                            <a class="btn btn-outline-light btn-sm px-3" href="${pageContext.request.contextPath}/login.jsp">
                                <i class="fa-solid fa-right-to-bracket me-1"></i> Login
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-warning btn-sm px-3 text-dark fw-bold" href="${pageContext.request.contextPath}/register.jsp">
                                <i class="fa-solid fa-user-plus me-1"></i> Register
                            </a>
                        </li>
                    </c:otherwise>
                </c:choose>
            </ul>
        </div>
    </div>
</nav>
