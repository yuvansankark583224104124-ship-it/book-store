package com.bookstore.servlet;

import com.bookstore.dao.UserDAO;
import com.bookstore.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Controller servlet for new Customer Registration.
 * Performs validation, checks duplicate email, and creates user account.
 * Company: YUVAN & THIYAGU & CO.
 */
@WebServlet(name = "RegisterServlet", urlPatterns = {"/register"})
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("loggedUser") != null) {
            response.sendRedirect(request.getContextPath() + "/profile");
            return;
        }
        request.getRequestDispatcher("/register.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");
        String city = request.getParameter("city");
        String state = request.getParameter("state");
        String pincode = request.getParameter("pincode");

        // Validation
        if (name == null || name.trim().isEmpty() ||
            email == null || email.trim().isEmpty() ||
            password == null || password.trim().isEmpty() ||
            phone == null || phone.trim().isEmpty() ||
            address == null || address.trim().isEmpty()) {
            
            request.setAttribute("errorMsg", "Please fill in all required fields.");
            retainFormData(request, name, email, phone, address, city, state, pincode);
            request.getRequestDispatcher("/register.jsp").forward(request, response);
            return;
        }

        if (password.length() < 6) {
            request.setAttribute("errorMsg", "Password must be at least 6 characters long.");
            retainFormData(request, name, email, phone, address, city, state, pincode);
            request.getRequestDispatcher("/register.jsp").forward(request, response);
            return;
        }

        if (confirmPassword != null && !password.equals(confirmPassword)) {
            request.setAttribute("errorMsg", "Passwords do not match. Please re-enter.");
            retainFormData(request, name, email, phone, address, city, state, pincode);
            request.getRequestDispatcher("/register.jsp").forward(request, response);
            return;
        }

        if (userDAO.isEmailRegistered(email)) {
            request.setAttribute("errorMsg", "An account with email '" + email + "' already exists. Please log in.");
            retainFormData(request, name, email, phone, address, city, state, pincode);
            request.getRequestDispatcher("/register.jsp").forward(request, response);
            return;
        }

        User newUser = new User(name.trim(), email.trim(), password, phone.trim(), address.trim(), 
                                (city != null ? city.trim() : "Chennai"), 
                                (state != null ? state.trim() : "Tamil Nadu"), 
                                (pincode != null ? pincode.trim() : "600001"));

        int userId = userDAO.register(newUser);

        if (userId > 0) {
            newUser.setUserId(userId);
            HttpSession session = request.getSession(true);
            session.setAttribute("loggedUser", newUser);
            session.setAttribute("cartCount", 0);
            session.setAttribute("successMsg", "Account created successfully! Welcome to YUVAN & THIYAGU & CO.");
            response.sendRedirect(request.getContextPath() + "/home");
        } else {
            request.setAttribute("errorMsg", "Registration failed due to a database error. Please try again.");
            retainFormData(request, name, email, phone, address, city, state, pincode);
            request.getRequestDispatcher("/register.jsp").forward(request, response);
        }
    }

    private void retainFormData(HttpServletRequest request, String name, String email, String phone, 
                                String address, String city, String state, String pincode) {
        request.setAttribute("name", name);
        request.setAttribute("email", email);
        request.setAttribute("phone", phone);
        request.setAttribute("address", address);
        request.setAttribute("city", city);
        request.setAttribute("state", state);
        request.setAttribute("pincode", pincode);
    }
}
