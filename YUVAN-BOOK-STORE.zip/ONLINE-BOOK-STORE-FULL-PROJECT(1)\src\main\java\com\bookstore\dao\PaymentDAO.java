package com.bookstore.dao;

import com.bookstore.model.Payment;
import com.bookstore.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Data Access Object for Payment transaction records.
 * Company: YUVAN & THIYAGU & CO.
 */
public class PaymentDAO {

    /**
     * Retrieves payment details associated with an order.
     */
    public Payment getPaymentByOrderId(int orderId) {
        String sql = "SELECT * FROM `payments` WHERE `order_id` = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, orderId);
            rs = ps.executeQuery();

            if (rs.next()) {
                Payment p = new Payment();
                p.setPaymentId(rs.getInt("payment_id"));
                p.setOrderId(rs.getInt("order_id"));
                p.setPaymentMethod(rs.getString("payment_method"));
                p.setAmount(rs.getDouble("amount"));
                p.setPaymentStatus(rs.getString("payment_status"));
                p.setPaymentDate(rs.getTimestamp("payment_date"));
                p.setTransactionRef(rs.getString("transaction_ref"));
                return p;
            }
        } catch (SQLException e) {
            System.err.println("[PaymentDAO.getPaymentByOrderId Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return null;
    }

    /**
     * Updates payment status for an order.
     */
    public boolean updatePaymentStatus(int orderId, String newStatus) {
        String sql = "UPDATE `payments` SET `payment_status` = ? WHERE `order_id` = ?";
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, newStatus);
            ps.setInt(2, orderId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[PaymentDAO.updatePaymentStatus Error] " + e.getMessage());
        } finally {
            DBConnection.closeStatement(ps);
            DBConnection.closeConnection(conn);
        }
        return false;
    }
}
