package com.bookstore.dao;

import com.bookstore.model.User;
import com.bookstore.util.DBConnection;
import com.bookstore.util.PasswordUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Customer/User registration, authentication, and profile management.
 * Company: YUVAN & THIYAGU & CO.
 */
public class UserDAO {

    /**
     * Registers a new customer into the database.
     * @return generated user_id on success, -1 on failure
     */
    public int register(User user) {
        String sql = "INSERT INTO `users` (`name`, `email`, `password`, `phone`, `address`, `city`, `state`, `pincode`) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, user.getName());
            ps.setString(2, user.getEmail().trim().toLowerCase());
            // Store hashed password or clean password
            String hashedPassword = PasswordUtil.hashPassword(user.getPassword());
            ps.setString(3, hashedPassword);
            ps.setString(4, user.getPhone());
            ps.setString(5, user.getAddress());
            ps.setString(6, user.getCity() != null ? user.getCity() : "Chennai");
            ps.setString(7, user.getState() != null ? user.getState() : "Tamil Nadu");
            ps.setString(8, user.getPincode() != null ? user.getPincode() : "600001");

            int rows = ps.executeUpdate();
            if (rows > 0) {
                rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            System.err.println("[UserDAO.register Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return -1;
    }

    /**
     * Authenticates a customer by email and password.
     */
    public User login(String email, String password) {
        String sql = "SELECT * FROM `users` WHERE `email` = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, email.trim().toLowerCase());
            rs = ps.executeQuery();

            if (rs.next()) {
                String storedPassword = rs.getString("password");
                if (PasswordUtil.checkPassword(password, storedPassword)) {
                    return mapUser(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("[UserDAO.login Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return null;
    }

    /**
     * Checks whether an email is already registered in the system.
     */
    public boolean isEmailRegistered(String email) {
        String sql = "SELECT 1 FROM `users` WHERE `email` = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, email.trim().toLowerCase());
            rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.err.println("[UserDAO.isEmailRegistered Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return false;
    }

    /**
     * Retrieves user details by ID.
     */
    public User getUserById(int userId) {
        String sql = "SELECT * FROM `users` WHERE `user_id` = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            rs = ps.executeQuery();
            if (rs.next()) {
                return mapUser(rs);
            }
        } catch (SQLException e) {
            System.err.println("[UserDAO.getUserById Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return null;
    }

    /**
     * Updates customer profile details.
     */
    public boolean updateProfile(User user) {
        String sql = "UPDATE `users` SET `name` = ?, `phone` = ?, `address` = ?, `city` = ?, `state` = ?, `pincode` = ? WHERE `user_id` = ?";
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, user.getName());
            ps.setString(2, user.getPhone());
            ps.setString(3, user.getAddress());
            ps.setString(4, user.getCity());
            ps.setString(5, user.getState());
            ps.setString(6, user.getPincode());
            ps.setInt(7, user.getUserId());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[UserDAO.updateProfile Error] " + e.getMessage());
        } finally {
            DBConnection.closeStatement(ps);
            DBConnection.closeConnection(conn);
        }
        return false;
    }

    /**
     * Updates customer password.
     */
    public boolean changePassword(int userId, String newPassword) {
        String sql = "UPDATE `users` SET `password` = ? WHERE `user_id` = ?";
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, PasswordUtil.hashPassword(newPassword));
            ps.setInt(2, userId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[UserDAO.changePassword Error] " + e.getMessage());
        } finally {
            DBConnection.closeStatement(ps);
            DBConnection.closeConnection(conn);
        }
        return false;
    }

    /**
     * Retrieves all registered customers for admin management.
     */
    public List<User> getAllUsers() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM `users` ORDER BY `user_id` DESC";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(mapUser(rs));
            }
        } catch (SQLException e) {
            System.err.println("[UserDAO.getAllUsers Error] " + e.getMessage());
        } finally {
            DBConnection.closeAll(rs, ps, conn);
        }
        return list;
    }

    private User mapUser(ResultSet rs) throws SQLException {
        User u = new User();
        u.setUserId(rs.getInt("user_id"));
        u.setName(rs.getString("name"));
        u.setEmail(rs.getString("email"));
        u.setPassword(rs.getString("password"));
        u.setPhone(rs.getString("phone"));
        u.setAddress(rs.getString("address"));
        u.setCity(rs.getString("city"));
        u.setState(rs.getString("state"));
        u.setPincode(rs.getString("pincode"));
        u.setCreatedAt(rs.getTimestamp("created_at"));
        return u;
    }
}
