package com.bookstore.model;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Model class representing structured sales reporting data for Admin.
 * Company: YUVAN & THIYAGU & CO.
 */
public class SalesReport implements Serializable {
    private static final long serialVersionUID = 1L;

    private double totalRevenue;
    private int totalOrders;
    private int totalBooksSold;
    private double dailyRevenue;
    private int dailyOrders;
    private double monthlyRevenue;
    private int monthlyOrders;

    private List<Map<String, Object>> dailySalesTrend;
    private List<Map<String, Object>> monthlySalesTrend;
    private List<Map<String, Object>> categoryWiseSales;
    private List<Map<String, Object>> bestSellingBooks;

    public SalesReport() {
    }

    public double getTotalRevenue() {
        return totalRevenue;
    }

    public void setTotalRevenue(double totalRevenue) {
        this.totalRevenue = totalRevenue;
    }

    public int getTotalOrders() {
        return totalOrders;
    }

    public void setTotalOrders(int totalOrders) {
        this.totalOrders = totalOrders;
    }

    public int getTotalBooksSold() {
        return totalBooksSold;
    }

    public void setTotalBooksSold(int totalBooksSold) {
        this.totalBooksSold = totalBooksSold;
    }

    public double getDailyRevenue() {
        return dailyRevenue;
    }

    public void setDailyRevenue(double dailyRevenue) {
        this.dailyRevenue = dailyRevenue;
    }

    public int getDailyOrders() {
        return dailyOrders;
    }

    public void setDailyOrders(int dailyOrders) {
        this.dailyOrders = dailyOrders;
    }

    public double getMonthlyRevenue() {
        return monthlyRevenue;
    }

    public void setMonthlyRevenue(double monthlyRevenue) {
        this.monthlyRevenue = monthlyRevenue;
    }

    public int getMonthlyOrders() {
        return monthlyOrders;
    }

    public void setMonthlyOrders(int monthlyOrders) {
        this.monthlyOrders = monthlyOrders;
    }

    public List<Map<String, Object>> getDailySalesTrend() {
        return dailySalesTrend;
    }

    public void setDailySalesTrend(List<Map<String, Object>> dailySalesTrend) {
        this.dailySalesTrend = dailySalesTrend;
    }

    public List<Map<String, Object>> getMonthlySalesTrend() {
        return monthlySalesTrend;
    }

    public void setMonthlySalesTrend(List<Map<String, Object>> monthlySalesTrend) {
        this.monthlySalesTrend = monthlySalesTrend;
    }

    public List<Map<String, Object>> getCategoryWiseSales() {
        return categoryWiseSales;
    }

    public void setCategoryWiseSales(List<Map<String, Object>> categoryWiseSales) {
        this.categoryWiseSales = categoryWiseSales;
    }

    public List<Map<String, Object>> getBestSellingBooks() {
        return bestSellingBooks;
    }

    public void setBestSellingBooks(List<Map<String, Object>> bestSellingBooks) {
        this.bestSellingBooks = bestSellingBooks;
    }

    public String getFormattedTotalRevenue() {
        return String.format("₹%.2f", totalRevenue);
    }

    public String getFormattedDailyRevenue() {
        return String.format("₹%.2f", dailyRevenue);
    }

    public String getFormattedMonthlyRevenue() {
        return String.format("₹%.2f", monthlyRevenue);
    }
}
