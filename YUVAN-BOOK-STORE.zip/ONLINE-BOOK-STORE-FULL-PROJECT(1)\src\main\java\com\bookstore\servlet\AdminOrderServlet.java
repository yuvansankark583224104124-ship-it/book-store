package com.bookstore.servlet;

import com.bookstore.dao.OrderDAO;
import com.bookstore.model.Order;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * Controller servlet for Admin Order Management:
 * View orders, inspect customer shipping details, update status transitions.
 * Company: YUVAN & THIYAGU & CO.
 */
@WebServlet(name = "AdminOrderServlet", urlPatterns = {
        "/admin/orders", "/admin/order-details", "/admin/update-order-status"
})
public class AdminOrderServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final OrderDAO orderDAO = new OrderDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();

        if ("/admin/order-details".equals(path)) {
            handleOrderDetails(request, response);
        } else {
            handleOrderList(request, response);
        }
    }

    private void handleOrderList(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String statusFilter = request.getParameter("status");
        List<Order> orders = orderDAO.getAllOrders();

        if (statusFilter != null && !statusFilter.trim().isEmpty() && !"ALL".equalsIgnoreCase(statusFilter)) {
            orders.removeIf(o -> !statusFilter.equalsIgnoreCase(o.getStatus()));
            request.setAttribute("selectedStatus", statusFilter);
        } else {
            request.setAttribute("selectedStatus", "ALL");
        }

        request.setAttribute("orders", orders);
        request.getRequestDispatcher("/admin/orders.jsp").forward(request, response);
    }

    private void handleOrderDetails(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idParam = request.getParameter("id");
        if (idParam == null) {
            response.sendRedirect(request.getContextPath() + "/admin/orders");
            return;
        }

        try {
            int orderId = Integer.parseInt(idParam);
            Order order = orderDAO.getOrderById(orderId);

            if (order == null) {
                request.getSession().setAttribute("errorMsg", "Order not found.");
                response.sendRedirect(request.getContextPath() + "/admin/orders");
                return;
            }

            request.setAttribute("order", order);
            request.getRequestDispatcher("/admin/order-details.jsp").forward(request, response);

        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/admin/orders");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String orderIdParam = request.getParameter("orderId");
        String newStatus = request.getParameter("status");
        HttpSession session = request.getSession();

        if (orderIdParam == null || newStatus == null) {
            session.setAttribute("errorMsg", "Invalid order status update request.");
            response.sendRedirect(request.getContextPath() + "/admin/orders");
            return;
        }

        try {
            int orderId = Integer.parseInt(orderIdParam);
            boolean updated = orderDAO.updateOrderStatus(orderId, newStatus.trim().toUpperCase());

            if (updated) {
                session.setAttribute("successMsg", "Order #" + orderId + " status updated to " + newStatus.toUpperCase() + ".");
            } else {
                session.setAttribute("errorMsg", "Failed to update order status.");
            }

        } catch (NumberFormatException e) {
            session.setAttribute("errorMsg", "Invalid Order ID.");
        }

        String referer = request.getHeader("referer");
        if (referer != null && referer.contains("/admin/order-details")) {
            response.sendRedirect(referer);
        } else {
            response.sendRedirect(request.getContextPath() + "/admin/orders");
        }
    }
}
