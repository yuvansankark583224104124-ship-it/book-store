<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<header class="admin-topbar">
    <div class="d-flex align-items-center">
        <button class="btn btn-light d-lg-none me-3 shadow-sm border" id="sidebarToggle" type="button">
            <i class="fa-solid fa-bars"></i>
        </button>
        <h5 class="mb-0 fw-bold text-dark">${adminSectionTitle != null ? adminSectionTitle : 'Management Console'}</h5>
    </div>

    <div class="d-flex align-items-center gap-3">
        <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-3 py-2 rounded-pill">
            <i class="fa-solid fa-user-shield me-1"></i> ${sessionScope.adminUser != null ? sessionScope.adminUser.fullName : 'Administrator'}
        </span>
        <a href="${pageContext.request.contextPath}/admin-logout" class="btn btn-outline-danger btn-sm" title="Logout">
            <i class="fa-solid fa-power-off"></i>
        </a>
    </div>
</header>
