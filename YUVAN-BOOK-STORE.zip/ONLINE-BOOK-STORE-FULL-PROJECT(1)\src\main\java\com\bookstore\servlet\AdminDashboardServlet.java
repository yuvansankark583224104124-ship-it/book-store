package com.bookstore.servlet;

import com.bookstore.dao.AdminDAO;
import com.bookstore.dao.OrderDAO;
import com.bookstore.model.DashboardStats;
import com.bookstore.model.Order;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Controller servlet for the Administrator KPI Dashboard.
 * Company: YUVAN & THIYAGU & CO.
 */
@WebServlet(name = "AdminDashboardServlet", urlPatterns = {"/admin/dashboard"})
public class AdminDashboardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final AdminDAO adminDAO = new AdminDAO();
    private final OrderDAO orderDAO = new OrderDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        DashboardStats stats = adminDAO.getDashboardStats();
        List<Order> allOrders = orderDAO.getAllOrders();
        
        // Take top 6 recent orders for dashboard table
        List<Order> recentOrders = allOrders.size() > 6 ? allOrders.subList(0, 6) : allOrders;
        stats.setRecentOrders(recentOrders);

        request.setAttribute("stats", stats);
        request.getRequestDispatcher("/admin/dashboard.jsp").forward(request, response);
    }
}
