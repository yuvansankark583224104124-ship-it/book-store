<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<c:set var="pageTitle" value="Contact Us | YUVAN & THIYAGU & CO." scope="request"/>
<jsp:include page="/includes/header.jsp" />
<jsp:include page="/includes/navbar.jsp" />

<main class="py-5 bg-light">
    <div class="container">
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="${pageContext.request.contextPath}/home" class="text-decoration-none">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
            </ol>
        </nav>

        <div class="row g-5">
            <!-- Contact Info -->
            <div class="col-lg-5">
                <div class="card border-0 shadow-sm rounded-4 p-4 p-md-5 h-100 bg-primary text-white" style="background: linear-gradient(135deg, #1e3a8a 0%, #0f172a 100%) !important;">
                    <span class="badge bg-warning text-dark px-3 py-2 rounded-pill fw-bold text-uppercase mb-3 align-self-start">Reach Out</span>
                    <h2 class="fw-bold mb-3">Get in Touch With Our Team</h2>
                    <p class="text-light opacity-75 mb-4">
                        Have questions about book availability, bulk institutional orders, or shipping timelines? We are here to assist you!
                    </p>

                    <div class="d-flex align-items-start mb-4">
                        <div class="me-3 fs-4 text-warning"><i class="fa-solid fa-location-dot"></i></div>
                        <div>
                            <h6 class="fw-bold mb-1 text-white">Headquarters &amp; Book House</h6>
                            <p class="mb-0 text-light opacity-75 small">124, Anna Salai, Mount Road, Chennai, Tamil Nadu - 600002</p>
                        </div>
                    </div>

                    <div class="d-flex align-items-start mb-4">
                        <div class="me-3 fs-4 text-warning"><i class="fa-solid fa-phone"></i></div>
                        <div>
                            <h6 class="fw-bold mb-1 text-white">Direct Phone</h6>
                            <p class="mb-0 text-light opacity-75 small">+91 98765 43210 / +91 44 2855 0000</p>
                        </div>
                    </div>

                    <div class="d-flex align-items-start mb-4">
                        <div class="me-3 fs-4 text-warning"><i class="fa-solid fa-envelope"></i></div>
                        <div>
                            <h6 class="fw-bold mb-1 text-white">Email Address</h6>
                            <p class="mb-0 text-light opacity-75 small">contact@yuvanthiyagu.com / support@yuvanthiyagu.com</p>
                        </div>
                    </div>

                    <div class="d-flex align-items-start">
                        <div class="me-3 fs-4 text-warning"><i class="fa-solid fa-clock"></i></div>
                        <div>
                            <h6 class="fw-bold mb-1 text-white">Operating Hours</h6>
                            <p class="mb-0 text-light opacity-75 small">Monday – Saturday: 9:00 AM – 8:00 PM IST</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Contact Form -->
            <div class="col-lg-7">
                <div class="card border-0 shadow-sm rounded-4 p-4 p-md-5">
                    <h3 class="fw-bold text-dark mb-2">Send Us a Message</h3>
                    <p class="text-muted small mb-4">Fill out the form below and our customer desk will respond within 24 business hours.</p>

                    <form onsubmit="event.preventDefault(); alert('Thank you for contacting YUVAN & THIYAGU & CO. Your message has been received!'); this.reset();">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-semibold text-secondary small">Your Full Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="e.g. Karthik Raja" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold text-secondary small">Email Address <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" placeholder="e.g. karthik@example.com" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold text-secondary small">Contact Phone <span class="text-danger">*</span></label>
                                <input type="tel" class="form-control" placeholder="e.g. 9876543210" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold text-secondary small">Subject</label>
                                <input type="text" class="form-control" placeholder="e.g. Inquiry regarding bulk textbook discount" required>
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-semibold text-secondary small">Your Message <span class="text-danger">*</span></label>
                                <textarea class="form-control" rows="5" placeholder="Please write your questions or order requirements here..." required></textarea>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary px-4 py-2 fw-semibold">
                                    <i class="fa-solid fa-paper-plane me-2"></i> Send Message
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>

<jsp:include page="/includes/footer.jsp" />
