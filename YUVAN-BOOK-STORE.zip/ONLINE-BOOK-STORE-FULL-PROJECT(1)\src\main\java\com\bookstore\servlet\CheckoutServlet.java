package com.bookstore.servlet;

import com.bookstore.dao.CartDAO;
import com.bookstore.dao.OrderDAO;
import com.bookstore.dao.UserDAO;
import com.bookstore.model.CartItem;
import com.bookstore.model.Order;
import com.bookstore.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * Controller servlet for Checkout workflow and Order placement.
 * Handles customer details validation, stock verification, and order processing.
 * Company: YUVAN & THIYAGU & CO.
 */
@WebServlet(name = "CheckoutServlet", urlPatterns = {"/checkout", "/place-order"})
public class CheckoutServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final CartDAO cartDAO = new CartDAO();
    private final OrderDAO orderDAO = new OrderDAO();
    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("loggedUser");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        // Fetch cart items
        List<CartItem> cartItems = cartDAO.getCartItemsByUser(user.getUserId());
        if (cartItems == null || cartItems.isEmpty()) {
            session.setAttribute("errorMsg", "Your cart is empty. Please add books before proceeding to checkout.");
            response.sendRedirect(request.getContextPath() + "/books");
            return;
        }

        // Check for stock issues
        for (CartItem item : cartItems) {
            if (item.getQuantity() > item.getStock()) {
                session.setAttribute("errorMsg", "Item '" + item.getBookTitle() + "' has only " + item.getStock() + " available. Please adjust your cart quantity.");
                response.sendRedirect(request.getContextPath() + "/cart");
                return;
            }
        }

        double grandTotal = cartDAO.getCartTotal(user.getUserId());

        // Refresh user info
        User freshUser = userDAO.getUserById(user.getUserId());

        request.setAttribute("cartItems", cartItems);
        request.setAttribute("grandTotal", grandTotal);
        request.setAttribute("user", freshUser != null ? freshUser : user);

        request.getRequestDispatcher("/checkout.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("loggedUser");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String recipientName = request.getParameter("recipientName");
        String recipientPhone = request.getParameter("recipientPhone");
        String address = request.getParameter("address");
        String city = request.getParameter("city");
        String state = request.getParameter("state");
        String pincode = request.getParameter("pincode");
        String paymentMethod = request.getParameter("paymentMethod");

        if (recipientName == null || recipientName.trim().isEmpty() ||
            recipientPhone == null || recipientPhone.trim().isEmpty() ||
            address == null || address.trim().isEmpty() ||
            paymentMethod == null || paymentMethod.trim().isEmpty()) {
            
            session.setAttribute("errorMsg", "Please provide all required shipping and payment details.");
            response.sendRedirect(request.getContextPath() + "/checkout");
            return;
        }

        String fullDeliveryAddress = address.trim();
        if (city != null && !city.trim().isEmpty()) fullDeliveryAddress += ", " + city.trim();
        if (state != null && !state.trim().isEmpty()) fullDeliveryAddress += ", " + state.trim();
        if (pincode != null && !pincode.trim().isEmpty()) fullDeliveryAddress += " - " + pincode.trim();

        List<CartItem> cartItems = cartDAO.getCartItemsByUser(user.getUserId());
        if (cartItems.isEmpty()) {
            session.setAttribute("errorMsg", "Your cart is empty.");
            response.sendRedirect(request.getContextPath() + "/books");
            return;
        }

        try {
            int orderId = orderDAO.createOrder(
                    user.getUserId(),
                    recipientName.trim(),
                    recipientPhone.trim(),
                    fullDeliveryAddress,
                    paymentMethod.trim(),
                    cartItems
            );

            if (orderId > 0) {
                // Clear session cart count
                session.setAttribute("cartCount", 0);
                session.setAttribute("successMsg", "Your order has been placed successfully!");

                Order placedOrder = orderDAO.getOrderById(orderId);
                request.setAttribute("order", placedOrder);
                request.getRequestDispatcher("/order-confirmation.jsp").forward(request, response);
            } else {
                session.setAttribute("errorMsg", "Failed to process order. Please try again.");
                response.sendRedirect(request.getContextPath() + "/checkout");
            }

        } catch (Exception e) {
            System.err.println("[CheckoutServlet Order Creation Error] " + e.getMessage());
            session.setAttribute("errorMsg", "Checkout Error: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/cart");
        }
    }
}
