<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<c:set var="pageTitle" value="My Profile | YUVAN & THIYAGU & CO." scope="request"/>
<jsp:include page="/includes/header.jsp" />
<jsp:include page="/includes/navbar.jsp" />

<main class="py-5 bg-light">
    <div class="container">
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="${pageContext.request.contextPath}/home" class="text-decoration-none">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Customer Profile</li>
            </ol>
        </nav>

        <jsp:include page="/includes/alerts.jsp" />

        <div class="row g-4">
            <!-- Col 1: Profile Summary Card -->
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm rounded-4 text-center p-4 mb-4">
                    <div class="avatar-circle mx-auto mb-3 bg-primary text-white d-flex justify-content-center align-items-center rounded-circle shadow" style="width: 80px; height: 80px; font-size: 2rem; font-weight: 700;">
                        ${user.name.substring(0, 1).toUpperCase()}
                    </div>
                    <h4 class="fw-bold mb-1">${user.name}</h4>
                    <p class="text-muted small mb-3"><i class="fa-solid fa-envelope me-1"></i> ${user.email}</p>
                    
                    <div class="d-flex justify-content-center gap-2 mb-3">
                        <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-3 py-2 rounded-pill">
                            <i class="fa-solid fa-user-check me-1"></i> Verified Customer
                        </span>
                    </div>

                    <hr class="my-3">

                    <div class="text-start small">
                        <p class="mb-2"><strong><i class="fa-solid fa-phone text-muted me-2"></i>Phone:</strong> ${user.phone}</p>
                        <p class="mb-2"><strong><i class="fa-solid fa-location-dot text-muted me-2"></i>Address:</strong> ${user.fullAddress}</p>
                        <p class="mb-0"><strong><i class="fa-solid fa-calendar text-muted me-2"></i>Member Since:</strong> <fmt:formatDate value="${user.createdAt}" pattern="dd MMM yyyy" /></p>
                    </div>
                </div>

                <!-- Change Password Card -->
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h5 class="fw-bold text-dark mb-3"><i class="fa-solid fa-key text-warning me-2"></i> Change Password</h5>
                    <form action="${pageContext.request.contextPath}/profile" method="post">
                        <input type="hidden" name="action" value="updatePassword">
                        <div class="mb-3">
                            <label class="form-label small fw-semibold text-secondary">Current Password</label>
                            <input type="password" name="currentPassword" class="form-control form-control-sm" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-semibold text-secondary">New Password</label>
                            <input type="password" name="newPassword" class="form-control form-control-sm" minlength="6" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-semibold text-secondary">Confirm New Password</label>
                            <input type="password" name="confirmPassword" class="form-control form-control-sm" minlength="6" required>
                        </div>
                        <button type="submit" class="btn btn-outline-primary btn-sm w-100 fw-bold">Update Password</button>
                    </form>
                </div>
            </div>

            <!-- Col 2: Profile Update & Recent Orders -->
            <div class="col-lg-8">
                <!-- Profile Edit Form -->
                <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
                    <h5 class="fw-bold text-dark mb-3"><i class="fa-solid fa-user-pen text-primary me-2"></i> Edit Account Details</h5>
                    <form action="${pageContext.request.contextPath}/profile" method="post">
                        <input type="hidden" name="action" value="updateProfile">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label small fw-semibold text-secondary">Full Name</label>
                                <input type="text" name="name" class="form-control" value="${user.name}" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-semibold text-secondary">Email Address (Read Only)</label>
                                <input type="email" class="form-control bg-light" value="${user.email}" readonly disabled>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-semibold text-secondary">Contact Phone</label>
                                <input type="tel" name="phone" class="form-control" value="${user.phone}" pattern="[0-9]{10}" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-semibold text-secondary">City</label>
                                <input type="text" name="city" class="form-control" value="${user.city}" required>
                            </div>
                            <div class="col-12">
                                <label class="form-label small fw-semibold text-secondary">Street / Delivery Address</label>
                                <textarea name="address" class="form-control" rows="2" required>${user.address}</textarea>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-semibold text-secondary">State</label>
                                <input type="text" name="state" class="form-control" value="${user.state}" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-semibold text-secondary">Pincode</label>
                                <input type="text" name="pincode" class="form-control" value="${user.pincode}" required>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary px-4 fw-bold">
                                    <i class="fa-solid fa-floppy-disk me-1"></i> Save Changes
                                </button>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- Recent Orders Preview -->
                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="fw-bold text-dark mb-0"><i class="fa-solid fa-box-archive text-success me-2"></i> Recent Orders</h5>
                        <a href="${pageContext.request.contextPath}/orders" class="btn btn-outline-primary btn-sm fw-semibold">View All Orders</a>
                    </div>

                    <c:choose>
                        <c:when test="${not empty recentOrders}">
                            <div class="table-responsive">
                                <table class="table align-middle">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Order ID</th>
                                            <th>Date</th>
                                            <th>Total</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <c:forEach var="ord" items="${recentOrders}" begin="0" end="4">
                                            <tr>
                                                <td class="fw-bold">#${ord.orderId}</td>
                                                <td class="small text-muted">${ord.formattedDate}</td>
                                                <td class="fw-bold text-primary">${ord.formattedTotalAmount}</td>
                                                <td>
                                                    <span class="badge ${ord.statusBadgeClass} rounded-pill">${ord.status}</span>
                                                </td>
                                                <td>
                                                    <a href="${pageContext.request.contextPath}/order-details?id=${ord.orderId}" class="btn btn-light btn-sm border" title="View Details">
                                                        <i class="fa-solid fa-eye"></i>
                                                    </a>
                                                    <a href="${pageContext.request.contextPath}/track-order?id=${ord.orderId}" class="btn btn-light btn-sm border text-primary" title="Track Order">
                                                        <i class="fa-solid fa-truck"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        </c:forEach>
                                    </tbody>
                                </table>
                            </div>
                        </c:when>
                        <c:otherwise>
                            <div class="text-center py-4 text-muted">
                                <i class="fa-solid fa-box-open fs-1 text-secondary mb-2 d-block"></i>
                                <p class="mb-2">You haven't placed any book orders yet.</p>
                                <a href="${pageContext.request.contextPath}/books" class="btn btn-warning btn-sm fw-bold">Start Shopping</a>
                            </div>
                        </c:otherwise>
                    </c:choose>
                </div>
            </div>
        </div>
    </div>
</main>

<jsp:include page="/includes/footer.jsp" />
