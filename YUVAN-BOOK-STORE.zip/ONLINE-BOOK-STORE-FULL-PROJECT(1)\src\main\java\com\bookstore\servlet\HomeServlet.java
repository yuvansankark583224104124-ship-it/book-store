package com.bookstore.servlet;

import com.bookstore.dao.BookDAO;
import com.bookstore.dao.CategoryDAO;
import com.bookstore.model.Book;
import com.bookstore.model.Category;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Controller servlet for the Bookstore Homepage.
 * Loads featured books, recent arrivals, and category list.
 * Company: YUVAN & THIYAGU & CO.
 */
@WebServlet(name = "HomeServlet", urlPatterns = {"", "/home", "/index"})
public class HomeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final BookDAO bookDAO = new BookDAO();
    private final CategoryDAO categoryDAO = new CategoryDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            List<Book> featuredBooks = bookDAO.getFeaturedBooks();
            List<Book> recentBooks = bookDAO.getRecentBooks(8);
            List<Category> categories = categoryDAO.getAllCategories();

            request.setAttribute("featuredBooks", featuredBooks);
            request.setAttribute("recentBooks", recentBooks);
            request.setAttribute("categories", categories);

            request.getRequestDispatcher("/index.jsp").forward(request, response);
        } catch (Exception e) {
            System.err.println("[HomeServlet Error] " + e.getMessage());
            request.setAttribute("errorMsg", "Failed to load homepage catalog.");
            request.getRequestDispatcher("/index.jsp").forward(request, response);
        }
    }
}
