package com.bookstore.servlet;

import com.bookstore.dao.BookDAO;
import com.bookstore.dao.CategoryDAO;
import com.bookstore.model.Book;
import com.bookstore.model.Category;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Controller servlet for Book Browsing and Book Details.
 * Company: YUVAN & THIYAGU & CO.
 */
@WebServlet(name = "BookServlet", urlPatterns = {"/books", "/book-details"})
public class BookServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final BookDAO bookDAO = new BookDAO();
    private final CategoryDAO categoryDAO = new CategoryDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String servletPath = request.getServletPath();

        if ("/book-details".equals(servletPath)) {
            handleBookDetails(request, response);
        } else {
            handleBookCatalog(request, response);
        }
    }

    private void handleBookCatalog(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String catIdParam = request.getParameter("category");
        List<Book> books;
        Category activeCategory = null;

        if (catIdParam != null && !catIdParam.trim().isEmpty()) {
            try {
                int catId = Integer.parseInt(catIdParam);
                books = bookDAO.getBooksByCategory(catId);
                activeCategory = categoryDAO.getCategoryById(catId);
            } catch (NumberFormatException e) {
                books = bookDAO.getAllBooks();
            }
        } else {
            books = bookDAO.getAllBooks();
        }

        List<Category> categories = categoryDAO.getCategoriesWithBookCount();

        request.setAttribute("books", books);
        request.setAttribute("categories", categories);
        request.setAttribute("activeCategory", activeCategory);
        request.getRequestDispatcher("/books.jsp").forward(request, response);
    }

    private void handleBookDetails(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idParam = request.getParameter("id");
        if (idParam == null || idParam.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/books");
            return;
        }

        try {
            int bookId = Integer.parseInt(idParam);
            Book book = bookDAO.getBookById(bookId);

            if (book == null) {
                request.getSession().setAttribute("errorMsg", "Book not found.");
                response.sendRedirect(request.getContextPath() + "/books");
                return;
            }

            List<Book> relatedBooks = bookDAO.getBooksByCategory(book.getCategoryId());
            // Remove self from related list
            relatedBooks.removeIf(b -> b.getBookId() == book.getBookId());

            request.setAttribute("book", book);
            request.setAttribute("relatedBooks", relatedBooks);
            request.getRequestDispatcher("/book-details.jsp").forward(request, response);

        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/books");
        }
    }
}
