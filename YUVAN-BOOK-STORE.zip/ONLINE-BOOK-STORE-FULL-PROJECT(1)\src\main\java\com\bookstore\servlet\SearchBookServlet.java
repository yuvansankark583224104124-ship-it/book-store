package com.bookstore.servlet;

import com.bookstore.dao.BookDAO;
import com.bookstore.dao.CategoryDAO;
import com.bookstore.model.Book;
import com.bookstore.model.Category;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Controller servlet for multi-parameter search (Title, Author, ISBN, Category).
 * Company: YUVAN & THIYAGU & CO.
 */
@WebServlet(name = "SearchBookServlet", urlPatterns = {"/search"})
public class SearchBookServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final BookDAO bookDAO = new BookDAO();
    private final CategoryDAO categoryDAO = new CategoryDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String keyword = request.getParameter("q");
        if (keyword == null) {
            keyword = "";
        }
        keyword = keyword.trim();

        List<Book> searchResults = bookDAO.searchBooks(keyword);
        List<Category> categories = categoryDAO.getAllCategories();

        request.setAttribute("keyword", keyword);
        request.setAttribute("books", searchResults);
        request.setAttribute("resultCount", searchResults.size());
        request.setAttribute("categories", categories);

        request.getRequestDispatcher("/search-results.jsp").forward(request, response);
    }
}
