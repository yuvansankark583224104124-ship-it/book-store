package com.bookstore.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Model class representing a simple Cart entry.
 * Company: YUVAN & PRASUN & CO.
 */
public class Cart implements Serializable {
    private static final long serialVersionUID = 1L;

    private int cartId;
    private int userId;
    private int bookId;
    private int quantity;
    private Timestamp addedAt;

    public Cart() {
    }

    public Cart(int cartId, int userId, int bookId, int quantity, Timestamp addedAt) {
        this.cartId = cartId;
        this.userId = userId;
        this.bookId = bookId;
        this.quantity = quantity;
        this.addedAt = addedAt;
    }

    public Cart(int userId, int bookId, int quantity) {
        this.userId = userId;
        this.bookId = bookId;
        this.quantity = quantity;
    }

    public int getCartId() {
        return cartId;
    }

    public void setCartId(int cartId) {
        this.cartId = cartId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Timestamp getAddedAt() {
        return addedAt;
    }

    public void setAddedAt(Timestamp addedAt) {
        this.addedAt = addedAt;
    }
}
