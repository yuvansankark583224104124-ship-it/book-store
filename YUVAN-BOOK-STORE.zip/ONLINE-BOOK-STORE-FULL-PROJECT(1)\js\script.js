﻿/**
 * ==========================================================================
 * YUVAN BOOK STORE - ONLINE BOOK STORE MANAGEMENT SYSTEM
 * Main Frontend JavaScript (Vanilla JS & LocalStorage Demo Interactions)
 * ==========================================================================
 */

// 1. Initial Books Dataset (Static Sample Data)
const SAMPLE_BOOKS = [
    {
        id: 1,
        title: "Java Programming: Complete Reference",
        author: "Herbert Schildt",
        category: "Programming",
        price: 850,
        stock: 25,
        rating: 4.8,
        reviewsCount: 142,
        publisher: "McGraw Hill Education",
        isbn: "978-1260440232",
        description: "The definitive guide to Java programming. Fully updated for Java SE 17, this comprehensive resource explains how to develop, compile, debug, and run Java programs with rich examples.",
        image: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400&q=80"
    },
    {
        id: 2,
        title: "Python Programming & Data Science",
        author: "Dr. R. Nageswara Rao",
        category: "Programming",
        price: 580,
        stock: 18,
        rating: 4.7,
        reviewsCount: 98,
        publisher: "Dreamtech Press",
        isbn: "978-9386052308",
        description: "Master Python programming concepts from basic syntax to OOP, GUI development, databases, algorithms, and data science libraries like NumPy and Pandas.",
        image: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=400&q=80"
    },
    {
        id: 3,
        title: "Web Development with HTML5, CSS3 & JS",
        author: "Jon Duckett",
        category: "Technology",
        price: 720,
        stock: 15,
        rating: 4.9,
        reviewsCount: 230,
        publisher: "John Wiley & Sons",
        isbn: "978-1119038634",
        description: "A full-color, visual introduction to modern web standards, responsive design, interactive JavaScript behaviors, and frontend development best practices.",
        image: "https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=400&q=80"
    },
    {
        id: 4,
        title: "Data Structures & Algorithms in Java",
        author: "Robert Lafore",
        category: "Education",
        price: 640,
        stock: 12,
        rating: 4.6,
        reviewsCount: 75,
        publisher: "Pearson Education",
        isbn: "978-0672324536",
        description: "An intuitive approach to mastering fundamental data structures including arrays, stacks, queues, trees, heaps, graphs, sorting, and algorithmic complexity.",
        image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400&q=80"
    },
    {
        id: 5,
        title: "Database Management Systems",
        author: "Raghu Ramakrishnan & Johannes Gehrke",
        category: "Education",
        price: 790,
        stock: 20,
        rating: 4.7,
        reviewsCount: 110,
        publisher: "McGraw Hill",
        isbn: "978-0072465631",
        description: "Comprehensive coverage of relational databases, SQL queries, normalization, transaction processing, indexing, storage management, and concurrency control.",
        image: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&q=80"
    },
    {
        id: 6,
        title: "Artificial Intelligence: Modern Approach",
        author: "Stuart Russell & Peter Norvig",
        category: "Technology",
        price: 1150,
        stock: 10,
        rating: 4.9,
        reviewsCount: 310,
        publisher: "Pearson",
        isbn: "978-0134610993",
        description: "The leading textbook in Artificial Intelligence used in leading universities worldwide. Covers neural networks, probabilistic reasoning, robotics, and reinforcement learning.",
        image: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=400&q=80"
    },
    {
        id: 7,
        title: "Machine Learning: A Probabilistic Perspective",
        author: "Kevin P. Murphy",
        category: "Technology",
        price: 980,
        stock: 8,
        rating: 4.8,
        reviewsCount: 88,
        publisher: "MIT Press",
        isbn: "978-0262018029",
        description: "A comprehensive and self-contained introduction to machine learning using probabilistic models. Ideal for graduate students, researchers, and engineers.",
        image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=400&q=80"
    },
    {
        id: 8,
        title: "The Alchemist",
        author: "Paulo Coelho",
        category: "Fiction",
        price: 350,
        stock: 40,
        rating: 4.8,
        reviewsCount: 520,
        publisher: "HarperCollins",
        isbn: "978-0062315007",
        description: "A global bestseller recounting the mystical story of Santiago, an Andalusian shepherd boy who journeys to Egypt in search of his personal legend and worldly treasures.",
        image: "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=400&q=80"
    },
    {
        id: 9,
        title: "Atomic Habits",
        author: "James Clear",
        category: "Self Development",
        price: 499,
        stock: 50,
        rating: 4.9,
        reviewsCount: 890,
        publisher: "Avery / Penguin",
        isbn: "978-0735211292",
        description: "A transformative framework for improving every day. Discover how small, incremental habits compound into remarkable, life-changing achievements.",
        image: "https://images.unsplash.com/photo-1541963463532-d68292c34b19?w=400&q=80"
    },
    {
        id: 10,
        title: "Rich Dad Poor Dad",
        author: "Robert T. Kiyosaki",
        category: "Business",
        price: 399,
        stock: 35,
        rating: 4.7,
        reviewsCount: 670,
        publisher: "Plata Publishing",
        isbn: "978-1612680194",
        description: "What the rich teach their kids about money that the poor and middle class do not. The number one personal finance guide of all time.",
        image: "https://images.unsplash.com/photo-1553729459-efe14ef6055d?w=400&q=80"
    },
    {
        id: 11,
        title: "Clean Code: Handbook of Agile Software",
        author: "Robert C. Martin",
        category: "Programming",
        price: 650,
        stock: 14,
        rating: 4.8,
        reviewsCount: 340,
        publisher: "Prentice Hall",
        isbn: "978-0132350884",
        description: "Learn the crafts and disciplines that distinguish a professional software craftsman. Contains invaluable principles for writing readable, maintainable software.",
        image: "https://images.unsplash.com/photo-1532012164546-f432f2e3777a?w=400&q=80"
    },
    {
        id: 12,
        title: "Computer Networks: A Top-Down Approach",
        author: "James Kurose & Keith Ross",
        category: "Education",
        price: 750,
        stock: 16,
        rating: 4.6,
        reviewsCount: 104,
        publisher: "Pearson",
        isbn: "978-0133594140",
        description: "Motivates students through a modern top-down approach focusing on the Internet and fundamental networking protocols, socket programming, and network security.",
        image: "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400&q=80"
    }
];

// 2. Shopping Cart Helper using LocalStorage
const CartManager = {
    STORAGE_KEY: "YTC_BOOKSTORE_CART",

    getCart() {
        try {
            const data = localStorage.getItem(this.STORAGE_KEY);
            return data ? JSON.parse(data) : [];
        } catch (e) {
            return [];
        }
    },

    saveCart(cart) {
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(cart));
        this.updateBadge();
    },

    addItem(bookId, quantity = 1) {
        const book = SAMPLE_BOOKS.find(b => b.id === Number(bookId));
        if (!book) return false;

        const cart = this.getCart();
        const existing = cart.find(item => item.id === book.id);

        if (existing) {
            existing.quantity += Number(quantity);
            if (existing.quantity > book.stock) {
                existing.quantity = book.stock;
                alert(`Maximum available stock for '${book.title}' is ${book.stock} units.`);
            }
        } else {
            const qty = Math.min(Number(quantity), book.stock);
            cart.push({
                id: book.id,
                title: book.title,
                author: book.author,
                price: book.price,
                stock: book.stock,
                image: book.image,
                category: book.category,
                quantity: qty
            });
        }

        this.saveCart(cart);
        this.showToast(`'${book.title}' added to cart!`);
        return true;
    },

    updateQuantity(bookId, newQty) {
        const cart = this.getCart();
        const item = cart.find(i => i.id === Number(bookId));
        if (item) {
            if (newQty <= 0) {
                this.removeItem(bookId);
                return;
            }
            if (newQty > item.stock) {
                alert(`Only ${item.stock} copies available in stock.`);
                item.quantity = item.stock;
            } else {
                item.quantity = newQty;
            }
            this.saveCart(cart);
        }
    },

    removeItem(bookId) {
        let cart = this.getCart();
        cart = cart.filter(item => item.id !== Number(bookId));
        this.saveCart(cart);
        this.showToast("Item removed from cart.");
    },

    clearCart() {
        localStorage.removeItem(this.STORAGE_KEY);
        this.updateBadge();
    },

    getCartCount() {
        const cart = this.getCart();
        return cart.reduce((total, item) => total + item.quantity, 0);
    },

    calculateTotals() {
        const cart = this.getCart();
        const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        // Free delivery over ₹1000, else ₹50
        const delivery = subtotal > 1000 || subtotal === 0 ? 0 : 50;
        const grandTotal = subtotal + delivery;
        return { subtotal, delivery, grandTotal };
    },

    updateBadge() {
        const badges = document.querySelectorAll('.cart-badge');
        const count = this.getCartCount();
        badges.forEach(b => {
            b.textContent = count;
            b.style.display = count > 0 ? 'inline-flex' : 'none';
        });
    },

    showToast(message) {
        let toast = document.getElementById('ytc-toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'ytc-toast';
            toast.style.cssText = `
                position: fixed;
                bottom: 24px;
                right: 24px;
                background-color: #0f172a;
                color: #ffffff;
                padding: 12px 24px;
                border-radius: 8px;
                font-weight: 600;
                font-size: 0.95rem;
                box-shadow: 0 10px 25px rgba(0,0,0,0.3);
                border-left: 4px solid #f59e0b;
                z-index: 9999;
                transition: opacity 0.3s ease, transform 0.3s ease;
                opacity: 0;
                transform: translateY(20px);
            `;
            document.body.appendChild(toast);
        }
        toast.textContent = message;
        toast.style.opacity = '1';
        toast.style.transform = 'translateY(0)';
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(20px)';
        }, 3000);
    }
};

// 3. Page Initializers
document.addEventListener('DOMContentLoaded', () => {
    CartManager.updateBadge();

    // Mobile Navbar Toggle
    const toggleBtn = document.querySelector('.mobile-toggle');
    const navMenu = document.querySelector('.nav-menu');
    if (toggleBtn && navMenu) {
        toggleBtn.addEventListener('click', () => {
            navMenu.classList.toggle('show');
        });
    }

    // Auto-detect page and run relevant logic
    const currentPath = window.location.pathname;

    if (currentPath.includes('books.html')) {
        initBooksCatalog();
    } else if (currentPath.includes('book-details.html')) {
        initBookDetails();
    } else if (currentPath.includes('cart.html')) {
        initCartPage();
    } else if (currentPath.includes('checkout.html')) {
        initCheckoutPage();
    } else if (currentPath.includes('order-confirmation.html')) {
        initOrderConfirmation();
    } else if (currentPath.includes('track-order.html')) {
        initTrackOrder();
    }
});

// 4. Books Catalog Filtering & Search
function initBooksCatalog() {
    const grid = document.getElementById('booksCatalogGrid');
    const searchInput = document.getElementById('catalogSearchInput');
    const categoryBtns = document.querySelectorAll('.category-filter-btn');
    const countLabel = document.getElementById('catalogCount');

    let activeCategory = "All";
    let searchQuery = "";

    // Check URL query parameters (e.g. ?category=Programming or ?q=Java)
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('category')) {
        activeCategory = urlParams.get('category');
    }
    if (urlParams.has('q')) {
        searchQuery = urlParams.get('q').toLowerCase();
        if (searchInput) searchInput.value = searchQuery;
    }

    function renderFilteredBooks() {
        if (!grid) return;
        let filtered = SAMPLE_BOOKS.filter(book => {
            const matchesCat = activeCategory === "All" || book.category.toLowerCase() === activeCategory.toLowerCase();
            const matchesSearch = !searchQuery || 
                book.title.toLowerCase().includes(searchQuery) ||
                book.author.toLowerCase().includes(searchQuery) ||
                book.category.toLowerCase().includes(searchQuery) ||
                book.isbn.includes(searchQuery);
            return matchesCat && matchesSearch;
        });

        if (countLabel) {
            countLabel.textContent = `Showing ${filtered.length} books`;
        }

        if (filtered.length === 0) {
            grid.innerHTML = `
                <div style="grid-column: 1 / -1; text-align: center; padding: 4rem 1rem;">
                    <i class="fa-solid fa-book-open" style="font-size: 3rem; color: #94a3b8; margin-bottom: 1rem;"></i>
                    <h3 style="font-weight: 700; color: #1e293b;">No Books Found</h3>
                    <p style="color: #64748b;">Try adjusting your keyword or selecting a different category filter.</p>
                </div>
            `;
            return;
        }

        grid.innerHTML = filtered.map(book => `
            <div class="book-card">
                <div class="book-img-wrapper">
                    <span class="book-category-tag">${book.category}</span>
                    <img src="${book.image}" alt="${book.title}" loading="lazy">
                </div>
                <div class="book-card-body">
                    <div class="book-rating">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                        <span>${book.rating} (${book.reviewsCount})</span>
                    </div>
                    <h3 class="book-title" title="${book.title}">${book.title}</h3>
                    <p class="book-author">By ${book.author}</p>
                    <div class="book-card-footer">
                        <div>
                            <div class="book-price">₹${book.price}</div>
                            <span class="badge ${book.stock > 5 ? 'badge-success' : 'badge-warning'}">
                                ${book.stock > 0 ? (book.stock <= 5 ? `Low Stock (${book.stock})` : 'In Stock') : 'Out of Stock'}
                            </span>
                        </div>
                        <div class="book-actions">
                            <a href="book-details.html?id=${book.id}" class="btn btn-outline btn-sm" title="View Details">
                                <i class="fa-solid fa-eye"></i>
                            </a>
                            <button onclick="CartManager.addItem(${book.id}, 1)" class="btn btn-primary btn-sm" title="Add to Cart">
                                <i class="fa-solid fa-cart-plus"></i> Add
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `).join('');
    }

    // Category button clicks
    categoryBtns.forEach(btn => {
        const cat = btn.dataset.category;
        if (cat.toLowerCase() === activeCategory.toLowerCase()) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }

        btn.addEventListener('click', () => {
            categoryBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            activeCategory = btn.dataset.category;
            renderFilteredBooks();
        });
    });

    // Search input typing
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            searchQuery = e.target.value.trim().toLowerCase();
            renderFilteredBooks();
        });
    }

    renderFilteredBooks();
}

// 5. Book Details Page Loader
function initBookDetails() {
    const urlParams = new URLSearchParams(window.location.search);
    const bookId = Number(urlParams.get('id')) || 1;
    const book = SAMPLE_BOOKS.find(b => b.id === bookId) || SAMPLE_BOOKS[0];

    // Populate elements
    const titleEl = document.getElementById('detailTitle');
    const authorEl = document.getElementById('detailAuthor');
    const categoryEl = document.getElementById('detailCategory');
    const priceEl = document.getElementById('detailPrice');
    const stockEl = document.getElementById('detailStock');
    const descEl = document.getElementById('detailDesc');
    const imgEl = document.getElementById('detailImage');
    const publisherEl = document.getElementById('detailPublisher');
    const isbnEl = document.getElementById('detailIsbn');
    const ratingEl = document.getElementById('detailRating');

    if (titleEl) titleEl.textContent = book.title;
    if (authorEl) authorEl.textContent = "By " + book.author;
    if (categoryEl) categoryEl.textContent = book.category;
    if (priceEl) priceEl.textContent = "₹" + book.price;
    if (descEl) descEl.textContent = book.description;
    if (imgEl) imgEl.src = book.image;
    if (publisherEl) publisherEl.textContent = book.publisher;
    if (isbnEl) isbnEl.textContent = book.isbn;
    if (ratingEl) ratingEl.textContent = `${book.rating} (${book.reviewsCount} customer reviews)`;

    if (stockEl) {
        stockEl.textContent = book.stock > 0 ? `In Stock (${book.stock} available)` : "Out of Stock";
        stockEl.className = `badge ${book.stock > 5 ? 'badge-success' : 'badge-warning'}`;
    }

    // Quantity selector buttons
    const qtyInput = document.getElementById('detailQtyInput');
    const btnMinus = document.getElementById('detailQtyMinus');
    const btnPlus = document.getElementById('detailQtyPlus');
    const addBtn = document.getElementById('detailAddToCartBtn');
    const buyNowBtn = document.getElementById('detailBuyNowBtn');

    if (btnMinus && btnPlus && qtyInput) {
        btnMinus.addEventListener('click', () => {
            let val = parseInt(qtyInput.value) || 1;
            if (val > 1) qtyInput.value = val - 1;
        });

        btnPlus.addEventListener('click', () => {
            let val = parseInt(qtyInput.value) || 1;
            if (val < book.stock) qtyInput.value = val + 1;
            else alert(`Only ${book.stock} units available.`);
        });
    }

    if (addBtn) {
        addBtn.addEventListener('click', () => {
            const qty = parseInt(qtyInput ? qtyInput.value : 1) || 1;
            CartManager.addItem(book.id, qty);
        });
    }

    if (buyNowBtn) {
        buyNowBtn.addEventListener('click', () => {
            const qty = parseInt(qtyInput ? qtyInput.value : 1) || 1;
            CartManager.addItem(book.id, qty);
            window.location.href = "checkout.html";
        });
    }
}

// 6. Cart Page Loader
function initCartPage() {
    const tableBody = document.getElementById('cartTableBody');
    const emptyMsg = document.getElementById('cartEmptyMessage');
    const cartWrapper = document.getElementById('cartContentWrapper');
    const subtotalEl = document.getElementById('cartSubtotal');
    const deliveryEl = document.getElementById('cartDelivery');
    const totalEl = document.getElementById('cartTotal');

    function render() {
        const cart = CartManager.getCart();

        if (cart.length === 0) {
            if (emptyMsg) emptyMsg.style.display = 'block';
            if (cartWrapper) cartWrapper.style.display = 'none';
            return;
        }

        if (emptyMsg) emptyMsg.style.display = 'none';
        if (cartWrapper) cartWrapper.style.display = 'grid';

        if (tableBody) {
            tableBody.innerHTML = cart.map(item => `
                <tr>
                    <td>
                        <div class="cart-item-preview">
                            <img src="${item.image}" alt="${item.title}">
                            <div class="cart-item-info">
                                <h4>${item.title}</h4>
                                <p>By ${item.author} | <span class="badge badge-info">${item.category}</span></p>
                            </div>
                        </div>
                    </td>
                    <td class="fw-bold">₹${item.price}</td>
                    <td>
                        <div class="qty-control">
                            <button class="qty-btn" onclick="CartManager.updateQuantity(${item.id}, ${item.quantity - 1}); initCartPage();">-</button>
                            <input type="text" class="qty-input" value="${item.quantity}" readonly>
                            <button class="qty-btn" onclick="CartManager.updateQuantity(${item.id}, ${item.quantity + 1}); initCartPage();">+</button>
                        </div>
                    </td>
                    <td class="fw-bold text-primary">₹${item.price * item.quantity}</td>
                    <td>
                        <button onclick="CartManager.removeItem(${item.id}); initCartPage();" class="btn btn-danger btn-sm" title="Remove Item">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `).join('');
        }

        const totals = CartManager.calculateTotals();
        if (subtotalEl) subtotalEl.textContent = `₹${totals.subtotal}`;
        if (deliveryEl) deliveryEl.textContent = totals.delivery === 0 ? "FREE" : `₹${totals.delivery}`;
        if (totalEl) totalEl.textContent = `₹${totals.grandTotal}`;
    }

    render();
}

// 7. Checkout Page Handler
function initCheckoutPage() {
    const summaryItems = document.getElementById('checkoutSummaryItems');
    const subtotalEl = document.getElementById('checkoutSubtotal');
    const deliveryEl = document.getElementById('checkoutDelivery');
    const grandTotalEl = document.getElementById('checkoutGrandTotal');
    const checkoutForm = document.getElementById('checkoutForm');

    const cart = CartManager.getCart();
    if (cart.length === 0) {
        alert("Your cart is empty. Redirecting to books catalog...");
        window.location.href = "books.html";
        return;
    }

    if (summaryItems) {
        summaryItems.innerHTML = cart.map(item => `
            <div style="display: flex; justify-content: space-between; margin-bottom: 0.75rem; font-size: 0.92rem;">
                <div>
                    <span style="font-weight: 600;">${item.title}</span>
                    <span style="color: #64748b; display: block; font-size: 0.8rem;">Qty: ${item.quantity} × ₹${item.price}</span>
                </div>
                <div style="font-weight: 700;">₹${item.price * item.quantity}</div>
            </div>
        `).join('');
    }

    const totals = CartManager.calculateTotals();
    if (subtotalEl) subtotalEl.textContent = `₹${totals.subtotal}`;
    if (deliveryEl) deliveryEl.textContent = totals.delivery === 0 ? "FREE" : `₹${totals.delivery}`;
    if (grandTotalEl) grandTotalEl.textContent = `₹${totals.grandTotal}`;

    if (checkoutForm) {
        checkoutForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const name = document.getElementById('custName').value;
            const address = document.getElementById('custAddress').value;
            const city = document.getElementById('custCity').value;
            const state = document.getElementById('custState').value;
            const pincode = document.getElementById('custPincode').value;
            const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked').value;

            // Generate Mock Order Object
            const mockOrder = {
                orderId: "YTC" + Math.floor(1000 + Math.random() * 9000),
                customerName: name,
                orderDate: new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }),
                totalAmount: totals.grandTotal,
                paymentMethod: paymentMethod,
                deliveryAddress: `${address}, ${city}, ${state} - ${pincode}`,
                status: "Confirmed",
                items: cart
            };

            // Save last placed order
            localStorage.setItem("YTC_LAST_ORDER", JSON.stringify(mockOrder));

            // Clear cart
            CartManager.clearCart();

            // Redirect
            window.location.href = "order-confirmation.html";
        });
    }
}

// 8. Order Confirmation Page Loader
function initOrderConfirmation() {
    const rawOrder = localStorage.getItem("YTC_LAST_ORDER");
    const order = rawOrder ? JSON.parse(rawOrder) : {
        orderId: "YTC1001",
        customerName: "Karthik Raja",
        orderDate: new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }),
        totalAmount: 1250,
        paymentMethod: "Cash on Delivery",
        deliveryAddress: "12, Anna Nagar West, Chennai, Tamil Nadu - 600040",
        status: "Confirmed"
    };

    const idEl = document.getElementById('confOrderId');
    const nameEl = document.getElementById('confCustomerName');
    const dateEl = document.getElementById('confOrderDate');
    const totalEl = document.getElementById('confTotal');
    const paymentEl = document.getElementById('confPayment');
    const addressEl = document.getElementById('confAddress');
    const trackLink = document.getElementById('confTrackLink');

    if (idEl) idEl.textContent = order.orderId;
    if (nameEl) nameEl.textContent = order.customerName;
    if (dateEl) dateEl.textContent = order.orderDate;
    if (totalEl) totalEl.textContent = `₹${order.totalAmount}`;
    if (paymentEl) paymentEl.textContent = order.paymentMethod;
    if (addressEl) addressEl.textContent = order.deliveryAddress;
    if (trackLink) trackLink.href = `track-order.html?id=${order.orderId}`;
}

// 9. Order Tracking Simulation
function initTrackOrder() {
    const urlParams = new URLSearchParams(window.location.search);
    const orderId = urlParams.get('id') || "YTC1001";

    const idEl = document.getElementById('trackOrderId');
    if (idEl) idEl.textContent = orderId;
}
