<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<c:set var="pageTitle" value="Customer Registration | YUVAN & THIYAGU & CO." scope="request"/>
<jsp:include page="/includes/header.jsp" />
<jsp:include page="/includes/navbar.jsp" />

<main class="py-5 bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10 col-lg-8">
                <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
                    <div class="card-header bg-primary text-white text-center py-4" style="background: linear-gradient(135deg, #1e3a8a 0%, #0f172a 100%) !important;">
                        <i class="fa-solid fa-user-plus text-warning fs-1 mb-2"></i>
                        <h4 class="fw-bold mb-1">Create Customer Account</h4>
                        <p class="text-light opacity-75 small mb-0">Join YUVAN &amp; THIYAGU &amp; CO. for quick ordering &amp; book tracking</p>
                    </div>

                    <div class="card-body p-4 p-md-5">
                        <jsp:include page="/includes/alerts.jsp" />

                        <form action="${pageContext.request.contextPath}/register" method="post">
                            <div class="row g-3">
                                <!-- Full Name -->
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold text-secondary small">Full Name <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light"><i class="fa-solid fa-user text-muted"></i></span>
                                        <input type="text" class="form-control" name="name" value="${name}" placeholder="e.g. Karthik Raja" required>
                                    </div>
                                </div>

                                <!-- Email -->
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold text-secondary small">Email Address <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light"><i class="fa-solid fa-envelope text-muted"></i></span>
                                        <input type="email" class="form-control" name="email" value="${email}" placeholder="karthik@example.com" required>
                                    </div>
                                </div>

                                <!-- Password -->
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold text-secondary small">Password <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light"><i class="fa-solid fa-lock text-muted"></i></span>
                                        <input type="password" class="form-control" name="password" placeholder="Minimum 6 characters" minlength="6" required>
                                    </div>
                                </div>

                                <!-- Confirm Password -->
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold text-secondary small">Confirm Password <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light"><i class="fa-solid fa-lock-open text-muted"></i></span>
                                        <input type="password" class="form-control" name="confirmPassword" placeholder="Re-enter password" minlength="6" required>
                                    </div>
                                </div>

                                <!-- Phone -->
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold text-secondary small">Mobile Phone Number <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light"><i class="fa-solid fa-phone text-muted"></i></span>
                                        <input type="tel" class="form-control" name="phone" value="${phone}" placeholder="10-digit mobile number" pattern="[0-9]{10}" required>
                                    </div>
                                </div>

                                <!-- City -->
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold text-secondary small">City <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light"><i class="fa-solid fa-city text-muted"></i></span>
                                        <input type="text" class="form-control" name="city" value="${city != null ? city : 'Chennai'}" placeholder="e.g. Chennai" required>
                                    </div>
                                </div>

                                <!-- Street Address -->
                                <div class="col-12">
                                    <label class="form-label fw-semibold text-secondary small">Delivery / Street Address <span class="text-danger">*</span></label>
                                    <textarea class="form-control" name="address" rows="3" placeholder="Door No, Street Name, Landmark..." required>${address}</textarea>
                                </div>

                                <!-- State & Pincode -->
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold text-secondary small">State <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="state" value="${state != null ? state : 'Tamil Nadu'}" required>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-semibold text-secondary small">Pincode / Postal Code <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="pincode" value="${pincode != null ? pincode : '600001'}" placeholder="e.g. 600040" required>
                                </div>

                                <div class="col-12 mt-4">
                                    <button type="submit" class="btn btn-warning w-100 py-2 fw-bold text-dark shadow-sm">
                                        <i class="fa-solid fa-user-plus me-2"></i> Register Account
                                    </button>
                                </div>
                            </div>
                        </form>

                        <div class="text-center mt-4 pt-3 border-top">
                            <p class="text-muted small mb-0">
                                Already have an account? 
                                <a href="${pageContext.request.contextPath}/login.jsp" class="text-primary fw-bold text-decoration-none">Log In Here</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<jsp:include page="/includes/footer.jsp" />
