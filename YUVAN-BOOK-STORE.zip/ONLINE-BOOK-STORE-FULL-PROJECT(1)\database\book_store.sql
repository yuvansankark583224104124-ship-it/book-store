﻿-- ==========================================================
-- ONLINE BOOK STORE MANAGEMENT SYSTEM
-- COMPANY: YUVAN BOOK STORE
-- DATABASE SCRIPT: book_store.sql
-- COMPATIBLE WITH: MySQL 5.7+ / MySQL 8.0+
-- ==========================================================

-- 1. Create Database if not exists
CREATE DATABASE IF NOT EXISTS `book_store` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `book_store`;

-- Disable Foreign Key Checks temporarily for clean execution
SET FOREIGN_KEY_CHECKS = 0;

-- Drop existing tables in reverse order of dependencies
DROP TABLE IF EXISTS `payments`;
DROP TABLE IF EXISTS `order_details`;
DROP TABLE IF EXISTS `orders`;
DROP TABLE IF EXISTS `cart`;
DROP TABLE IF EXISTS `books`;
DROP TABLE IF EXISTS `categories`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `admin`;

SET FOREIGN_KEY_CHECKS = 1;

-- ==========================================================
-- TABLE 1: admin
-- Stores administrative user credentials and profile
-- ==========================================================
CREATE TABLE `admin` (
    `admin_id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `full_name` VARCHAR(100) NOT NULL DEFAULT 'System Administrator',
    `email` VARCHAR(100) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================================
-- TABLE 2: users
-- Stores registered customer accounts
-- ==========================================================
CREATE TABLE `users` (
    `user_id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `email` VARCHAR(100) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `phone` VARCHAR(20) NOT NULL,
    `address` TEXT NOT NULL,
    `city` VARCHAR(50) DEFAULT 'Chennai',
    `state` VARCHAR(50) DEFAULT 'Tamil Nadu',
    `pincode` VARCHAR(10) DEFAULT '600001',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================================
-- TABLE 3: categories
-- Stores book categorization data
-- ==========================================================
CREATE TABLE `categories` (
    `category_id` INT AUTO_INCREMENT PRIMARY KEY,
    `category_name` VARCHAR(100) NOT NULL UNIQUE,
    `description` VARCHAR(255) DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================================
-- TABLE 4: books
-- Stores book catalog, details, pricing, and live inventory
-- ==========================================================
CREATE TABLE `books` (
    `book_id` INT AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(255) NOT NULL,
    `author` VARCHAR(150) NOT NULL,
    `category_id` INT NOT NULL,
    `publisher` VARCHAR(150) NOT NULL,
    `isbn` VARCHAR(20) NOT NULL UNIQUE,
    `price` DECIMAL(10, 2) NOT NULL CHECK (`price` >= 0),
    `stock` INT NOT NULL DEFAULT 0 CHECK (`stock` >= 0),
    `description` TEXT NOT NULL,
    `image_url` VARCHAR(255) DEFAULT 'default_book.png',
    `featured` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_books_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================================
-- TABLE 5: cart
-- Stores shopping cart items per user
-- ==========================================================
CREATE TABLE `cart` (
    `cart_id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `book_id` INT NOT NULL,
    `quantity` INT NOT NULL DEFAULT 1 CHECK (`quantity` > 0),
    `added_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_cart_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
    CONSTRAINT `fk_cart_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`book_id`) ON DELETE CASCADE,
    CONSTRAINT `uq_user_book` UNIQUE (`user_id`, `book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================================
-- TABLE 6: orders
-- Stores customer orders, shipping, and fulfillment status
-- ==========================================================
CREATE TABLE `orders` (
    `order_id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `order_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `total_amount` DECIMAL(10, 2) NOT NULL CHECK (`total_amount` >= 0),
    `status` ENUM('PLACED', 'CONFIRMED', 'SHIPPED', 'OUT FOR DELIVERY', 'DELIVERED', 'CANCELLED') NOT NULL DEFAULT 'PLACED',
    `recipient_name` VARCHAR(100) NOT NULL,
    `recipient_phone` VARCHAR(20) NOT NULL,
    `delivery_address` TEXT NOT NULL,
    `payment_method` VARCHAR(50) NOT NULL DEFAULT 'Cash on Delivery',
    CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================================
-- TABLE 7: order_details
-- Stores individual line items within each order
-- ==========================================================
CREATE TABLE `order_details` (
    `order_detail_id` INT AUTO_INCREMENT PRIMARY KEY,
    `order_id` INT NOT NULL,
    `book_id` INT NOT NULL,
    `quantity` INT NOT NULL CHECK (`quantity` > 0),
    `price` DECIMAL(10, 2) NOT NULL CHECK (`price` >= 0),
    CONSTRAINT `fk_order_details_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE,
    CONSTRAINT `fk_order_details_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`book_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================================
-- TABLE 8: payments
-- Stores transaction records for orders
-- ==========================================================
CREATE TABLE `payments` (
    `payment_id` INT AUTO_INCREMENT PRIMARY KEY,
    `order_id` INT NOT NULL UNIQUE,
    `payment_method` VARCHAR(50) NOT NULL,
    `amount` DECIMAL(10, 2) NOT NULL,
    `payment_status` ENUM('PENDING', 'COMPLETED', 'FAILED', 'REFUNDED') NOT NULL DEFAULT 'PENDING',
    `payment_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `transaction_ref` VARCHAR(100) DEFAULT NULL,
    CONSTRAINT `fk_payments_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================================
-- SAMPLE DATA INSERTIONS
-- ==========================================================

-- 1. Insert Default Administrator
-- Default credentials: username = admin, password = admin123
INSERT INTO `admin` (`username`, `password`, `full_name`, `email`) VALUES
('admin', 'admin123', 'Yuvan Book Store Administrator', 'admin@yuvanbookstore.com');

-- 2. Insert Standard Categories
INSERT INTO `categories` (`category_id`, `category_name`, `description`) VALUES
(1, 'Programming', 'Software development, algorithms, web technologies, and programming languages.'),
(2, 'Fiction', 'Imaginative novels, short stories, thrillers, and literary fiction.'),
(3, 'Non-Fiction', 'History, philosophy, essays, memoirs, and real-world investigations.'),
(4, 'Science', 'Physics, chemistry, astronomy, biology, and scientific discoveries.'),
(5, 'Technology', 'Artificial intelligence, cloud computing, cybersecurity, and hardware.'),
(6, 'Business', 'Economics, management, entrepreneurship, investing, and leadership.'),
(7, 'Biography', 'Life stories of inspiring leaders, scientists, artists, and innovators.'),
(8, 'Education', 'Academic textbooks, competitive exams, engineering, and mathematics.');

-- 3. Insert Sample Registered Customers
INSERT INTO `users` (`user_id`, `name`, `email`, `password`, `phone`, `address`, `city`, `state`, `pincode`) VALUES
(1, 'Karthik Raja', 'karthik@example.com', 'user123', '9876543210', '12, Anna Nagar West, 2nd Avenue', 'Chennai', 'Tamil Nadu', '600040'),
(2, 'Ananya Sharma', 'ananya@example.com', 'user123', '9845123456', '45/2, Gandhi Road, Adyar', 'Chennai', 'Tamil Nadu', '600020'),
(3, 'Ramesh Kumar', 'ramesh@example.com', 'user123', '9789012345', '78, Cross Cut Road, Gandhipuram', 'Coimbatore', 'Tamil Nadu', '641012');

-- 4. Insert Comprehensive Book Catalog (16 Books across 8 Categories)
INSERT INTO `books` (`book_id`, `title`, `author`, `category_id`, `publisher`, `isbn`, `price`, `stock`, `description`, `image_url`, `featured`) VALUES
(1, 'Java: The Complete Reference', 'Herbert Schildt', 1, 'McGraw Hill Education', '978-1260440232', 850.00, 25, 'The definitive guide to Java Programming covering language syntax, core libraries, OOP concepts, collections, and modern concurrency.', 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400&q=80', 1),
(2, 'Clean Code: A Handbook of Agile Software Craftsmanship', 'Robert C. Martin', 1, 'Prentice Hall', '978-0132350884', 650.00, 18, 'Even bad code can function. But if code isn’t clean, it can bring a development organization to its knees. Learn how to write robust, maintainable code.', 'https://images.unsplash.com/photo-1532012164546-f432f2e3777a?w=400&q=80', 1),
(3, 'Design Patterns: Elements of Reusable Object-Oriented Software', 'Erich Gamma, Richard Helm, Ralph Johnson, John Vlissides', 1, 'Addison-Wesley', '978-0201633610', 920.00, 12, 'The classic Gang of Four book on software engineering patterns that transform code design and enterprise software scalability.', 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400&q=80', 0),
(4, 'The Alchemist', 'Paulo Coelho', 2, 'HarperCollins', '978-0062315007', 350.00, 40, 'A magical story of Santiago, an Andalusian shepherd boy who yearns to travel in search of a worldly treasure as extravagant as any ever found.', 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&q=80', 1),
(5, 'To Kill a Mockingbird', 'Harper Lee', 2, 'J. B. Lippincott & Co.', '978-0061120084', 420.00, 15, 'A gripping, heart-wrenching story of innocence betrayed and racial injustice in the Deep South, viewed through the eyes of young Scout Finch.', 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=400&q=80', 0),
(6, 'Sapiens: A Brief History of Humankind', 'Yuval Noah Harari', 3, 'Harper', '978-0062316097', 599.00, 30, 'Explore the entire history of the human species, from the very first humans to walk the earth to the radical breakthroughs of the Cognitive, Agricultural, and Scientific Revolutions.', 'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?w=400&q=80', 1),
(7, 'Atomic Habits', 'James Clear', 3, 'Avery', '978-0735211292', 499.00, 50, 'An easy and proven way to build good habits and break bad ones. Learn the tiny changes that bring remarkable, lifelong results.', 'https://images.unsplash.com/photo-1541963463532-d68292c34b19?w=400&q=80', 1),
(8, 'A Brief History of Time', 'Stephen Hawking', 4, 'Bantam Books', '978-0553380163', 450.00, 20, 'From the big bang to black holes, theoretical physicist Stephen Hawking takes readers on a breathtaking voyage through the cosmos.', 'https://images.unsplash.com/photo-1506880018603-83d5b814b5a6?w=400&q=80', 0),
(9, 'Cosmos', 'Carl Sagan', 4, 'Random House', '978-0345539434', 550.00, 14, 'Carl Sagan explores fifteen billion years of cosmic evolution and the development of science and civilization with dazzling eloquence.', 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=400&q=80', 0),
(10, 'Artificial Intelligence: A Modern Approach', 'Stuart Russell, Peter Norvig', 5, 'Pearson', '978-0134610993', 1150.00, 10, 'The most comprehensive, up-to-date introduction to the theory and practice of artificial intelligence in modern computing.', 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=400&q=80', 1),
(11, 'The Lean Startup', 'Eric Ries', 6, 'Crown Business', '978-0307887894', 520.00, 22, 'How today’s entrepreneurs use continuous innovation to create radically successful businesses and navigate uncertainty.', 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&q=80', 1),
(12, 'Rich Dad Poor Dad', 'Robert T. Kiyosaki', 6, 'Plata Publishing', '978-1612680194', 399.00, 35, 'What the rich teach their kids about money that the poor and middle class do not. The #1 personal finance book of all time.', 'https://images.unsplash.com/photo-1553729459-efe14ef6055d?w=400&q=80', 0),
(13, 'Wings of Fire: An Autobiography', 'A.P.J. Abdul Kalam, Arun Tiwari', 7, 'Universities Press', '978-8173711466', 320.00, 45, 'The inspirational autobiography of Dr. A.P.J. Abdul Kalam, former President of India, recounting his journey from humble beginnings to missile pioneer.', 'https://images.unsplash.com/photo-1516979187457-637abb4f9353?w=400&q=80', 1),
(14, 'Steve Jobs', 'Walter Isaacson', 7, 'Simon & Schuster', '978-1451648539', 690.00, 16, 'The exclusive and unvarnished biography of Steve Jobs, based on more than forty interviews with Jobs conducted over two years.', 'https://images.unsplash.com/photo-1519682337058-a94d519337bc?w=400&q=80', 0),
(15, 'Higher Engineering Mathematics', 'B.S. Grewal', 8, 'Khanna Publishers', '978-8174091955', 780.00, 28, 'Comprehensive textbook for undergraduate engineering students covering advanced calculus, differential equations, and linear algebra.', 'https://images.unsplash.com/photo-1509228468518-180dd4864904?w=400&q=80', 0),
(16, 'Core Python Programming', 'Dr. R. Nageswara Rao', 1, 'Dreamtech Press', '978-9386052308', 580.00, 3, 'Comprehensive guide to mastering Python concepts, OOP, GUI programming, databases, and data structures. (Low stock sample item)', 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=400&q=80', 0);

-- 5. Insert Sample Orders
INSERT INTO `orders` (`order_id`, `user_id`, `order_date`, `total_amount`, `status`, `recipient_name`, `recipient_phone`, `delivery_address`, `payment_method`) VALUES
(1001, 1, '2026-08-25 10:30:00', 1349.00, 'DELIVERED', 'Karthik Raja', '9876543210', '12, Anna Nagar West, 2nd Avenue, Chennai, Tamil Nadu - 600040', 'Online Payment Demo'),
(1002, 2, '2026-08-30 14:15:00', 850.00, 'SHIPPED', 'Ananya Sharma', '9845123456', '45/2, Gandhi Road, Adyar, Chennai, Tamil Nadu - 600020', 'Cash on Delivery'),
(1003, 3, '2026-09-01 16:45:00', 499.00, 'PLACED', 'Ramesh Kumar', '9789012345', '78, Cross Cut Road, Gandhipuram, Coimbatore, Tamil Nadu - 641012', 'Online Payment Demo');

-- 6. Insert Sample Order Details
INSERT INTO `order_details` (`order_detail_id`, `order_id`, `book_id`, `quantity`, `price`) VALUES
(1, 1001, 1, 1, 850.00),
(2, 1001, 7, 1, 499.00),
(3, 1002, 1, 1, 850.00),
(4, 1003, 7, 1, 499.00);

-- 7. Insert Sample Payments
INSERT INTO `payments` (`payment_id`, `order_id`, `payment_method`, `amount`, `payment_status`, `payment_date`, `transaction_ref`) VALUES
(1, 1001, 'Online Payment Demo', 1349.00, 'COMPLETED', '2026-08-25 10:31:00', 'TXN-YTC-98234123'),
(2, 1002, 'Cash on Delivery', 850.00, 'PENDING', '2026-08-30 14:15:00', 'COD-YTC-1002'),
(3, 1003, 'Online Payment Demo', 499.00, 'COMPLETED', '2026-09-01 16:46:00', 'TXN-YTC-77123984');

-- Sample User 1 Cart
INSERT INTO `cart` (`user_id`, `book_id`, `quantity`) VALUES
(1, 4, 1),
(1, 11, 2);

-- Output status confirmation
SELECT 'Database initialization completed successfully for YUVAN BOOK STORE' AS `Status`;
