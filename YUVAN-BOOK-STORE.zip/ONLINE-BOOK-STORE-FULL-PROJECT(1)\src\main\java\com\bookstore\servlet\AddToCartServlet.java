package com.bookstore.servlet;

import com.bookstore.dao.BookDAO;
import com.bookstore.dao.CartDAO;
import com.bookstore.model.Book;
import com.bookstore.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Controller servlet for adding books to the shopping cart with real-time stock validation.
 * Company: YUVAN & THIYAGU & CO.
 */
@WebServlet(name = "AddToCartServlet", urlPatterns = {"/cart/add"})
public class AddToCartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final CartDAO cartDAO = new CartDAO();
    private final BookDAO bookDAO = new BookDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("loggedUser") : null;

        String returnUrl = request.getHeader("referer");
        if (returnUrl == null || returnUrl.isEmpty()) {
            returnUrl = request.getContextPath() + "/books";
        }

        if (user == null) {
            session = request.getSession(true);
            session.setAttribute("errorMsg", "Please log in to add books to your shopping cart.");
            session.setAttribute("redirectAfterLogin", returnUrl);
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String bookIdParam = request.getParameter("bookId");
        String quantityParam = request.getParameter("quantity");

        int quantity = 1;
        if (quantityParam != null && !quantityParam.trim().isEmpty()) {
            try {
                quantity = Integer.parseInt(quantityParam);
                if (quantity <= 0) quantity = 1;
            } catch (NumberFormatException e) {
                quantity = 1;
            }
        }

        if (bookIdParam == null || bookIdParam.trim().isEmpty()) {
            session.setAttribute("errorMsg", "Invalid book selection.");
            response.sendRedirect(returnUrl);
            return;
        }

        try {
            int bookId = Integer.parseInt(bookIdParam);
            Book book = bookDAO.getBookById(bookId);

            if (book == null) {
                session.setAttribute("errorMsg", "Book not found.");
                response.sendRedirect(returnUrl);
                return;
            }

            if (book.getStock() <= 0) {
                session.setAttribute("errorMsg", "'" + book.getTitle() + "' is currently Out of Stock.");
                response.sendRedirect(returnUrl);
                return;
            }

            if (quantity > book.getStock()) {
                session.setAttribute("errorMsg", "Requested quantity (" + quantity + ") exceeds available stock (" + book.getStock() + ").");
                response.sendRedirect(returnUrl);
                return;
            }

            boolean added = cartDAO.addToCart(user.getUserId(), bookId, quantity);
            if (added) {
                int totalCount = cartDAO.getCartCount(user.getUserId());
                session.setAttribute("cartCount", totalCount);
                session.setAttribute("successMsg", "'" + book.getTitle() + "' was added to your cart!");
            } else {
                session.setAttribute("errorMsg", "Could not add item to cart. Stock limit reached.");
            }

        } catch (NumberFormatException e) {
            session.setAttribute("errorMsg", "Invalid book ID.");
        }

        response.sendRedirect(returnUrl);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }
}
