package com.bookstore.servlet;

import com.bookstore.dao.BookDAO;
import com.bookstore.dao.CategoryDAO;
import com.bookstore.model.Book;
import com.bookstore.model.Category;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * Controller servlet for Admin Book Management:
 * List, Add, Edit, Delete, Search, and Update Books.
 * Company: YUVAN & THIYAGU & CO.
 */
@WebServlet(name = "AdminBookServlet", urlPatterns = {
        "/admin/books", "/admin/add-book", "/admin/edit-book", "/admin/delete-book"
})
public class AdminBookServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final BookDAO bookDAO = new BookDAO();
    private final CategoryDAO categoryDAO = new CategoryDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();

        switch (path) {
            case "/admin/add-book":
                showAddBookForm(request, response);
                break;
            case "/admin/edit-book":
                showEditBookForm(request, response);
                break;
            case "/admin/delete-book":
                handleDeleteBook(request, response);
                break;
            case "/admin/books":
            default:
                listBooks(request, response);
                break;
        }
    }

    private void listBooks(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String search = request.getParameter("search");
        List<Book> books;
        if (search != null && !search.trim().isEmpty()) {
            books = bookDAO.searchBooks(search.trim());
            request.setAttribute("searchKeyword", search.trim());
        } else {
            books = bookDAO.getAllBooks();
        }
        request.setAttribute("books", books);
        request.getRequestDispatcher("/admin/books.jsp").forward(request, response);
    }

    private void showAddBookForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Category> categories = categoryDAO.getAllCategories();
        request.setAttribute("categories", categories);
        request.getRequestDispatcher("/admin/add-book.jsp").forward(request, response);
    }

    private void showEditBookForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idParam = request.getParameter("id");
        if (idParam == null) {
            response.sendRedirect(request.getContextPath() + "/admin/books");
            return;
        }

        try {
            int bookId = Integer.parseInt(idParam);
            Book book = bookDAO.getBookById(bookId);
            if (book == null) {
                request.getSession().setAttribute("errorMsg", "Book not found.");
                response.sendRedirect(request.getContextPath() + "/admin/books");
                return;
            }

            List<Category> categories = categoryDAO.getAllCategories();
            request.setAttribute("book", book);
            request.setAttribute("categories", categories);
            request.getRequestDispatcher("/admin/edit-book.jsp").forward(request, response);

        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/admin/books");
        }
    }

    private void handleDeleteBook(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String idParam = request.getParameter("id");
        HttpSession session = request.getSession();

        if (idParam != null) {
            try {
                int bookId = Integer.parseInt(idParam);
                boolean deleted = bookDAO.deleteBook(bookId);
                if (deleted) {
                    session.setAttribute("successMsg", "Book #" + bookId + " deleted successfully.");
                } else {
                    session.setAttribute("errorMsg", "Failed to delete book. It may have existing orders linked to it.");
                }
            } catch (NumberFormatException e) {
                session.setAttribute("errorMsg", "Invalid Book ID.");
            }
        }
        response.sendRedirect(request.getContextPath() + "/admin/books");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();
        HttpSession session = request.getSession();

        String title = request.getParameter("title");
        String author = request.getParameter("author");
        String categoryIdParam = request.getParameter("categoryId");
        String publisher = request.getParameter("publisher");
        String isbn = request.getParameter("isbn");
        String priceParam = request.getParameter("price");
        String stockParam = request.getParameter("stock");
        String description = request.getParameter("description");
        String imageUrl = request.getParameter("imageUrl");
        boolean featured = request.getParameter("featured") != null;

        // Validation
        if (title == null || title.trim().isEmpty() ||
            author == null || author.trim().isEmpty() ||
            categoryIdParam == null || isbn == null || isbn.trim().isEmpty() ||
            priceParam == null || stockParam == null) {
            
            session.setAttribute("errorMsg", "Please complete all required fields.");
            response.sendRedirect(request.getContextPath() + ("/admin/edit-book".equals(path) ? "/admin/edit-book?id=" + request.getParameter("bookId") : "/admin/add-book"));
            return;
        }

        try {
            int categoryId = Integer.parseInt(categoryIdParam);
            double price = Double.parseDouble(priceParam);
            int stock = Integer.parseInt(stockParam);

            if (price < 0 || stock < 0) {
                session.setAttribute("errorMsg", "Price and Stock cannot be negative numbers.");
                response.sendRedirect(request.getContextPath() + ("/admin/edit-book".equals(path) ? "/admin/edit-book?id=" + request.getParameter("bookId") : "/admin/add-book"));
                return;
            }

            if ("/admin/edit-book".equals(path)) {
                int bookId = Integer.parseInt(request.getParameter("bookId"));
                if (bookDAO.isIsbnExists(isbn, bookId)) {
                    session.setAttribute("errorMsg", "Another book already has this ISBN: " + isbn);
                    response.sendRedirect(request.getContextPath() + "/admin/edit-book?id=" + bookId);
                    return;
                }

                Book book = new Book(bookId, title.trim(), author.trim(), categoryId, publisher, isbn.trim(), price, stock, description, imageUrl, featured, null);
                boolean updated = bookDAO.updateBook(book);
                if (updated) {
                    session.setAttribute("successMsg", "Book details updated successfully!");
                } else {
                    session.setAttribute("errorMsg", "Failed to update book details.");
                }
                response.sendRedirect(request.getContextPath() + "/admin/books");

            } else {
                // Add Book
                if (bookDAO.isIsbnExists(isbn, 0)) {
                    session.setAttribute("errorMsg", "A book with ISBN '" + isbn + "' already exists.");
                    response.sendRedirect(request.getContextPath() + "/admin/add-book");
                    return;
                }

                Book book = new Book(title.trim(), author.trim(), categoryId, publisher, isbn.trim(), price, stock, description, imageUrl, featured);
                boolean added = bookDAO.addBook(book);
                if (added) {
                    session.setAttribute("successMsg", "New book '" + title + "' added to the bookstore catalog!");
                } else {
                    session.setAttribute("errorMsg", "Failed to add book.");
                }
                response.sendRedirect(request.getContextPath() + "/admin/books");
            }

        } catch (NumberFormatException e) {
            session.setAttribute("errorMsg", "Invalid numeric values for Price, Stock, or Category.");
            response.sendRedirect(request.getContextPath() + "/admin/books");
        }
    }
}
